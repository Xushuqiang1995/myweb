rm(list = ls())
library(shiny)
library(reticulate)
library(tidyr)
library(ggplot2)
library(ggthemes)
library(readxl)
library(openxlsx)
library(shinyjqui)
library(shinyWidgets)
library(shinycssloaders)
library(reshape2)
library(data.table)
server <- function(input, output,session) {
  options(shiny.maxRequestSize=5000*1024^2)
  #jqui_bookmarking()
  values=reactiveValues(MS_data=NULL,raw_group_data=NULL,n_sample=NULL,group_data=NULL,plot_RSD=NULL,plot_values_matrix=NULL)
  # print(getwd())
  # print(tempdir())
  original_dir <- getwd()
  
  
  ###上传MS表和repeat_list分组文件------>写在reactive里面
  plotdata <- reactive({
    if(!is.null(input$fileMS)){
      ######先上传MS表
      if(str_detect(input$fileMS$name,pattern = '.txt$')){
        values$MS_data <- read.csv(file=input$fileMS$datapath,sep = '\t',header = T,check.names = F)
      }
      else if(str_detect(input$fileMS$name,pattern = '.csv$')){
        values$MS_data <- read.csv(file=input$fileMS$datapath,header = T,check.names = F)
      }
      else if(str_detect(input$fileMS$name,pattern = '.xls$') | str_detect(input$fileMS$name,pattern = '.xlsx$')){
        num_sheet_MS=excel_sheets(input$fileMS$datapath)
          data_MS <- read_excel(input$fileMS$datapath,col_names=T,sheet=1) %>%
            data.frame()
          values$MS_data <- data_MS
      }
    }
    if(!is.null(input$filegroup)){
      ###再上传分组文件
      if(str_detect(input$filegroup$name,pattern = '.txt$')){
        values$raw_group_data <- read.csv(file=input$filegroup$datapath,sep = '\t',header = F)

        process_group_data <- values$raw_group_data
        process_group_data <- process_group_data[!unlist(lapply(process_group_data$V1, function(i){length(strsplit(i,'/')[[1]])>1})),]
        process_group_data <- process_group_data %>% separate_rows(V1,sep = '\\,') %>% data.frame()
        values$group_data <- process_group_data
      }
      else if(str_detect(input$filegroup$name,pattern = '.csv$')){
        values$raw_group_data <- read.csv(file=input$filegroup$datapath,sep = ',',header = F)

        process_group_data <- values$raw_group_data
        process_group_data <- process_group_data[!unlist(lapply(process_group_data$V1, function(i){length(strsplit(i,'/')[[1]])>1})),]
        process_group_data <- process_group_data %>% separate_rows(V1,sep = '\\,') %>% data.frame()
        values$group_data <- process_group_data
      }
      else if(str_detect(input$filegroup$name,pattern = '.xls$') | str_detect(input$filegroup$name,pattern = '.xlsx$')){
        num_sheet_repeat_list=excel_sheets(input$filegroup$datapath)
          data_repeat_list <- read_excel(input$filegroup$datapath,col_names=F,sheet=1) %>%
            data.frame()
          colnames(data_repeat_list) <- c('V1','V2')
          values$raw_group_data <- data_repeat_list

          process_group_data <- data_repeat_list
          process_group_data <- process_group_data[!unlist(lapply(process_group_data$V1, function(i){length(strsplit(i,'/')[[1]])>1})),]
          process_group_data <- process_group_data %>% separate_rows(V1,sep = '\\,') %>% data.frame()
          values$group_data <- process_group_data
      }
      else{
        values$raw_group_data <- read.csv(file=input$filegroup$datapath,sep = '\t',header = F)

        process_group_data <- values$raw_group_data
        process_group_data <- process_group_data[!unlist(lapply(process_group_data$V1, function(i){length(strsplit(i,'/')[[1]])>1})),]
        process_group_data <- process_group_data %>% separate_rows(V1,sep = '\\,') %>% data.frame()
        values$group_data <- process_group_data
      }
    }
      df <- values$MS_data
      group <- values$group_data
      colnames(group) <- c('sample_id','group')
      values$n_sample <- length(unique(group$group))
      group$group <- factor(group$group,levels = unique(group$group))
      df <- df[,group$sample_id]
      df <- reshape2::melt(as.matrix(df),varnames=c('protein_id','sample_id'),value.name = 'value')
      parse_data <- left_join(df,group,by='sample_id')
      parse_data <- na.omit(parse_data)
      sd_data <- aggregate(parse_data$value,by=list(parse_data$protein_id,parse_data$group),FUN = sd)
      mean_data <- aggregate(parse_data$value,by=list(parse_data$protein_id,parse_data$group),FUN = mean)
      rsd <- round((sd_data$x)/(mean_data$x),3)
      sd_mean_data <- data.frame(sd_data[,-3],rsd)
      colnames(sd_mean_data) <- c('protein_id','sample','RSD')
      sd_mean_data <- na.omit(sd_mean_data)
      df_protein <- data.frame(table(sd_mean_data$protein_id))
      protein_id <- df_protein[df_protein$Freq == values$n_sample,]$Var1
      sd_mean_data <- sd_mean_data[sd_mean_data$protein_id %in% protein_id,]
      # sd_mean_data$RSD <- round(sd_mean_data$RSD,3)
	    showNotification('正在绘图，请稍等...',duration = 5)
      return(sd_mean_data)

  })
  
  

  ####已传数据预览
  output$head_3_MS <- renderDataTable({
    datatable(values$MS_data,rownames = F,class="row-border hover",extensions = 'Buttons',
              options=list(pageLength = 3,lengthMenu = c(10, 20, 50, 100,-1),
                           dom = 'Blfrtip',scrollX=TRUE,buttons = c('csv', 'excel'),autoWidth = TRUE, 
                           columnDefs = list(list(width = "125px", targets = "_all"))))
  })
  output$head_repeat_list <- renderDataTable({
    datatable(values$raw_group_data,rownames = F,class="row-border hover",extensions = 'Buttons',
              options=list(pageLength = 10,lengthMenu = c(10, 20, 50, 100,-1),
                           dom = 'Blfrtip',scrollX=TRUE,buttons = c('csv', 'excel')))
  })
  
  ##########一键默认参数输出
  observeEvent(input$reset_plot, {
    shinyjs::reset("rsdapp")
  })

  ##################处理数据并且将输出图片在UI端-------------绘图（如果在observer函数里去写处理数据的方法会导致代码比较重复，可读性较差）
  output$plotRSD <- renderPlot({
    if(!is.null(input$fileMS) & !is.null(input$filegroup)){
        # showNotification('正在绘图，请稍等...',duration = 5)
         p <- ggplot(data = plotdata(),aes(x=sample,y=RSD,fill=sample))+
          geom_boxplot()+theme_bw()+scale_fill_brewer(palette = input$color)+
          labs(x=input$x_lab,y=input$y_lab,fill=input$legend_lab)+
          ylim(0,input$y_max) ###这个参数需要修改一下，如果y轴减少，图片的绘制是重新根据剩下的点来重新绘制的，可能会导致结果的误差，最好要采用直接截断图片的方法
        themetype <- input$theme_select
        my_theme <- theme(axis.title.x = element_text(size = input$x_lab_size,face=input$x_font_style,family = input$fontfamily_title_x),
                          axis.title.y = element_text(size = input$y_lab_size,face=input$y_font_style,family = input$fontfamily_title_y),
                          legend.title = element_text(size=input$legend_lab_size,face=input$legend_font_style,family = input$fontfamily_title_label),
                          legend.key.width = unit(input$legend_key_width,"pt"),
                          legend.key.height = unit(input$legend_key_height,"pt"),
                          axis.text.x = element_text(size=input$x_size),axis.text.y = element_text(size=input$y_size),
                          legend.text = element_text(size=input$legend_size),legend.position = input$legend_position)
        ############先对ggthemes的主题进行提取，主题必须采用base:eval方法来调用
        if (grepl("::", themetype)) {
          real_theme <- strsplit(themetype, split = "::")[[1]][2]
          pkg <- strsplit(themetype, split = "::")[[1]][1]
          p <- p + base::eval(call(real_theme), envir = rlang::search_env(rlang::pkg_env_name(pkg)))+my_theme   ###ggthemes主题的调用方法需要添加相应的环境
        } else {
          p <- p + base::eval(call(themetype))+my_theme
        }
        values$plot_RSD <- p
        return(p)  ##一般都是最后的时候再去返回图片的值
    }
  })
  

  #######图片低端显示图片宽度和高度
  output$pic_width_and_height=renderUI({
    req(input$plotRSD_size)
    p(paste("width:",input$plotRSD_size$width,"px height:",input$plotRSD_size$height,"px",sep=""))
  })
  
  ###########写入绘图所有绘图参数
  observe({
      para_matrix <- rbind(
      c("R version:","3.6.3"),
      c("R package(version):","ggplot2(v3.3.5)"),
      c("x轴标题",input$x_lab),
      c("y轴标题",input$y_lab),
      c("图例标题",input$legend_lab),
      c("x轴标题字体大小",input$x_lab_size),
      c("y轴标题字体大小",input$y_lab_size),
      c("图例标题字体大小",input$legend_lab_size),
      c("x轴刻度字体大小",input$x_size),
      c("y轴刻度字体大小",input$y_size),
      c("图例内容字体大小",input$legend_size),
      c("x轴标题字体样式",input$x_font_style),
      c("y轴标题字体样式",input$y_font_style),
      c("图例字体样式",input$legend_font_style),
      c("x轴字体型号",input$fontfamily_title_x),
      c("y轴字体型号",input$fontfamily_title_y),
      c("图例字体型号",input$fontfamily_title_label),
      c("图例图标宽度",input$legend_key_width),
      c("图例图标高度",input$legend_key_height),
      c("y轴最大值",input$y_max),
      c("颜色修改",input$color),
      c("图例位置",input$legend_position),
      c("主题选择",input$theme_select),
      c("图片宽度",input$plotRSD_size$width),
      c("图片高度",input$plotRSD_size$height))
    colnames(para_matrix) <- c("Parameters","Values")
    para_matrix <- data.frame(para_matrix)
    values$plot_values_matrix <- para_matrix
    })
  
  ###绘图参数显示
  output$plot_para <- renderTable({
    return(values$plot_values_matrix)
  })
  
  
  ###############下载示例文件 默认参数不用修改
  output$downloaddemo_MS <- downloadHandler(
    filename = function(){
      paste0('demo_MS.txt')
    },
    content = function(file){
      file.copy(paste0(original_dir,"/www/Demo_MS_identified_information.txt"), file)
    }
  )

  output$downloaddemo_repeat_list <- downloadHandler(
    filename = function(){
      paste0('demo_repeat_list.txt')
    },
    content = function(file){
      file.copy(paste0(original_dir,"/www/Demo_repeat_list"), file)
    }
  )
  
  
  #####################导出结果图（暂时导出失败 后续再试）
  output$plotRSD.save.pdf <- downloadHandler(
    filename = function(){
      if((input$plotfilename != "") & (input$plotfilename != ".")){
        plotfilename = input$plotfilename
      }
      else{
        showNotification("请输入正确的文件名称！",type = 'error',duration = 3)
      }
      paste0(plotfilename,'.pdf')
    },
    content = function(file){
      ggsave(filename = file,values$plot_RSD,width = input$plotRSD_size$width/80,height = input$plotRSD_size$height/80)
    },
    contentType = "pdf"
  )

  output$plotRSD.save.png <- downloadHandler(
    filename = function(){ 
    if((input$plotfilename != "") & (input$plotfilename != ".")){
      plotfilename = input$plotfilename
    }
    else{
        showNotification("请输入正确的文件名称！",type = 'error',duration = 3)
      }  
    paste0(plotfilename,'.png')
    },
    content = function(file){
      # ggsave(filename = file,values$plot_RSD,width = input$plotRSD_size$width/70,height = input$plotRSD_size$height/70)
      png(file,width = input$plotRSD_size$width,height = input$plotRSD_size$height)
      print(values$plot_RSD)
      dev.off()
    },
    contentType = "png"
  )
  
  
  
  ###################将所有的绘图参数导出
  output$save_para <- downloadHandler(
    filename = function() {
      paste0("demo_plot_values_matrix",".xlsx")
    },
    content = function(file){
      write.xlsx(values$plot_values_matrix,file=paste0(tempdir(),"/demo_plot_values_matrix.xlsx"),sheetName = "Sheet1",colNames = T,rowNames = F)
      file.copy(paste0(tempdir(),"/demo_plot_values_matrix.xlsx"), file)
    },
    contentType = "xlsx"
  )
}

