rm(list=ls())
library(shiny)
library(shinydashboard)
library(reshape2)
library(tidyverse)
library(shinyjqui)
library(tidyr)
library(shinythemes)
library(esquisse)
library(RColorBrewer)
library(shinyWidgets)
library(shinyjs)
library(shinycssloaders)
library(shinydisconnect)
library(DT)
######字体需先放入再导入,已在shiny_base_plot_r4:v1中/home/zyl/R/Fonts中存放字体文件
ui=function(request) {
  #--------------- Header ------------------------
  header <- dashboardHeader(title = "RSD Plot",titleWidth = 200)  ##表头的位置 200居左  2000居中 表示和左边框的距离
  #--------------- Sidebar ------------------------
  sidebar <- dashboardSidebar(
    collapsed = T
  )
  #--------------- Body ------------------------
  theme_choices <- esquisse:::get_themes()[1:2] #这里不加[1:2]也可以 因为get_themes()函数默认输出两个大列表
  theme_choices$ggthemes$par <- NULL
  theme_choices$ggthemes$solid <- NULL
  ############构建颜色背景语句content
  codelineall2 = NULL
  for (colorname in rownames(brewer.pal.info)) {
    col16=brewer.pal(brewer.pal.info[colorname,1],colorname)#rev()
    col16str=str_c(col16, collapse = ",")
    mycodeline=paste0("<div style='background: linear-gradient(90deg,",col16str,"); color: white;padding-right: 190px;'>",colorname,"</div>")
    codelineall2 = c(codelineall2,mycodeline)
  }
  #################################
  body <- dashboardBody(
              fluidRow(
                column(4,fluidRow(column(6,h4(align="left",tags$b("输入数据&参数"))),column(2),column(1,br(),actionButton('reset_plot',label = '参数一键初始化',icon = icon("sync-alt"),class = "btn-warning"))),
                       tabsetPanel(
                         tabPanel(strong("参数"),useShinyjs(),
                           div(id="rsdapp",style="padding-left: 5px; padding-top: 25px; padding-right: 5px; margin-bottom: 5px;max-height: 750px; overflow-x: hidden;overflow-y: auto;",
                               fluidRow(###横排分割，宽度1-12整数，相对宽度无法精细
                                 column(8,fileInput(inputId = "fileMS",accept = c(".txt",".csv",".xls",".xlsx"),label=NULL,
                                                    placeholder = "txt/csv/xls/xlsx",buttonLabel = "上传MS表")),
                                 column(4,style='float:left;',tags$h5(tags$a(icon("download"),downloadLink("downloaddemo_MS",strong("下载示例MS表")))))
                               ),
                               fluidRow(###横排分割，宽度1-12整数，相对宽度无法精细
                                 column(8,fileInput(inputId = "filegroup",accept = NULL,label=NULL,
                                                    placeholder = "txt/csv/xls/xlsx/无后缀",buttonLabel = "上传分组文件")),
                                 column(4,style='float:left;',tags$h5(tags$a(icon("download"),downloadLink("downloaddemo_repeat_list",strong("下载示例分组文件")))))
                               ),
                               fluidRow(
                                 column(4,textInput('x_lab',"x轴标题",value = 'Sample')),
                                 column(4,textInput('y_lab',"y轴标题",value = 'RSD')),
                                 column(4,textInput('legend_lab',"图例标题",value = 'Sample'))
                               ),
                               fluidRow(
                                 column(4,h1("\n"),numericInput('x_lab_size',"x轴标题字体大小",min = 10,max = 40,value = 20)),
                                 column(4,h1("\n"),numericInput('y_lab_size',"y轴标题字体大小",min = 10,max = 40,value = 20)),
                                 column(4,h1("\n"),numericInput('legend_lab_size',"图例标题字体大小",min = 20,max = 40,value = 20))
                               ),
                               fluidRow(
                                 column(4,h1("\n"),numericInput('x_size',"x轴刻度字体大小",min = 10,max = 40,value = 15)),
                                 column(4,h1("\n"),numericInput('y_size',"y轴刻度字体大小",min = 10,max = 40,value = 15)),
                                 column(4,h1("\n"),numericInput('legend_size',"图例内容字体大小",min = 10,max = 40,value = 15))
                               ),
                               fluidRow(
                                 column(4,h1("\n"),selectInput('x_font_style','x轴标题字体样式',choices = c("plain", "italic", "bold", "bold.italic"),selected = 'plain')),
                                 column(4,h1("\n"),selectInput('y_font_style','y轴标题字体样式',choices = c("plain", "italic", "bold", "bold.italic"),selected = 'plain')),
                                 column(4,h1("\n"),selectInput('legend_font_style','图例字体样式',choices = c("plain", "italic", "bold", "bold.italic"),selected = 'plain')),
                               ),
                               fluidRow(
                                 column(4,br(),pickerInput(inputId = "fontfamily_title_x", label = "x轴字体型号", choices = c("sans","serif","mono","wqy-microhei","Times New Roman","Arial", "Calibri"), selected = "sans")),
                                 column(4,br(),pickerInput(inputId = "fontfamily_title_y", label = "y轴字体型号", choices = c("sans","serif","mono","wqy-microhei","Times New Roman","Arial", "Calibri"), selected = "sans")),
                                 column(4,br(),pickerInput(inputId = "fontfamily_title_label", label = "图例字体型号", choices = c("sans","serif","mono","wqy-microhei","Times New Roman","Arial", "Calibri"), selected = "sans"))
                               ),
                               fluidRow(
                                 column(4,h1("\n"),numericInput('legend_key_width','图例图标宽度',min = 10,max = 40,value = 20)),
                                 column(4,h1("\n"),numericInput('legend_key_height','图例图标高度',min = 10,max = 40,value = 20)),
                                 column(4,h1("\n"),numericInput('y_max','y轴最大值',min = 0.3,max = 1,value = 0.6,step = 0.1)),
                               ),
                               fluidRow(
                                 column(4,h1("\n"),pickerInput('color','颜色修改',choices = rownames(brewer.pal.info),
                                                               selected = 'Dark2',choicesOpt = list(content = codelineall2))),
                                 column(4,h1("\n"),pickerInput('legend_position','图例位置',choices = c("right","left","top","bottom"),selected = 'right')),
                                 column(4,h1("\n"),pickerInput('theme_select','主题选择',choices = theme_choices,selected = 'theme_bw'))
                               )
                           )
                         ),
                         tabPanel(
                           strong("已传数据预览"),
                           br(),
                           p(strong("默认输出矩阵文件前3行和分组文件的前10行")),
                           div(style="margin:0px 12px;max-height: 700px; overflow-y: auto;",
                           dataTableOutput('head_3_MS'),
                           dataTableOutput('head_repeat_list'),
                           )
                         )
                       )
                       
                ),
                column(5,h4(align="left",tags$b("输出结果&图片下载")),
                       tabsetPanel(
                         tabPanel(strong("绘图结果预览"),
                           div(style = "background-color: rgba(255,255,255,0); padding-left: 5px; padding-top: 25px; padding-right: 5px; margin-bottom: 5px;",
                                  fluidRow(
                                    column(4,textInput("plotfilename",label="下载文件名：","RSD_plot")),
                                    column(2,style='padding: 24px;padding-left: 3px',downloadButton('plotRSD.save.pdf',label = '导出pdf图片')),#####padding-left: 40px;
                                    column(2,style='padding: 24px;padding-left: 3px',downloadButton('plotRSD.save.png',label = '导出png图片')),
                                    column(2,style='padding: 24px;padding-left: 3px',downloadButton('save_para',label = '导出绘图参数')),
                                  ),
                                  p(strong("注意:图片右下方‘三角符号’可拖拽，以改变下载图片的宽度和高度，右下方实时显示拖拽后的宽度和高度")),
                                  withSpinner(jqui_resizable(plotOutput("plotRSD", width = "650px", height = "600px")),type=4),
                                  uiOutput("pic_width_and_height")
                         
                       
                          
                         )
                       ),
                       tabPanel(strong("绘图参数预览"),
                         div(style="margin:0px 12px;max-height: 750px; overflow-y: auto;",      
                         br(),
                         p("本地绘图参数汇总，可在'绘图结果预览'栏点击下载方便后续重现"),
                         tableOutput('plot_para')
                         )
                       )
                       )
                      ),
                column(3,h4(align="center",tags$b("说明")),
                       tabsetPanel(
                         tabPanel(strong("使用教程&案例"),
                           div(style="margin:0px 12px;max-height: 750px; overflow-y: auto;",
                           h4(tags$b("简介：")),
                           p("相对标准偏差（RSD）分析，相对标准偏差(relative standard deviation；RSD)又叫标准偏差系数、变异系数、变动系数等，由标准偏差除以相应的平均值乘100%所得值，可检验分析结果的精密度，旨在评估多次实验所得结果之间的一致性"),
                           h4(tags$b("适用范围：")),
                           p("用于评估样本重复性，输入数据需要包含MS表（蛋白组或修饰组等其他类型的数据皆可）和repeat_list（样本分组文件）"),
                           h4(tags$b("输入文件：")),
                           p("输入矩阵文件必须包含的列有：",strong("样本ID"),"。样本名称必须和repeat_list相对应，不可缺少或者增加"),
                           p("文件格式支持txt(制表符分隔),csv分隔(逗号分隔),xls,xlsx四种格式,此外repeat_list文件有无后缀名均可以进行分析"),
                           p("此工具提供内置demo示例文件可下载，如需绘制RSD图请务必按照此示例参照此格式进行分析"),
                           h4(tags$b("示例输入文件（MS&repeat_list）：")),
                           div(align="center",tags$img(src="MS.png",heigth="90%",width="100%")),
                           div(align="center",tags$img(src="repeatList.png",heigth="90%",width="100%")),
                           h4(tags$b("示例绘图结果：")),
                           div(align="center",tags$img(src="plot.png",heigth="90%",width="100%")),
                           h4(tags$b("下载：")),
                           p("下载图片文件的名称可以自定义修改,提供两种格式的图片下载，并且可以导出参数，图片右下角三角符号可拖拽来改变图片宽高")
                           )
                         ),
                         tabPanel(strong("常见问题(FAQ)"),
                                  br(),
                                  p(tags$b("Q1.上传文件找不到自己的文件？")),
                                  p("注意检查文件名称是否有后缀名",strong("(本地电脑推荐显示文件拓展名)，"),"默认支持四种文件格式，文件若无后缀名（txt,csv,xls,xlsx），在选择文件下拉框注意选择‘所有文件’"),
                                  br(),
                                  p(tags$b("Q2.下载的图片模糊怎么办？")),
                                  p("小工具提供png和pdf两种格式的图片，pdf为矢量图，可无限放大不模糊"),
                                  br(),
                                  p(tags$b("Q3.小工具界面的控件排列混乱影响使用怎么办？")),
                                  p("建议使用google浏览器，并且显示全屏，浏览器下载地址：https://www.google.cn/intl/zh-CN/chrome/"),
                                  br(),
                                  p(tags$b("Q4.提交完成后不出图，而且报错信息没有明确提示怎么办？")),
                                  p("请仔细检查文件的格式，特别是MS表，因为数据中的特殊字符会影响结果的输出，例如 %、NA、+、-、（）、空格、科学计数、罗马字母等，去掉特殊符号，将特殊字符替换为空"),
                                  br(),
                                  p(tags$b("Q5.如果最终还想在结果图片上添加一些信息，怎么修改呢？")),
                                  p("如需修改，可以将pdf图导入到AI（Adobe Illustrator）等软件进行调整"),
                                  br(),
                                  p(tags$b("Q6.RSD箱线图的x轴的样本组别从左至右的排列顺序是按照什么来排序的，如果更换排序？")),
                                  p("默认按照repeat_list.txt文件的第二列为排序标准，如需修改顺序可在上传文件之前编辑repeat_list即可"),
                                  br(),
                                  p(tags$b("Q7.文件较多时怎么检验自己传的数据对不对?")),
                                  p("在'已传数据预览'里可以预览上传的数据并且提供csv和txt两种格式的数据下载，'entries'可自由选择当前页面需要展示的行数，为-1时表示显示全部")
                                  
                         )
                          
                       )
                     
                      
                       
                )
              )
      
  )
  #--------------- Page ------------------------
  dashboardPage(skin = 'blue',header,sidebar, body)
}
