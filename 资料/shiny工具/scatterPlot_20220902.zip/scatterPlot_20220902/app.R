rm(list = ls())
library(shiny)
library(shinycssloaders)
library(readxl)
library(DT)
library(dplyr)
library(ggplot2)
library(egg)  
library(ggthemes)
library(shinyWidgets)
library(shinyjqui)
library(RColorBrewer)
library(colourpicker)
library(stringr)
library(showtext)
library(esquisse)
library(ggpubr)
library(ggsci)
library(tibble)
library(magrittr)
library(purrr)
library(tidyr)
library(readr)
library(rlang)
library(hrbrthemes)
library(shinylogs)
library(ggrepel)
library(openxlsx)
choices_font <- font_families()

ui <- fluidPage(titlePanel(title = "散点图"),
                sidebarLayout(
                  sidebarPanel(
                    width = 4,
                    tabsetPanel(
                    tabPanel("参数",div(style="padding-left: 5px; padding-top: 25px; padding-right: 5px; margin-bottom: 5px;max-height: 800px; overflow-x: hidden;overflow-y: auto;",
                                 fluidRow(
                                   column(8,fileInput(inputId = "file",label = "输入文件",buttonLabel = "上传文件",accept = ".xlsx",placeholder = "ScatterPlot.xlsx")),
                                   column(4,br(),style='float:left;',tags$h5(tags$a(icon("download"),downloadLink("downloaddemo_file",strong("下载示例文件")))))
                                 ),
                                 awesomeRadio(
                                   inputId = "logOrNot",
                                   label = "数据处理方式",
                                   choices = c("不处理", "log2", "log10"),
                                   selected = "log2",
                                   inline = TRUE
                                 ), 
                                 fluidRow(column(width = 6, pickerInput(
                                   inputId = "bg_theme",
                                   label = "绘图主题",
                                   choices = c(
                                     "theme_article",
                                     "theme_pubr",
                                     "theme_gray",
                                     "theme_bw",
                                     "theme_linedraw",
                                     "theme_light",
                                     "theme_dark",
                                     "theme_minimal",
                                     "theme_classic"
                                   ),selected = "theme_article"
                                 )), 
                                 column(width = 6, textInput(
                                   inputId = "figuretitle",
                                   label = "图片主标题",
                                   value = "ScatterPlot"
                                 ))),
                                 
                                 # fluidpage ---------------------------------------------------------------
                                 
                                 
                                 fluidRow(column(width = 6, numericInput(
                                   inputId = "dotsize",
                                   label = "散点大小",
                                   value = 3,
                                   min = 1,
                                   max = 10
                                 )), 
                                 column(width = 6, numericInput(
                                   inputId = "alpha",
                                   label = "散点透明度",
                                   value = 0.8,
                                   min = 0,
                                   max = 1,
                                   step = 0.1
                                 ))),
                                 fluidRow(column(width = 6, awesomeRadio(
                                   inputId = "show_legend",
                                   label = "图例",
                                   choices = c("显示", "隐藏"),
                                   selected = "显示",
                                   inline = TRUE
                                 )),
                                 column(width = 6, pickerInput(
                                   inputId = "legend_position",
                                   label = "图例位置",
                                   choices = c("右边", "上边"),
                                   selected = "右边",
                                 ))),
                                 fluidRow(
                                   column(6,awesomeCheckbox(
                                     inputId = "show_r",
                                     label = "标注相关系数R",
                                     value = TRUE
                                   )),
                                   column(6,awesomeCheckbox(
                                     inputId = "show_point_label",
                                     label = "标注蛋白标签",
                                     value = FALSE
                                   ))
                                 ),
                                 uiOutput('choice_point_process'),
                                 
                                 fluidRow(
                                   column(width = 6, numericInput(
                                     inputId = "r_x",
                                     label = "R在X轴位置坐标",
                                     value = -8,
                                     step = 2
                                   )),
                                   column(width = 6, numericInput(
                                     inputId = "r_y",
                                     label = "R在Y轴位置坐标",
                                     value = 10,
                                     step = 2
                                   ))),
                                 
                                 fluidRow(
                                   column(width = 6, textInput(
                                     inputId = "title_x",
                                     label = "x轴标题",
                                     value = ""
                                   )),
                                   column(width = 6, textInput(
                                     inputId = "title_y",
                                     label = "y轴标题",
                                     value = ""
                                   ))),
                                 fluidRow(column(width = 4, textInput(
                                   inputId = "up_label",
                                   label = "上调标签",
                                   value = "Up"
                                 )), 
                                 column(width = 4, textInput(
                                   inputId = "unchange_label",
                                   label = "无差异标签",
                                   value = "NoDiff"
                                 )), 
                                 column(width = 4, textInput(
                                   inputId = "down_label",
                                   label = "下调标签",
                                   value = "Down"
                                 ))),
                                 
                                 fluidRow(column(width = 4, numericInput(
                                   inputId = "font_size",
                                   label = "字号",
                                   value = 20,
                                   min = 5,
                                   max = 50
                                 )), 
                                 column(width = 4, pickerInput(
                                   inputId = "font_family",
                                   label = "字体",
                                   choices = choices_font, 
                                   selected = "sans"
                                 ))),
                                 fluidRow(column(width = 4, colourInput(
                                   inputId = "up_color",
                                   label = "上调颜色",
                                   value = "#F01405"
                                 )), 
                                 column(width = 4, colourInput(
                                   inputId = "unchange_color",
                                   label = "无差异颜色",
                                   value = "#615F5F"
                                 )), 
                                 column(width = 4, colourInput(
                                   inputId = "down_color",
                                   label = "下调颜色",
                                   value = "#0A54BD"
                                 )))),
                      ),
                    tabPanel(
                      title = "已传数据预览",
                      uiOutput(outputId = "ui1"),
                      div(style = "margin:0px 0px; max-width: 500px; max-height: 650px;
                               overflow-x: auto;", dataTableOutput(outputId = 'table'))
                    )
                    )
                ),
               mainPanel(width = 8,
                            fluidRow(
                              column(7,tags$h4("输出结果&图片下载"),
                              tabsetPanel(
                               tabPanel(
                                 title = "输出图片",
                                 br(),
                                 downloadBttn(
                                   outputId = "download_pdf",
                                   size = "sm",
                                   label = "Export pdf"
                                 ),
                                 downloadBttn(
                                   outputId = "download_png",
                                   size = "sm",
                                   label = "Export png"
                                 ),br(),
                                 withSpinner(jqui_resizable(plotOutput("plot", width = "700px", height = "600px")),type=4),
                                 uiOutput("pic_width_and_height")
                               ),
                               tabPanel(
                                 title = '绘图参数预览',
                                 div(style="margin:0px 12px;max-height: 750px;overflow-x: hidden; overflow-y: auto;",      
                                     br(),
                                     fluidRow(
                                       column(6,p("本地绘图参数汇总，可点击'参数下载'方便后续重现")),
                                       column(6,downloadButton('save_para',label = '导出绘图参数'))
                                     ),
                                     br(),
                                     tableOutput('plot_para')
                                 )
                               )
                                     )),
                              column(5, tags$h4("说明"),
                                     tabsetPanel(
                                       tabPanel(
                                         "使用教程",
                                         div(
                                           style="padding-left: 5px; padding-top: 25px; padding-right: 5px; margin-bottom: 5px;max-height: 800px;overflow-y: auto;",
                                           tags$h4(tags$b("简介：")),
                                           p("用于绘制两样本中蛋白表达量上下调的散点图（蛋白组、基因组、修饰组等其他类型的数据皆可）"),
                                           tags$h4(tags$b("文件格式：")),
                                           tags$p("Excel专用的.xlsx格式"),
                                           tags$h4(tags$b("文件内容：")),
                                           tags$p(
                                             "表格中的数据如图所示，除去第一列'protein'，
                                           第一列为蛋白在样本1中的表达信息，用于绘制散点图的X轴；
                                           第二列为蛋白在样本2中的表达信息，用于绘制散点图的Y轴；
                                           第三列为蛋白的差异方向，上调蛋白标签必须为up，下调蛋白标签必须为down，非差异蛋白标签必须为no_diff；散点根据差异方向来标注颜色。"
                                           ),
                                           tags$div(align = "center", tags$img(
                                             src = "demo_file.png",
                                             height = "100%",
                                             width = "100%"
                                           )),
                                           tags$h4(tags$b("结果展示：")),
                                           p('文件有蛋白ID信息时，可点击左栏中“标注蛋白标签”显示蛋白标签，否则无需点击，每次绘图结束可在“绘图参数预览”点击参数下载以便下次重复。'),
                                           tags$div(align = "center", tags$img(
                                             src = "result_plot.png",
                                             height = "100%",
                                             width = "100%"
                                           ))
                                         )
                                         
                                       ),
                                       
                                       tabPanel("工具开发者",
                                                tags$br(),
                                                tags$p("版本号："),
                                                tags$p("v0.0.1"),
                                                 p('开发者：'),
                                       p('景杰生信部qy'),
                                       p('维护：'),
                                       p('景杰生信部lhd'),
                                       p('发布日期：'),
                                       p('2022-09-01')
                                       
                                       
                                       )
                                               
                                       
                                     ))
                            ))
                ))


#---------------------------------------------------server-------------------------------------------------------------------#
server <- function(input, output, session) {
  original_dir <- getwd()
  values=reactiveValues(data=NULL,preview_data=NULL,filter_data=NULL,sheet=NULL,plot_values_matrix=NULL,x_title=NULL,y_title=NULL)
  options(shiny.maxRequestSize=100*1024^2) 
  ##上传文件
  plot_data <- reactive({
    if(!is.null(input$file)){
      values$data <- read_xlsx(path=input$file$datapath,sheet=input$sheet)
      return(values$data)
    }
    
  })
  
  ###上传文件预览前10行
  output$table=renderDataTable({
    datatable(plot_data())
  })
  
  ##取出xls文件所有的sheet
  observeEvent(input$file,{
    req(input$file)
    inFile <- input$file
    if(stringr::str_detect(inFile$name,pattern = '.xlsx$')){
      values$sheets=excel_sheets(path = inFile$datapath)
    }
    else{
      showModal(
        modalDialog(
          p("Please upload a file in excel format!")
        )
      )
    }

  })
  ###判断用哪个sheet页面
  output$ui1=renderUI({
    req(values$sheets)
    div(
      tags$h4(style="color:red","如果excel文件有很多sheet页，请选择其中一个sheet页进行分析!"),
      radioButtons('sheet',label="Sheet names",choices = values$sheets,inline = T)
    )
  })
  
  
  
  ##根据文件行数来判断有无必要添加“是否添加蛋白标签”的必要
  # output$protein_label_ui <- renderUI({
  #   if(!is.null(input$file)){
  #     if(ncol(plot_data())==4){
  #     awesomeCheckbox(
  #         inputId = "show_point_label",
  #         label = "标注蛋白标签",
  #         value = FALSE
  #       )
  #   }
  #   }
  #   
  # })
  
  
  
  
  
  
  
  ##蛋白标签页修改
  output$choice_point_process <- renderUI({
      if(input$show_point_label){
      div(
        fluidRow(
        column(4,numericInput('point_size',label = '蛋白标签大小',value = 5,min = 3,max = 10,step = 1)),
        column(4,numericInput('point_number_up',label = "展示上调蛋白标签个数",value = 5,min = 3,max = 10,step = 1)),
        column(4,numericInput('point_number_down',label = "展示下调蛋白标签个数",value = 5,min = 3,max = 10,step = 1))
      )
      )

    }
    

  })

  
  ##图片低端显示图片宽高
  output$pic_width_and_height=renderUI({
    req(input$plot_size)
    p(paste("width:",input$plot_size$width,"px height:",input$plot_size$height,"px",sep=""))
  })
  
  ###绘图参数写入
  observe({
    if(!is.null(input$file)){
      if(input$show_point_label){
        para_matrix <- rbind(
          c("R version:","3.6.3"),
          c("R package(version):","ggplot2(v3.3.5)"),
          c("数据处理方式",input$logOrNot),
          c("绘图主题",input$bg_theme),
          c("图片主标题",input$figuretitle),
          c("散点大小",input$dotsize),
          c("散点透明度",input$alpha),
          c("图例",input$show_legend),
          c("图例位置",input$legend_position),
          c("标注相关系数R",input$show_r),
          c("标注蛋白标签",input$show_point_label),
          c("蛋白标签大小",input$point_size),
          c("展示上调蛋白标签个数",input$point_number_up),
          c("展示下调蛋白标签个数",input$point_number_down),
          c("R在x轴位置坐标",input$r_x),
          c("R在Y轴位置坐标",input$r_y),
          c("x轴标题",values$x_title),
          c("y轴标题",values$y_title),
          c("上调标签",input$up_label),
          c("无差异标签",input$unchange_label),
          c("下调标签",input$down_label),
          c("字号",input$font_size),
          c("字体",input$font_family),
          c("上调颜色",input$up_color),
          c("无差异颜色",input$unchange_color),
          c("下调颜色",input$down_color),
          c("图片宽度",input$plot_size$width),
          c("图片高度",input$plot_size$height)
        )
      }
      else{
        para_matrix <- rbind(
          c("R version:","3.6.3"),
          c("R package(version):","ggplot2(v3.3.5)"),
          c("数据处理方式",input$logOrNot),
          c("绘图主题",input$bg_theme),
          c("图片主标题",input$figuretitle),
          c("散点大小",input$dotsize),
          c("散点透明度",input$alpha),
          c("图例",input$show_legend),
          c("图例位置",input$legend_position),
          c("标注相关系数R",input$show_r),
          c("标注蛋白标签",input$show_point_label),
          c("R在x轴位置坐标",input$r_x),
          c("R在Y轴位置坐标",input$r_y),
          c("x轴标题",values$x_title),
          c("y轴标题",values$y_title),
          c("上调标签",input$up_label),
          c("无差异标签",input$unchange_label),
          c("下调标签",input$down_label),
          c("字号",input$font_size),
          c("字体",input$font_family),
          c("上调颜色",input$up_color),
          c("无差异颜色",input$unchange_color),
          c("下调颜色",input$down_color),
          c("图片宽度",input$plot_size$width),
          c("图片高度",input$plot_size$height)
        )
      }
    }
    else{
      para_matrix <- rbind(
        c("R version:","3.6.3"),
        c("R package(version):","ggplot2(v3.3.5)"),
        c("数据处理方式",input$logOrNot),
        c("绘图主题",input$bg_theme),
        c("图片主标题",input$figuretitle),
        c("散点大小",input$dotsize),
        c("散点透明度",input$alpha),
        c("图例",input$show_legend),
        c("图例位置",input$legend_position),
        c("标注相关系数R",input$show_r),
        c("标注蛋白标签",input$show_point_label),
        c("R在x轴位置坐标",input$r_x),
        c("R在Y轴位置坐标",input$r_y),
        c("x轴标题",''),
        c("y轴标题",''),
        c("上调标签",input$up_label),
        c("无差异标签",input$unchange_label),
        c("下调标签",input$down_label),
        c("字号",input$font_size),
        c("字体",input$font_family),
        c("上调颜色",input$up_color),
        c("无差异颜色",input$unchange_color),
        c("下调颜色",input$down_color),
        c("图片宽度",input$plot_size$width),
        c("图片高度",input$plot_size$height)
      )
    }
    
    colnames(para_matrix) <- c("Parameters","Values")
    para_matrix <- data.frame(para_matrix)
    values$plot_values_matrix <- para_matrix
  })

  
  
  ##参数显示
  output$plot_para <- renderTable({
    return(values$plot_values_matrix)
  })
  
  
  #######出图
  output$plot <- renderPlot({
    if(!is.null(input$file)){
      
      if(ncol(plot_data())==4){
        plot.data <- plot_data()
        inputname1 <- colnames(plot.data)[2]
        inputname2 <- colnames(plot.data)[3]
        inputname3 <- colnames(plot.data)[4]
        colnames(plot.data) <- c("ID","X","Y","Type")
      }
      else if (ncol(plot_data())==3){
        plot.data <- plot_data()
        inputname1 <- colnames(plot.data)[1]
        inputname2 <- colnames(plot.data)[2]
        inputname3 <- colnames(plot.data)[3]
        colnames(plot.data) <- c("X","Y","Type")
      }
      
      
      
      
      #设置展示标签的个数
      if(input$show_point_label){

      ###计算ratio值来进行排序
      # ratio <- (plot.data$Y)/(plot.data$X)
      # up_index <- order(ratio,decreasing = T)[1:(input$point_number)/2]
      # down_index <- order(ratio)[1:(input$point_number)/2]
      # index <- c(up_index,down_index)
      # index <- unique(index)
      # index <- setdiff(c(1:length(plot.data$ID)),index)
      # plot.data$ID[index] <- ''

      #计算上调的top_n和下调的down_n 
      req(input$point_number_up)
      up_plot.data <- plot.data[plot.data$Type == 'up',]
      down_plot.data <- plot.data[plot.data$Type == 'down',]
      
      up_ratio <- up_plot.data$Y / up_plot.data$X
      top10_up_plot.data <- up_plot.data[order(up_ratio,decreasing = T),][1:input$point_number_up,]
      up_id <- top10_up_plot.data$ID
      
      down_ratio <- down_plot.data$Y / down_plot.data$X
      top10_down_plot.data <- down_plot.data[order(down_ratio),][1:input$point_number_down,] 
      down_id=top10_down_plot.data$ID
      
      id <- c(up_id,down_id)
      index <- match(id,plot.data$ID)
      index <- setdiff(c(1:length(plot.data$ID)),index)
      plot.data$ID[index] <- ''
      }

      
      xlab <- inputname1
      ylab <- inputname2
      legendlab <- inputname3
      
      if (input$logOrNot == "log2") {
        plot.data[,"X"] <- log2(plot.data[,"X"])
        plot.data[,"Y"] <- log2(plot.data[,"Y"])
        xlab <- paste("Log2", xlab)
        ylab <- paste("Log2", ylab)
      } else if (input$logOrNot == "log10") {
        plot.data[,"X"] <- log10(plot.data[,"X"])
        plot.data[,"Y"] <- log10(plot.data[,"Y"])
        xlab <- paste("Log10", xlab)
        ylab <- paste("Log10", ylab)
      } else {
        plot.data[,"X"] <- 1*(plot.data[,"X"])
        plot.data[,"Y"] <- 1*(plot.data[,"Y"])
        xlab <- xlab
        ylab <- ylab
      }
      
      if (input$title_x != "") {
        xlab <- input$title_x
      }
      
      if (input$title_y != "") {
        ylab <- input$title_y
      }
      values$x_title <- xlab
      values$y_title <- ylab
      show_legend <- if_else(input$show_legend == "显示", TRUE, FALSE)
      if (show_legend & input$legend_position == "右边") {
        legend_position <- "right"
      } else if (show_legend & input$legend_position == "上边") {
        legend_position <- "top"
      } else {
        legend_position <- "none"
      }
      
      cor <- round(cor(plot.data[,"X"], plot.data[,"Y"]), 3)
      cor <- paste("R =", cor)
      
      themeType <- input$bg_theme
      values$filter_data <- plot.data
      p <- ggplot() +
        geom_point(
          data = plot.data,
          aes(x = X, y = Y, color = Type),
          size = input$dotsize,
          alpha = input$alpha
        ) + base::eval(call(themeType)) + 
        xlab(values$x_title) + ylab(values$y_title) + ggtitle(input$figuretitle) + 
        theme(
          legend.position = legend_position, 
          axis.title = element_text(
            size = (input$font_size + 3),
            family = input$font_family,
            color = "black"
          ),
          axis.text = element_text(
            size = input$font_size,
            family = input$font_family,
            color = "black"
          ),
          legend.title = element_text(
            size = input$font_size,
            family = input$font_family,
            color = "black"
          ),
          legend.text = element_text(
            size = input$font_size,
            family = input$font_family,
            color = "black"
          ),
          plot.title = element_text(hjust = 0.5),
          title = element_text(size = 15, face = "bold")
        ) +
        scale_color_manual(
          values = c(
            up = input$up_color,
            no_diff = input$unchange_color,
            down = input$down_color
          ),
          labels = c(up = input$up_label,
                     no_diff = input$unchange_label,
                     down = input$down_label)
        )
        
      
      if (input$show_r) {
        p <- p + annotate(geom = "text", x = input$r_x, y = input$r_y, label = cor, size = 8)
      } else {
        p <- p
      }
      
      if(input$show_point_label){
        req(input$point_size)
        p <- p+geom_text_repel(aes(x=plot.data$X,y=plot.data$Y,label=plot.data$ID),size=input$point_size,box.padding = 1)
        
      }
      values$plot <- p
      return(p)
    }
    

  })
  
  ##下载示例文件
  output$downloaddemo_file <- downloadHandler(
    filename = function(){
      paste0('demo_scatterplot.xlsx')
    },
    content = function(file){
      file.copy(paste0(original_dir,"/www/Demo_ScatterPlot_label.xlsx"), file)
    }
  )
  
  #下载示例图片
  output$download_pdf <- downloadHandler(
    filename = "Scatter_diagram.pdf",
    content = function(file) {
      ggsave(
        filename = file,
        plot = values$plot,
        width = input$plot_size$width/80,
        height = input$plot_size$height/80
      )
    }
  )
  output$download_png <- downloadHandler(
    filename = "Scatter_diagram.png",
    content = function(file) {
      png(file,width = input$plot_size$width,height = input$plot_size$height)
      print(values$plot)
      dev.off()
    }
  )
  
  ##下载参数
  output$save_para <- downloadHandler(
    filename = function() {
      paste0("demo_plot_values_matrix",".xlsx")
    },
    content = function(file){
      write.xlsx(values$plot_values_matrix,file=paste0(tempdir(),"/demo_plot_values_matrix.xlsx"),sheetName = "Sheet1",colNames = T,rowNames = F)
      file.copy(paste0(tempdir(),"/demo_plot_values_matrix.xlsx"), file)
    },
    contentType = "xlsx"
  )
}

# Run the application
shinyApp(ui = ui, server = server)
