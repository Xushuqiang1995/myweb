rm(list=ls())
library(shiny)
library(shinydashboard)
library(DT)
library(shinyjqui)##图片拖拽大小
library(shinythemes)
library(shinyWidgets)
library(shinyjs)
library(shinycssloaders)#等待条
library(shinydisconnect)#自定义断开页面
#library(shinylogs)##logs记录
#library(RXSpreadsheet)##可编辑表格
#library(plotly)
#library(RCurl)
#library(jsonlite)
#library(shinyFiles)
# author: Wanglu
# Date: 2022/03/07
# update:2022/04/18

ui=function(request){
    #--------------- Header ------------------------
    header=dashboardHeader(title = "Correlation Heatmap",titleWidth = 200)
    #--------------- Sidebar ------------------------
    sidebar=dashboardSidebar(
        disconnectMessage(
            text = "若上传文件或设置参数运行后出现此界面，表明你上传的数据可能有问题，程序已停止运行。请点击‘Refresh’重新打开工具查看教程，严格按照教程示例数据修改你的文件及格式，再做尝试！",
            refresh="Refresh"
        ),
        actionButton("disconnect","Disconnect the app"),
        collapsed =TRUE,
        useShinyjs(),
        width=200,
        sidebarMenu(id="tabs",menuItem("Correlation",tabName="tabplot",icon=icon("barcode")))
    )
    #--------------- Body ------------------------
    body <- dashboardBody(
        theme = shinytheme(theme="flatly"),
        tabItems(
            tabItem(
                "tabplot",
                fluidRow(
                    column(
                        4,h4("参数"),tabsetPanel(
                            tabPanel(
                                "数据&参数",br(),
                                p("注意:上传文件前请先查看最右侧使用教程中数据输入部分的说明！"),
                                div(style="padding-left: 5px; padding-top: 25px; padding-right: 5px; margin-bottom: 5px;max-height: 750px; overflow-x: hidden;overflow-y: auto;",
                                     fluidRow(
                                    column(8,fileInput(inputId = "file_MS",accept = c(".txt",".csv",".xls",".xlsx"),label="MS_identified_information.txt",placeholder = "xlsx/txt/csv/xls",buttonLabel = "上传MS表")),
                                    column(4,br(),style='float:left;',tags$h5(tags$a(icon("download"),downloadLink("downloaddemo_MS","下载示例MS表"))))
                                ),
                                fluidRow(
                                  column(8,fileInput(inputId = "file_group",accept = NULL,label="repeat_list",placeholder = "xlsx/txt/csv/xls/无后缀名",buttonLabel = "上传分组文件")),
                                  column(4,br(),style='float:left;',tags$h5(tags$a(icon("download"),downloadLink("downloaddemo_group","下载示例分组文件"))))
                                ),
                                fluidRow(column(12,radioGroupButtons(inputId = "upradios",label = "请选择数据定量的方法",choices = c("Quantitative.value", "LFQ intensity", "Intensity", "iBAQ"),
                                                           selected="Quantitative.value",checkIcon = list(yes = icon("ok",lib = "glyphicon"))))),
                                br(),
                                fluidRow(
                                    column(6,pickerInput(inputId="cormethod",label="相关性计算方法/Correlation mentod:",choices=c("pearson","spearman","kendall"))),
                                    column(6,uiOutput('cluster_or_not')),
                                ),
                                fluidRow(
                                    
                                    column(6,uiOutput('cluster_sample')),
                                    column(4,uiOutput("cluster_numbers"))
                                   
                                ),
                                uiOutput('cluster_color_width'),
                               
                                fluidRow(

                                    column(6,pickerInput("cor_num_show","是否展示数字",choices=c('yes','no'),selected = 'yes')),
                                    column(6,uiOutput("number_color"))
                                   
                                ),
                                uiOutput("pcc_method_type_UI"),
                                uiOutput("pcc_color_break"),
                                h5(strong("颜色选择：")),
                                fluidRow(
                                    column(4,colourpicker::colourInput("high","High","#FF0000")),
                                    column(4,colourpicker::colourInput("medium","Medium","#F0E7E7")),
                                    column(4,colourpicker::colourInput("low","Low","#4682B4"))
                                ),
                                h5(strong("字号")),
                                fluidRow(
                                    column(4,numericInput("tl.cex","标签字体大小：",value=1.2,step=0.1)),
                                    column(4,numericInput("number.cex","展示数字大小：",value=1,step=0.1)),
                                    column(4,numericInput("cl.cex","图例字体大小：",value=0.8,step=0.1))
                                ),
                                fluidRow(
                                    column(4,uiOutput("col_angel")),
                                    column(4,uiOutput("label_legend")),
                                    column(4,uiOutput('label_line_annotation'))
                                )
                                    )
                               
                            ),
                            tabPanel(
                                "已传数据预览",br(),
                                p(style="color:black","注意：表格仅展示上传数据的前3行"),
                                div(style="padding-left: 5px; padding-top: 25px; padding-right: 5px; margin-bottom: 5px;max-height: 750px; overflow-x: hidden;overflow-y: auto;",
                                    dataTableOutput('preview_MS'),
                                dataTableOutput('preview_repeat_list')
                                    )
                                
                            )
                        )
                    ),
                    column(
                        5,h4("结果"),
                        tabsetPanel(
                            tabPanel(
                                "图片&下载",
                                div(style = "background-color: rgba(255,255,255,0); padding-left: 5px; padding-top: 25px; padding-right: 5px; margin-bottom: 5px;",
                                    fluidRow(
                                    column(3,textInput("plotfilename",label="下载文件名:",value="corr_plot")),
                                    column(2,style='padding-left: 3px',numericInput("pic_width","图片宽度",value = 650,min = 400,max = 800)),
                                    column(2,style='padding-left: 3px',numericInput("pic_height","图片高度",value = 650,min = 400,max = 800)),
                                    column(2,style='padding: 24px;padding-left: 3px',downloadButton("plotcorr.save",label="Export pdf",width=NULL)),
                                    column(2,style='padding: 24px;padding-left: 3px',downloadButton("plotcorrpng.save",label="Export png",width=NULL))
                                ),
                                
                                ####################拖动改变图片的大小延迟太高 放弃
                                # withSpinner(jqui_resizable(plotOutput("pearson", width = "650px", height = "600px")),type=4),
                                uiOutput('plot_pic_result'),
                                uiOutput("number_width_height")
                                    
                                )
                               
                            ),
                            tabPanel(
                                "绘图数据",br(),
                                p(style="color:black","注意:展示全部行数选择-1,点击CVS或Excel，可下载当前数据数据"),
                                dataTableOutput("tablecorr")
                            ),
                            tabPanel(
                                "绘图参数预览",br(),
                                p("下方为本次绘图主要参数，可点击导出按钮保存到本地，便于后期查找或重现。"),
                                downloadButton("save_plot","导出参数",width=NULL),
                                tableOutput('plot_values_table')
                            )
                        )
                    ),
                    column(
                        3,h4("说明"),
                        tabsetPanel(
                            tabPanel(
                                "使用教程",br(),
                                div(
                                    style="margin:0px 12px;max-height: 750px; overflow-y: auto;",
                                    h4(tags$b("简介：")),
                                    p("相关性分析能够展示样本内重复性和样本间的相关程度，是实验质控的重要指标。组内重复间相关性系数越大，组间样本相关性系数越小，表明实验效果越好。"),
                                    p(strong("1. 一般而言，绘制皮尔森相关性图时，TQTP类型项目使用'Quantitative.value'数据；LQ类型项目使用'LFQ intensity'(当搜库软件为Maxquant时)或者'Intensity'(当搜库软件为Proteome Discoverer时)；LP类型项目使用'Intensity'。LP类型项目的MS表中暂无Intensity值，如需要Intensity值，可联系技术支持或销售。")),
                                    p("2. 'Quantitative.value'为蛋白相对表达值，此工具默认使用表达值绘制皮尔森图。可先查看MS表中是否存在对应数值列(列名开头与上述后3个选项字符相同)，再根据项目类型选择准确的数值列。"),
                                    p("3. If correlation method is 'kendall' or 'spearman', Kendall's tau or Spearman's rho statistic is used to estimate a rank-based measure of association. These are more robust and have been recommended if the data do not necessarily come from a bivariate normal distribution"),
                                    h4(tags$b("输入数据：")),
                                    p("1.分析支持的文件格式包括txt(制表符分隔)文本文件、csv(逗号分隔)文本文件、以及Excel专用的xlsx格式，同样支持旧版Excel的xls(Excel 97-2003 )格式。"),
                                    p("2.输入数据应为MS表和分组文件repeat_list文件。"),
                                    p("3.点击“下载示例MS表/下载示例分组文件“，即可下载分析所需示例文件。"),
                                    p(strong("MS表:"),"(图片太小可鼠标右键'在新标签页中打开图像)"),
                                    div(align="center",tags$img(src="MS.png",height="100%",width="100%")),
                                    br(),
                                    p(strong("repeat_list分组文件:")),
                                    div(align="center",tags$img(src="repeat_list.png",height="100%",width="100%")),
                                    p("数据上传成功后在“已传数据预览”页面可以看到自己上传的数据。"),
                                    h4(tags$b("参数调整及说明：")),
                                    p(strong("相关性计算方法："),"选择计算相关性系数的算法。您以调整使用不同的相关性计算方法，得到样本内差异最小，样本间差异最大的图片，一般情况下，表达量数据的相关性计算方法首选pearson、spearman方法"),
                                    p(strong("是否聚类："),"聚类分析可以将有较大相似性的样本归为一类。no代表不聚类，yes代表使用R语言hclust()对样本进行聚类"),
                                    p(strong("聚类方法："),"您可以尝试多种聚类方法，最终选择效果较好的方法输出结果"),
                                    p(strong("聚类框数目："),"您可以选择将样本聚类为几大类，当且仅当‘是否对样本聚类’选项为‘yes’时才有意义"),
                                    p(strong("聚类框颜色："),"您可以调整聚类框的颜色，当且仅当‘是否对样本聚类’选项为‘yes’时才有意义"),
                                    p(strong("聚类框宽度："),"您可以调整聚类框的宽度，当且仅当‘是否对样本聚类’选项为‘yes’时才有意义"),
                                    p(strong("是否展示数字："),"是否在图片上展示相关性数据"),
                                    p(strong("数字颜色："),"您可以调整样图片中相关性数据的字体颜色"),
                                    p(strong("表现形式："),"图片可以利用不同的表现形式来展示相关系数。您可以通过调整使用不同的表现形式来展示图片，最终选取客户最满意的图片"),
                                    p(strong("展示类型："),"相关性热图是根据左上-右下对角线对称的图片，您可以选择展示全部图片、展示左下部分或展示右上部分"),
                                    p(strong("颜色选择："),"您可以选择喜欢的颜色来绘制图片，High代表相关性强的颜色，Low代表相关性弱的颜色"),
                                    p(strong("字号："),"您可以调整样本标签、相关性系数、图例的字号大小"),
                                    p(strong("列名角度："),"您可以调整样图片列名标签的角度"),
                                    p(strong("图例位置："),"您可以改变图例的位置使图片更美观"),
                                    p(strong("展示边框颜色："),"您可以自由选择每一个方格的边框颜色"),
                                    h4(tags$b("其他：")),
                                    p("1.在“下载文件名“中输入图片命名，点击'Export pdf'、'Export png'可下载pdf、png图片"),
                                    p("2.在“绘图数据界面“可下载样本间相关性系数表格数据"),
                                    p("3.在绘图参数导出界面，可下载绘制该图片的相关参数列表数据")
                                )
                            ),
                            tabPanel(
                                "常见问题",br(),
                                p(strong("1.如何修改样本名称？")),
                                p("RE：请在repeat_list中修改好样本名后重新上传文件，请注意样本名称与MS表中的对应顺序"),
                                p(strong("2.样本内重复和样本间的相关性系数都很高，颜色梯度无法区分怎么办？")),
                                p("RE：建议1：‘展示边框颜色’选择‘NA’，使得颜色对比更加清晰"),
                                p("RE：建议2:‘表现形式’选择‘pie’，并且‘图例位置’选择‘不展示图例’，如下图所示"),
                                p("RE：建议3:调整色阶"),
                                div(align="center",tags$img(src="demo_pie.png",height="100%",width="100%"))
                            ),
                            tabPanel(
                                "工具开发者",br(),
                                p("版本号：v1.0.0"),
                                p("开发者：景杰生信部wl"),
                                p("维护者：景杰生信部wl"),
                                p("发布日期：2022-04-30"),
                                br(),
                                p("更新版本：v1.0.1"),
                                p("更新日志：增加聚类功能-->by wl"),
                                p("更新日期：2022-05-24"),
                                br(),
                                p("更新版本：v1.0.2"),
                                p("1.根据不同类型的项目数据选择不同的数据预处理方法-->by lhd"),
                                p("2.增加色阶、显示分组信息等功能并完善绘图参数内容-->by lhd"),
                                p("更新日期：2022-09-13")
                            )
                        )
                    )
                )
            )
        )
    )
    #--------------- Page ------------------------
     dashboardPage(title = 'corrWebapp',skin = "blue",header,sidebar, body)
}