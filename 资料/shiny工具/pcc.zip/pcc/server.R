rm(list=ls())
library(shiny)
library(DT)
library(shinyjqui)
library(readxl)
library(openxlsx)
library(RColorBrewer)
library(stringr)
library(shinycssloaders)
library(shinyjs)
library(corrplot)
library(corrgram)
library(data.table)
library(tidyverse)
library(pheatmap)
#library(showtext)#字体
#library(extrafont)#字体
#library(extrafontdb)#字体
# author: Wanglu
# Date: 2022/01/24
# update: 2022/03/24

server=function(input,output,session){
    #------------------------ reactive --------------------------
    options(shiny.maxRequestSize=5000*1020^2)
    jqui_bookmarking()
    values=reactiveValues(data=NULL,raw_group_data=NULL,group_data=NULL,corp=NULL,data_preview=NULL,plot_values_matrix=NULL,data_cor=NULL)
    print(getwd())
    print(tempdir())
    original_dir=getwd()
    
    
    
    
    
    
    #######上传文件
    file_input <- reactive({
        if(!is.null(input$file_MS) & !is.null(input$file_group)){
            showNotification("文件已上传，正在绘图中，请稍等......",type="warning",duration=10)
          
          
          #######上传MS表
            inFile=input$file_MS
            if((str_detect(inFile$name,pattern=".xlsx$"))|(str_detect(inFile$name,pattern=".xls$"))){
                sheets=readxl::excel_sheets(path=inFile$datapath)
                if(length(sheets)>1){
                    showModal(modalDialog(
                        p("请上传仅有一个sheet的xlsx/xls格式的表格，或是txt，csv格式文件")
                        )
                    )
                }else{
                    data_up<-read_excel(inFile$datapath,sheet=1,col_names=T)
                    data_up=as.data.frame(data_up)
                    #row.names(data_up)=data_up[,1]
                    #data_up=subset(data_up,select=-1)
                    values$data=data_up
                }
            }
            else if(str_detect(inFile$name,pattern=".csv$")){
                values$data=read.csv(file=inFile$datapath,header=T,stringsAsFactors=T,row.names=NULL,encoding='UTF-8',check.names=F,sep=',')
            }
            else{
              values$data=read.table(file=inFile$datapath,header=T,stringsAsFactors=T,row.names=NULL,sep='\t',encoding='UTF-8',check.names=F,quote="")
              }
        
              ############上传repeat_list分组文件 
      if((str_detect(input$file_group$name,pattern=".xlsx$")) | (str_detect(input$file_group$name,pattern=".xls$"))){
        data_repeat_list <- read_excel(input$file_group$datapath,col_names=F,sheet=1) %>%
          data.frame()
        colnames(data_repeat_list) <- c('V1','V2')
        values$raw_group_data <- data_repeat_list
        
        process_group_data <- data_repeat_list
        process_group_data <- process_group_data[!(process_group_data$V1 %like% "/" | process_group_data$V2 %like% "/"),]
        process_group_data <- process_group_data %>% separate_rows(V1,sep = '\\,') %>% data.frame()
        values$group_data <- process_group_data
      }
      else if(str_detect(input$file_group$name,pattern = '.csv$')){
        values$raw_group_data <- read.csv(file=input$file_group$datapath,sep = ',',header = F)
        
        process_group_data <- values$raw_group_data
        process_group_data <- process_group_data[!(process_group_data$V1 %like% "/" | process_group_data$V2 %like% "/"),]
        process_group_data <- process_group_data %>% separate_rows(V1,sep = '\\,') %>% data.frame()
        values$group_data <- process_group_data
      }
      else if(str_detect(input$file_group$name,pattern = '.txt$')){
        values$raw_group_data <- read.csv(file=input$file_group$datapath,sep = '\t',header = F)
        
        process_group_data <- values$raw_group_data
        process_group_data <- process_group_data[!(process_group_data$V1 %like% "/" | process_group_data$V2 %like% "/"),]
        process_group_data <- process_group_data %>% separate_rows(V1,sep = '\\,') %>% data.frame()
        values$group_data <- process_group_data
        # print(values$group_data)
      }
      else{
        values$raw_group_data <- read.csv(file=input$file_group$datapath,sep = '\t',header = F)
        
        process_group_data <- values$raw_group_data
        process_group_data <- process_group_data[!(process_group_data$V1 %like% "/" | process_group_data$V2 %like% "/"),]
        process_group_data <- process_group_data %>% separate_rows(V1,sep = '\\,') %>% data.frame()
        values$group_data <- process_group_data
      }
            
            }
          
    
      
      
    })
    
    
    # observeEvent(input$intro,{removeModal()})
    output$preview_MS=DT::renderDataTable({
      file_input()
        datatable(values$data[1:3,],extensions='Buttons',class="row-border hover",options=list(pageLength=10,lengthMenu=c(10,20,50,100,-1),dom='rt',scrollX=TRUE))
    })
    
    output$preview_repeat_list=DT::renderDataTable({
      file_input()
      datatable(values$raw_group_data,extensions='Buttons',class="row-border hover",options=list(pageLength=10,lengthMenu=c(10,20,50,100,-1),dom='rt',scrollX=TRUE))
    })
    
    
    ###########################根据用户选择不同的数据来源来展示不同的UI界面##########################################
    

    output$pcc_method_type_UI <- renderUI({
      
      if(input$upradios =='Quantitative.value'){
        fluidRow(
          column(6,pickerInput(inputId="method",label="表现形式：",choices=c('color','circle','square','ellipse','number','pie','shade'))),
          column(6,awesomeRadio("type","展示类型",choices=c("full","upper","lower"),selected='full',inline = TRUE,checkbox = TRUE))
        )
      }
      else{
        NULL
      }
    })
    
    output$pcc_color_break <- renderUI({
      if(input$upradios !='Quantitative.value'){
        fluidRow(
          column(6,pickerInput(inputId="change_break_or_not",label="是否更改色阶",choices=c("no","yes"),selected = 'no')),
          column(6,uiOutput('break_min'))
        )
      }
    })

    output$break_min <- renderUI({
      if(input$upradios !='Quantitative.value'){
        if(input$change_break_or_not=='yes'){
          numericInput('color_break_min','输入色阶范围最小值',min = -1,max = 1,value = 0.8,step = 0.01)
        }
      }
    })

    
    output$cluster_or_not <- renderUI({
      if(input$upradios =='Quantitative.value'){
      pickerInput("order","是否聚类",choices=c('hclust','no'),selected = 'no')
      }
      else{
        awesomeRadio('clust','是否聚类',choices = c('yes','no'),selected = 'no',inline = T,checkbox = TRUE)
      }
    })
    # req(input$order)
   
    output$cluster_sample <- renderUI({
      if(input$upradios =='Quantitative.value'){
      req(input$order)
      if(input$order!='no'){
        pickerInput("hclust.method","聚类方法",choices=c('ward.D2', 'ward.D', 'single', 'complete', 'average', 'mcquitty', 'median', 'centroid'))
      }
      }
      else{
        req(input$clust)
      if(input$clust!='no'){
        pickerInput("hclust.method","聚类方法",choices=c('ward.D2', 'ward.D', 'single', 'complete', 'average', 'mcquitty', 'median', 'centroid'))
      }
      }
      
    })
    
    
    output$cluster_numbers <- renderUI({
      if(input$upradios =='Quantitative.value'){
        req(input$order)
      if(input$order!='no'){
      numericInput("addrect","聚类框数目",min=1,max = length(values$group_data$V1),value=2,step=1)
      }
      }
      else{
        req(input$clust)
      if(input$clust!='no'){
        numericInput("addrect","聚类簇个数",min=1,max = length(values$group_data$V1),value=2,step=1)
      }
      }
      
    })
    
    
    output$cluster_color_width <- renderUI({
      req(input$order)
      
      if(input$upradios =='Quantitative.value'){
      if(input$order!='no'){
        fluidRow(
        column(6,colourpicker::colourInput("rect.col","聚类框颜色","black")),
        column(6,numericInput("rect.lwd","聚类框宽度",value=3,step=0.1))
      )
      }
      }
      
    })
    
    
    output$number_color <- renderUI({
      if(input$cor_num_show=='yes'){
        awesomeRadio("addCoef.col","数字颜色",choices=c("black","grey","white"),selected="black",inline = TRUE,checkbox = TRUE)
      }
    })
    
    
    output$col_angel <- renderUI({
      if(input$upradios =='Quantitative.value'){
        numericInput("tl.srt","列名角度:",value = 90,step = 5,min = 0,max=90)
      }
      else{
        pickerInput('tl.srt',"列名角度",choices = c(0,45,90,270,315),selected = 270)
      }
    })
    
    
    output$label_legend <- renderUI({
      if(input$upradios =='Quantitative.value'){
        pickerInput("cl.pos","图例位置",choices=c("右侧","下侧","不展示图例"))
      }
      else{
        pickerInput('show_legend_or_not',"是否显示图例",choices = c("是","否"),selected = "是")
      }
    })
    
    
    
    
    output$label_line_annotation <- renderUI({
      if(input$upradios =='Quantitative.value'){
        pickerInput("grid.col_show","展示边框颜色",choices=c('NA','gray','black'))
      }
      else{
        pickerInput('label_line_annotation',"是否显示组别",choices = c("是","否"),selected = "是")
      }
    })
    
   
    
    
    
    
    #################################################交互式参数(其实也没必要这样写  完全可以写在plot函数里  不需要reactive  绘图的时候直接用就可以了)
    ## cluster
    order.finalre=reactive({
        if(input$order=='hclust'){
            order.final="hclust"
        }else{
            order.final="original"
        }
        return(order.final)
    })
    #get cor_num's color
    cor_num_color=reactive({
        if(is.null(values$data)){
            values$corp=NULL
            num_color=NULL
        }else{
            if(input$cor_num_show=='no'){
                num_color=NULL
            }else{num_color=input$addCoef.col}
        }
        return(num_color)
    })
    #the position of legend
    legend.pos=reactive({
        if(input$cl.pos=="右侧"){
            legend_position='r'
        }else if(input$cl.pos=="下侧"){
            legend_position='b'
        }else{legend_position='n'}
        return(legend_position)
    })
    
    
    
    ####################################################################################################绘图+顺便保存图片
    output$pearson <- renderPlot({
      file_input()
      if(!is.null(input$file_MS) & !is.null(input$file_group)){
          ######交互式参数调用reactive
          num_color=cor_num_color()
          legend_position=legend.pos()
          order.if=order.finalre()
      
      data <- values$data
      id <- values$group_data$V1
      id <- as.vector(id)
      if(input$upradios=='Quantitative.value'){
        data <- data[,id]
        row_sub <- apply(data, 1, function(row) all(row !=0 ))
        data_cor <- cor(log2(data[row_sub,]), method = input$cormethod, use = 'complete.obs')
        data_cor <- round(data_cor,3)
        data_cor <- as.matrix(data_cor)
        
        #########绘图数据预览
        values$data_preview <- data_cor
        
        ###保存相关性图片 png格式
        outfile=paste(tempdir(),'pearson_correlation.png',sep="/")
        png(outfile, width =input$pic_width, height =input$pic_height)
        # png(outfile, width =input$pearson_size$width, height =input$pearson_size$height)
        
        # ?corrplot
        corrplot(
                  data_cor,      #绘图数据
                  method=input$method,   #每一个框（数值）的不同表现形式
                  col=colorRampPalette(c(input$low,input$medium,input$high))(100),##渐变的三个背景颜色选择
                  is.corr=T,   #数据数据是否为相关矩阵
                  add=F,  #不添加图形
                  diag=T, #显示对角线
                  outline=F,   #显示每一个方框是否需要黑线框住
                  addCoef.col=num_color,  ##是否展示数字
                  addgrid.col=input$grid.col_show,  #展示边框颜色
                  addCoefasPercent=F,   ##是否将数值乘以100展示
                  order=order.if,   #是否对样本进行聚类
                  hclust.method=input$hclust.method,   #聚类的方法选择  差别不大 。。。。。
                  addrect=input$addrect,  ##分层聚类的个数
                  rect.col=input$rect.col,   #聚类框的颜色
                  rect.lwd=input$rect.lwd,  ##聚类框的宽度
                  tl.cex=input$tl.cex,   #标签字体大小
                  tl.col='black',   ##标签颜色
                  tl.srt=input$tl.srt,###此处列名角度存在问题
                  cl.cex=input$cl.cex,   #图例字体大小
                  number.cex=input$number.cex,  #展示数字字体大小
                  cl.pos=legend_position,   ##图例的位置
                  type=input$type   ##选择展示上半部分还是下半部分
                  ) %>% try(silent = T)
        dev.off()
        
        
        
        ###保存相关性图片 pdf格式
        outfile=paste(tempdir(),'pearson_correlation.pdf',sep="/")
        # png(outfile, width =input$pearson_size$width, height =input$pearson_size$height)
        pdf(outfile, width =input$pic_width /80, height =input$pic_height /80)
        
        corrplot(
          data_cor,      #绘图数据
          method=input$method,   #每一个框（数值）的不同表现形式
          col=colorRampPalette(c(input$low,input$medium,input$high))(100),##渐变的三个背景颜色选择
          is.corr=T,   #数据数据是否为相关矩阵
          add=F,  #不添加图形
          diag=T, #显示对角线
          outline=F,   #显示每一个方框是否需要黑线框住
          addCoef.col=num_color,  ##是否展示数字
          addgrid.col=input$grid.col_show,  #展示边框颜色
          addCoefasPercent=F,   ##是否将数值乘以100展示
          order=order.if,   #是否对样本进行聚类
          hclust.method=input$hclust.method,   #聚类的方法选择  差别不大 。。。。。
          addrect=input$addrect,  ##分层聚类的个数
          rect.col=input$rect.col,   #聚类框的颜色
          rect.lwd=input$rect.lwd,  ##聚类框的宽度
          tl.cex=input$tl.cex,   #标签字体大小
          tl.col='black',   ##标签颜色
          tl.srt=input$tl.srt,###此处列名角度存在问题
          cl.cex=input$cl.cex,   #图例字体大小
          number.cex=input$number.cex,  #展示数字字体大小
          cl.pos=legend_position,   ##图例的位置
          type=input$type   ##选择展示上半部分还是下半部分
        ) %>% try(silent = T)
        dev.off()
        
        #网页前端展示
        return(corrplot(
          data_cor,      #绘图数据
          method=input$method,   #每一个框（数值）的不同表现形式
          col=colorRampPalette(c(input$low,input$medium,input$high))(100),##渐变的三个背景颜色选择
          is.corr=T,   #数据数据是否为相关矩阵
          add=F,  #不添加图形
          diag=T, #显示对角线
          outline=F,   #显示每一个方框是否需要黑线框住
          addCoef.col=num_color,  ##是否展示数字
          addgrid.col=input$grid.col_show,  #展示边框颜色
          addCoefasPercent=F,   ##是否将数值乘以100展示
          order=order.if,   #是否对样本进行聚类
          hclust.method=input$hclust.method,   #聚类的方法选择  差别不大 。。。。。
          addrect=input$addrect,  ##分层聚类的个数
          rect.col=input$rect.col,   #聚类框的颜色
          rect.lwd=input$rect.lwd,  ##聚类框的宽度
          tl.cex=input$tl.cex,   #标签字体大小
          tl.col='black',   ##标签颜色
          tl.srt=input$tl.srt,###此处列名角度存在问题
          cl.cex=input$cl.cex,   #图例字体大小
          number.cex=input$number.cex,  #展示数字字体大小
          cl.pos=legend_position,   ##图例的位置
          type=input$type   ##选择展示上半部分还是下半部分
        ) %>% try(silent = T))
      }
      else if(!is.na(grep(input$upradios,colnames(data))[1])){
        newid <- paste(input$upradios,id,sep = ' ')
        data_cor <- subset(data,select=newid)
        colnames(data_cor) <- id
        data_cor[data_cor==0] <- NA
        data_cor <- log10(data_cor)
        data_cor <- as.data.frame(data_cor)
        td <- corrgram(data_cor,cor.method=input$cormethod,type='data',order=FALSE)
        t = round(td,3)
        t <- as.matrix(t)
        
        ###绘图数据预览
        values$data_preview <- t
        
        req(input$clust)
        if (input$clust=='no'){
          clust =FALSE
        }else{
          clust = TRUE
        }
        
        req(input$cor_num_show)
        if (input$cor_num_show=='yes'){
          show_number <- T
        }
        else{
          show_number <- F
        }
        
        my_color <- colorRampPalette(c(input$low,input$medium,input$high))(100)
        
        
        req(input$change_break_or_not)
        if(input$change_break_or_not=='yes'){
          req(input$color_break_min)
          breaksList <- seq(input$color_break_min, 1, length.out=100)
        }
        else{
          breaksList=NULL
        }
        
        annotation_col <- values$group_data
        colnames(annotation_col) <- c("sample","group")
        rownames(annotation_col) <- annotation_col$sample
        annotation_col <- annotation_col[2]
        # print(annotation_col)
        
        req(input$show_legend_or_not)
        if(input$show_legend_or_not=='是'){
          show_legend_label=T
        }
        else{
          show_legend_label=F
        }
        
        req(input$label_line_annotation)
        if(input$label_line_annotation=='是'){
          anno_col=annotation_col
        }
        else{
          anno_col=NULL
        }
        
        
        ######################保存pheatmap图片（png&pdf）
        outfile=paste(tempdir(),'pearson_correlation.png',sep="/")
        outfilepdf=paste(tempdir(),'pearson_correlation.pdf',sep="/")
        
        
        # print(t)
        ###############是否聚类 是否展示数字 展示数字的颜色 展示数值的后几位小数 聚类的方法 聚类簇的个数 颜色选择 字号的选择（标签字体大小 展示数字的大小  图例字体大小  列名的角度 图例的位置 展示边框颜色）
        ###########是否显示行注释（列注释） 单元格大小调整
        pic <- pheatmap(t,
                        cluster_rows = clust,
                        cluster_cols =clust,
                        display_numbers = show_number,
                        number_color = input$addCoef.col,
                        number_format="%.3f",
                        clustering_method = input$hclust.method,
                        cutree_rows = input$addrect,
                        cutree_cols = input$addrect,
                        color = my_color,
                        breaks = breaksList,fontsize = (input$cl.cex)*15,
                        fontsize_number = (input$number.cex)*16,
                        fontsize_row = (input$tl.cex)*13,
                        fontsize_col = (input$tl.cex)*13,
                        annotation_col = anno_col,
                        legend = show_legend_label,
                        angle_col = input$tl.srt) %>% try(silent = T)
        
        ggsave(filename = outfile,pic,width =input$pic_width/80, height =input$pic_height/80) %>% try(silent = T)
        ggsave(filename = outfilepdf,pic,width =input$pic_width/80, height =input$pic_height/80) %>% try(silent = T)
        
        return(pic)
        
      }
      
      
      ##################没有相应的数据列，弹出警告信息
      else{
        showNotification('没有找到对应的数据列，请检查数据后重试！',duration = 5)
      }
      
      }
      
        
      
      
    })
    
    
    output$plot_pic_result <- renderUI({
      plotOutput("pearson", width = paste0(input$pic_width,'px'), height = paste0(input$pic_height,'px'))
    })
    
    output$number_width_height <- renderUI({
      # p(paste("width:",input$pearson_size$width,"px height:",input$pearson_size$height,"px",sep=""))
      p(paste("width:",input$pic_width,"px height:",input$pic_height,"px",sep=""))
    })
    
    
    #######################绘图数据预览
    output$tablecorr <- DT::renderDataTable({
      datatable(values$data_preview,rownames = T,class="row-border hover",extensions = 'Buttons',
                options=list(pageLength = 20,lengthMenu = c(10, 20, 50, 100,-1),
                             dom = 'Blfrtip',scrollX=TRUE,buttons = c('csv', 'excel'),autoWidth = TRUE, 
                             columnDefs = list(list(width = "100px", targets = "_all"))))
      
    })
    
    
    
    
    
    
    
    ########################绘图参数预览 根据不同情乱设定不同的参数  参数用不到对于没有用的参数就设置为空
    observe({
      if(input$upradios=="Quantitative.value"){
        req(input$order)
      if(input$order=='no'){
        clust_method <- ""
        clust_number <- ""
        clust_color <- ""
        clust_width <- ""
      }
      else{
        clust_method <- input$hclust.method
        clust_number <- input$addrect
        clust_color <- input$rect.col
        clust_width <- input$rect.lwd
      }
        
        req(input$cor_num_show)
      if(input$cor_num_show=="yes"){
        number_color <- input$addCoef.col
      }
      else{
        number_color <- ""
      }
      plot_values_matrix <- rbind(
        c("R version:"," v3.6.3"),
        c("corrplot package version","0.84"),
        c("相关性计算方法",input$cormethod),
        c("是否聚类",input$order),
        c("聚类方法",clust_method),
        c("聚类框数目",clust_number),
        c("聚类框颜色",clust_color),
        c("聚类框宽度",clust_width),
        c("是否展示数字",input$cor_num_show),
        c("数字颜色",number_color),
        c("表现形式",input$method),
        c("展示类型",input$type),
        c("颜色选择-high",input$high),
        c("颜色选择-medium",input$medium),
        c("颜色选择-low",input$low),
        c("标签字体大小",input$tl.cex),
        c("展示数字大小",input$number.cex),
        c("图例字体大小",input$cl.cex),
        c("列名角度",input$tl.srt),
        c("图例位置",input$cl.pos),
        c("展示边框颜色",input$grid.col_show),
        c("图片宽度",input$pic_width),
        c("图片高度",input$pic_height)
      )
      }
      
      else{
        req(input$clust)
        if(input$clust=='no'){
          clust_method <- ""
          clust_number <- ""
        }
        else{
          clust_method <- input$hclust.method
          clust_number <- input$addrect
        }
        
        req(input$cor_num_show)
        if(input$cor_num_show=="yes"){
          number_color <- input$addCoef.col
        }
        else{
          number_color <- ""
        }
        req(input$change_break_or_not)
        if(input$change_break_or_not=='no'){
          break_min <- ""
        }
        else{
          break_min=input$color_break_min
        }
        plot_values_matrix <- rbind(
          c("R version:"," v3.6.3"),
          c("pheatmap package version","1.0.12"),
          c("相关性计算方法",input$cormethod),
          c("是否聚类",input$clust),
          c("聚类方法",clust_method),
          c("聚类簇个数",input$addrect),
          c("是否展示数字",input$cor_num_show),
          c("数字颜色",number_color),
          c("是否更改色阶",input$change_break_or_not),
          c("色阶范围最小值",break_min),
          c("颜色选择-high",input$high),
          c("颜色选择-medium",input$medium),
          c("颜色选择-low",input$low),
          c("标签字体大小",input$tl.cex),
          c("展示数字大小",input$number.cex),
          c("图例字体大小",input$cl.cex),
          c("列名角度",input$tl.srt),
          c("是否显示图例",input$show_legend_or_not),
          c("是否显示组别",input$label_line_annotation),
          c("图片宽度",input$pic_width),
          c("图片高度",input$pic_height)
        )
      }
   
      
      plot_values_matrix <- as.data.frame(plot_values_matrix)
      colnames(plot_values_matrix) <- c("keys","values")
      values$plot_values_matrix <- plot_values_matrix
      
    })
   
    
    
    
    #########绘图参数预览
    output$plot_values_table <- renderTable({
      return(values$plot_values_matrix)
    })
    
    
    
    
    
    
    #--------------------------- demo data download -------------------------------
    output$downloaddemo=downloadHandler(
        filename=function(){
            paste0("demo_corr_data",".xlsx")
        },
        content=function(file){
            file.copy(paste0(original_dir,'/www/demo_corr_data.xlsx'),file)
        }
    )
    
    
    ##############绘图参数下载
    output$save_plot=downloadHandler(
        filename=function(){
            paste0('plot_vlaues_matrix','.xlsx')
        },
        content=function(file){
            write.xlsx(values$plot_values_matrix,file=paste0(tempdir(),"/plot_values_matrix.xlsx"),sheetName='Sheet1',col.names=T,row.names=F)
            file.copy(paste0(tempdir(),'/plot_values_matrix.xlsx'),file)
        },
        contentType='xlsx'
    )
    
    
    
    
    
    
    ############下载结果图片
    output$plotcorr.save=downloadHandler(
        filename=function(){
            plotfilename='corr'
            if((input$plotfilename!="")&(input$plotfilename!=".")){
                plotfilename=input$plotfilename
            }
            paste0(plotfilename,'.pdf')
        },
        content=function(file){
            file.copy(paste(tempdir(),'pearson_correlation.pdf',sep="/"), file)
        },
        contentType='pdf'
    )
    output$plotcorrpng.save=downloadHandler(
        filename=function(){
            plotfilename='corr'
            if((input$plotfilename!="")&(input$plotfilename!=".")){
                plotfilename=input$plotfilename
            }
            paste0(plotfilename,'.png')
        },
        content=function(file){
            file.copy(paste(tempdir(),'pearson_correlation.png',sep="/"), file)
        },
        contentType='png'
    )
    observeEvent(input$disconnect,{session$close()})
}
