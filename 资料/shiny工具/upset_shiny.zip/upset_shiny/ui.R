## author: Shuqiang Xu
#  date: 2022/08/25
#  update: 2022/08/25
## Upset Plot

ui <- function(request) {
  # Header ---------------------------------------
  header <- dashboardHeader(title = "Upset Plot", titleWidth = 200)

  # Sidebar ---------------------------------------
  sidebar <- dashboardSidebar(
    collapsed = TRUE, ### 折叠侧边栏
    width = 200,
    sidebarMenu(
      id = "tabs",
      menuItem("upset", tabName = "tabplot", icon = icon("barcode"))
    )
  )
  # Body ---------------------------------------
  # theme_choices$ggthemes$solid <- NULL
  body <- dashboardBody(
    theme = shinytheme(theme = "flatly"),
    style = "background-color:white;", ## 将全局默认背景改为白色
    tabItems(
      tabItem(
        "tabplot",
        fluidRow(
          # 输入 ----------------------------------------------------------------------
          column(
            4, h4("参数"),
            tabsetPanel(
              #   Panel-1: 数据上传和调参 -------------------------------------------------------------
              tabPanel(
                "数据&参数",
                shinyFeedback::useShinyFeedback(),
                div(
                  style = "background-color: white; padding-left: 5px; padding-top: 25px; padding-right: 5px; margin-bottom: 5px;",
                  fluidRow( # 横排分割，宽度1-12整数，相对宽度无法精细
                    column(3, h5(strong("导入数据")), style = "padding-left: 35px"),
                    column(5, fileInput(inputId = "file", accept = c(".txt", ".csv", ".xls", ".xlsx"), label = NULL, placeholder = "xlsx/txt/csv/xls", buttonLabel = "选择文件")),
                    column(4, style = "float:left;", tags$h5(tags$a(icon("download"), downloadLink("downloaddemo", "下载示例文件"))))
                  ),
                  fluidRow(
                    column(12, selectInput(inputId = 'nsets', label = tippy('选择绘图集合', '默认选择表格中的所有列/集合'), choices = NULL, selected = NULL, multiple = TRUE, width = '100%'))
                  )
                ),
                div(HTML('<p><u>(主)柱状图调整</u></p>'),style='color:blue'), 
                div(
                  style = "background-color: white; padding-left: 5px; padding-right: 5px; margin-bottom: 5px;",
                  fluidRow(
                    column(3, numericInput(inputId = 'nintersects', label = tippy("柱子数量", '交集数量'), value = 20, min = 1, step = 1)),
                    column(3, selectInput(inputId = 'order_by', label = tippy("排序类型", 'freq:按照交集中元素个数排序，即垂直柱状图的高度; degree:按照交集中集合数量排序，即柱状图下方的交集矩阵图'), choices = c('freq', 'degree'), selected = 'freq')),
                    column(3, selectInput(inputId = 'decreasing', label = tippy("降序排列", 'freq:默认降序排列; degree:默认升序排列'), choices = c(TRUE, FALSE), selected = TRUE)),
                    column(3, numericInput(inputId = 'mb_ratio', label = tippy("柱状图比例", '柱状图在整个画板中的垂直占比，取值范围在0.3-0.7之间'), value = 0.7, min = 0.001, max = 1, step = 0.05)),
                  ),
                  fluidRow(
                    column(3, textInput(inputId = 'mainbar_y_label', label = 'Y轴标签', value = 'Counts of Intersections')),
                    column(3, numericInput(inputId = 'mainbar_y_label_size', label = 'Y轴标签字号', value = 1.5, step = 0.1)),
                    column(3, numericInput(inputId = 'mainbar_y_scale_size', label = 'Y轴数值字号', value = 2, step = 0.1)),
                    column(3, selectInput(inputId = 'show_numbers', label = '显示计数标签', choices = c('yes', 'no'), selected = 'yes')),
                  ),
                  fluidRow(
                    column(3, numericInput(inputId = 'mainbar_numeric_size', label = '计数标签字号', value = 1.5, step = 0.1)),
                    column(3, colourpicker::colourInput(inputId = 'main_bar_color', label = '柱状图颜色', value = 'gray23', showColour = 'background')),
                  ),
                  div(HTML('<p><u>(横)柱状图调整</u></p>'),style='color:blue'), 
                  fluidRow(
                    column(3, textInput(inputId = 'sets_x_label', label = 'X轴标签', value = 'Set Size')),
                    column(3, numericInput(inputId = 'sets_x_label_size', label = 'X轴标签字号', value = 2, min = 0)),
                    column(3, numericInput(inputId = 'sets_x_scale_size', label = 'X轴数值字号', value = 2, min = 0)),
                    column(3, numericInput(inputId = 'sets_x_scale_max', label = 'X轴数值长度', value = NULL, min = 0)),
                  ),
                  fluidRow(
                    column(3, numericInput(inputId = 'samlep_name_size', label = '样本名称字号', value = 2, min = 0)),
                    column(3, colourpicker::colourInput(inputId = 'sets_bar_color', label = '柱状图(横)颜色', value = 'gray23', showColour = 'background')),
                    column(3, selectInput(inputId = 'set_size_show', label = '显示计数标签(横)', choices = c(TRUE, FALSE), selected = TRUE)),
                    column(3, numericInput(inputId = "set_size_numbers_size", label = "计数标签字号", value = 7, step = 0.1, min = 0.2)),
                  ),
                  fluidRow(
                    column(3, numericInput(inputId = 'point_size', label = '点大小', value = 2.2, min = 0.1, step = 0.1)),
                    column(3, numericInput(inputId = 'line_size', label = '线宽度', value = 0.7, min = 0.1, step = 0.1)),
                  ),
                )
              ),

              #   Panel-2: 数据预览 -------------------------------------------------------------
              tabPanel(
                "数据预览",
                br(),
                p(style = "color:black", "注意: 表格仅展示上传数据的前15行"),
                br(),
                DT::dataTableOutput(outputId = "preview")
              )
            )
          ),
          # 输出 ----------------------------------------------------------------------
          column(
            5, h4("结果"),
            tabsetPanel(
              #   Panel-1: 图片&下载 -------------------------------------------------------------
              tabPanel(
                title = "图片&下载",
                br(),
                fluidRow(
                  column(2, selectInput(
                    inputId = "plot_format", label = NULL,
                    selected = "png", choices = c("png", "pdf", "tiff", 'svg')
                  )),
                  column(3, numericInputIcon("plot_height", label = NULL, value = 520, min = 10, step = 50, icon = list("图高"))),
                  column(3, numericInputIcon("plot_width", label = NULL, value = 640, min = 10, step = 50, icon = list("图宽")))
                ),
                fluidRow(
                  column(1, downloadButton("plot_download", label = "图形")),
                  column(2, downloadButton("plot_overlap_download", label = "Overlap数据集"), style = "padding-left: 40px"),
                  column(4, "参数调整后下方图片将实时更新", style = "color:#6BAED6;padding-top:10px", offset = 1),
                ),
                div(
                  style = "background-color: white; padding-left: 5px; padding-top: 25px; padding-right: 5px; margin-bottom: 5px;",
                  uiOutput(outputId = "plot_out_ui")
                ),
              ),
              #   Panel-2: 绘图参数详情 -------------------------------------------------------------
              tabPanel(
                "绘图参数",
                column(2, downloadButton("plot_config_download", label = "绘图参数"), style = "padding-left: 40px", offset = 1),
                br(),
                br(),
                p("下方为本次绘图主要参数，可点击导出按钮保存到本地，便于后期查找或重现。"),
                tableOutput("plot_config_table")
              )
            )
          ),
          # 操作指南 --------------------------------------------------------------------
          column(
            3, h4("说明"),
            tabsetPanel(
              #   Panel-1: 使用教程 -----------------------------------------------------------
              tabPanel(
                "使用教程",
                div(
                  style = "margin:0px 12px;max-height: 800px; overflow-y: auto;",
                  # a("查看教程",href="https://www.bilibili.com/video/av77519185/",target="_blank"),
                  h4(align = "center", tags$b("使用教程")),
                  h4(tags$b("简介：")),
                  p("upset图常用于展示样本间的交集情况。"),
                  h4(tags$b("适用范围：")),
                  p("适用于转录组、蛋白组、代谢组、微生物、基因组等差异数据的可视化，数据需包括样本(集合)名称及其元素"),
                  h4(tags$b("输入：")),
                  p("含有至少5列不同的样本(集合)"),
                  div(align = "center", tags$img(src = "p1.png", heigth = "100%", width = "100%")),
                  h4(tags$b("下载：")),
                  p("设置好图形的宽高后，选择png/pdf/tiff/svg图片格式后，下载保存图片"),
                  div(align = "center", tags$img(src = "p2.png", heigth = "90%", width = "90%")),
                  h4(tags$b("已传数据预览&绘图数据：")),
                  p("已传数据预览存在数据表明数据已上传成功，绘图数据为经过筛选和处理后的数据。"),
                  h4(tags$b("绘图参数导出：")),
                  p("主要介绍了使用的R版本及相应的包版本，以及前端参数设置详情，以便将来图形复现。"),
                  br(),
                  h4(tags$b("参数说明：")),
                  div(HTML('<p><u>(主)柱状图调整</u></p>'),style='color:blue'), 
                  p(strong("柱子数量："), "(主)柱状图的柱子数量。"),
                  p(strong("排序类型："), "freq:默认按照柱子高度从高往低排序；degree:默认按照交集情况矩阵中取交集集合数量从小到大排序。"),
                  p(strong("标签距离："), "样本名称(标签)到颜色填充中心旋转的距离。"),
                  p(strong("柱状图比例："), "主柱状图与下方交集矩阵关系的 "),
                  p(strong("Y轴标签："), "Y轴标签文本内容(名称)。"),
                  p(strong("Y轴标签字号："), "Y轴标签文本大小。"),
                  p(strong("Y轴数字字号："), "Y轴坐标轴上文本大小。"),
                  p(strong("显示计数标签："), "在主柱状图上显示柱状图高度(交集)数值。"),
                  p(strong("计数标签字号："), "在主柱状图上显示柱状图高度(交集)数值文本字号。"),
                  p(strong("柱状图颜色："), "在主柱状图上的填充颜色。"),
                  div(HTML('<p><u>(横)柱状图调整</u></p>'),style='color:blue'), 
                  p(strong("X轴标签："), "X轴标签文本内容(名称)。"),
                  p(strong("X轴标签字号："), "X轴标签文本大小。"),
                  p(strong("X轴数字字号："), "X轴坐标轴上文本大小。"),
                  p(strong("X轴数值长度："), "对X轴长度延伸。"),
                  p(strong("样本名称字号："), "set1/set2等集合名称字体大小设置。"),
                  p(strong("柱状图(横)颜色："), "在柱状图(横)上的填充颜色。"),
                  p(strong("显示技术标签(横)："), "在柱状图(横)上显示柱状图高度(交集)数值。"),
                  p(strong("计数标签字号："), "在柱状图(横)上显示柱状图高度(交集)数值文本字号。"),
                  p(strong("点大小："), "在主柱状图下方，表示集合交集情况的矩阵图中，点的大小。"),
                  p(strong("线宽度："), "在主柱状图下方，表示集合交集情况的矩阵图中，线的宽度。")
                )
              ),
              #   Panel-2: 常见问题 -----------------------------------------------------------
              tabPanel(
                "常见问题",
                br(),
                p(tags$b("Q1. 各参数控件排序杂乱，挤压显示不全。")),
                p("请全屏显示，并尽量使用谷歌浏览器登录云平台运行工具，部分浏览器可能不兼容，页面布局出现比例失调等情况。"),
                p(tags$b("Q2.页面变灰（即灰屏）无法操作问题排查")),
                p("出现此现象表示工具运行错误，主要有以下情况:1) 若从工具列表打开即出现灰屏，则可能是浏览器或网络问题；
                                    2) 若工具正常打开，但在传输数据后出现灰屏，则表明上传数据文件不符合要求，请按照教程，对照demo数据仔细排查，
                                    注意：表头是否符合要求（无缺失或#等），行列名是否有重复，数字列中是否有非数字字符（NA、#N/A等）。"),
                p("若自行排查后，依然出现灰屏，可联系对应销售经理或项目管理，并提供数据文件，我们会帮助排查。")
              ),
              #   Panel-3: 工具开发者 -----------------------------------------------------------
              tabPanel(
                "工具开发者",
                br(),
                p("版本号："),
                p("v0.0.1"),
                p("开发者："),
                p("景杰生信部xsq"),
                p("维护者："),
                p("景杰生信部zyl"),
                p("发布日期："),
                p("2022-06-06"),
                br(),
                br(),
              )
            )
          )
        )
      )
    )
  )
  dashboardPage(title = "UpsetWebapp", skin = "blue", header, sidebar, body)
}
