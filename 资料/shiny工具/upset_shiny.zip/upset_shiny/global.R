options(encoding = "utf-8")

# options(shiny.launch.browser = TRUE)
# Packages to library -----------------------------------------------------
## 数据处理和画图
library(tidyverse)              # 数据处理/转换
library(readxl)                 # 读取xlsx文件
library(ggthemes)               # 调整ggplot画图主题
library(dtplyr)                 # dtplyr::lazy_dt()将数据框转换成data.table类型进行运算处理，自动将dplyr/tidyr函数转换成data.table的处理函数
library(data.table)             # data.table的运行速度相比data.frame/tibble更快
library(UpSetR)                 # UpSetR::upset()函数画图
## Shiny展示效果拓展相关包
library(DT)                     # 用于输出数据框,以表格的形式呈现
library(shiny)                  # 涉及shiny的主要内容，fileInput()/tableOutput()等传参函数，observe()/req()/valid()等条件相应函数
library(shinydashboard)         # 不同于shiny的UI框架，由dashboardHeader()/dashboardSidebar()/dashboardBody()函数构成UI结构
library(shinythemes)            # 主要在ui端设置背景板颜色，在dashboardBody()函数内
library(esquisse)               # # 拖动选择变量的过程，即drag-and-drop，但是这里好像用不到;esquisse:::get_theme()获取ggplot所有的theme设置
library(shinyWidgets)           # 丰富shiny控件内容，通过shinyWidgets::shinyWidgetsGallery()可查看
library(shinyjs)                # shinyjs将JavaScript封装成函数，或者自己的js，可以直接调用
library(shinyFeedback)          # 如果文件类型/数据不符合要求，则给出警告反馈；主要用shinyFeedback::feedbackDanger()函数
library(tippy)                  # 当在UI端参数的标签需要更多文本解释，但不想显示的体现在UI界面，此时用悬浮显示，主要用tippy::tippy()参数，对input ui中的label参数设置
library(shinycssloaders)        # 程序运行加载（等待）条，主要应用在画图加载时，使用 withSpinner()，用于生成图过程中等待的
library(colourpicker)           # 颜色提取使用colourpicker::colourInput
# 好像没用到？
library(shinydisconnect)        # 自定义断开页面，如果用户上传数据不符合要求，则断开连接，无法接下来的操作




# 生成upset数据示例 ------------------------------------------------------------------------------------------------------------------------------
# library(tidyverse)
# set.seed(123)
# ds <- data.frame(Set1 = c(paste('Protein',sample(1:150, 40), sep = ''), rep(NA, 110)),
#                  Set2 = c(paste('Protein',sample(1:150, 50), sep = ''), rep(NA, 100)),
#                  Set3 = c(paste('Protein',sample(1:150, 99), sep = ''), rep(NA, 51)),
#                  Set4 = c(paste('Protein',sample(1:150, 130), sep = ''), rep(NA, 20)),
#                  Set5 = c(paste('Protein',sample(1:150, 100), sep = ''), rep(NA, 50)),
#                  Set6 = c(paste('Protein',sample(1:150, 120), sep = ''), rep(NA, 30)),
#                  Set7 = c(paste('Protein',sample(1:150, 133), sep = ''), rep(NA, 17)))
# write_csv(ds, file = 'upset_shiny/www/test0.csv', col_names = TRUE)

# Overlap数据处理完整示例 V1 ----------------------------------------------------------------------------------------------------------------------------
# library(tidyverse)
# # 思路1：将数据框中的每列转换为一个列表元素，并对其做缺失值/字符类型做处理
# d0 <- read_csv(file = 'upset_shiny/www/test0.csv') %>%
#   as.list() %>%
#   map(., ~ na.omit(.x)) %>%
#   map(., ~ as.character(.x)) %>%
#   map(., ~ .x[.x != ""])
# 
# # 思路2：排列组合各种交集的可能性，前7列的每一行代表一种排列组合可能性，提取相应的取交集的名称int_name和并集的名称uni_name
# m0 <- list(c(TRUE, FALSE)) %>%
#   rep(length(d0)) %>%
#   expand.grid() %>%
#   set_names(names(d0)) %>%
#   mutate(s = rowSums(.)) %>%
#   filter(s != 0) %>%
#   select(-s) %>%
#   rowwise() %>%
#   mutate(int = list(c_across(cols = everything()))) %>%
#   ungroup() %>%
#   mutate(int_name = map(.x = int, .f = function(x){names(d0)[x]}),
#          uni_name = map(.x = int_name, .f = ~ setdiff(x = names(d0), y = .x))) %>%
#   select(-int);m0
# 
# m3 <- m0 %>%
#   # 思路3：根据int_name(uni_name)提取集合名称对应的集合，并对其单元格内的list求交集和并集;得到int_set/uni_set.
#   mutate(int_set = map(.x = int_name, .f = ~ sapply(X = .x, FUN = function(x) d0[[x]])),
#          uni_set = map(.x = uni_name, .f = ~ sapply(X = .x, FUN = function(x) d0[[x]]))) %>%
#   mutate(int_set = map(.x = int_set,
#                        .f = function(x){
#                          if(is.list(x)){
#                            reduce(.x = x, .f = intersect)
#                          } else { return(x)}
#                        }),
#          uni_set = map(.x = uni_set, .f = ~ unlist(.x) %>% unique())) %>%
#   # 思路4：对每一行的int_set和uni_set求差集
#   mutate('Intersect' = map2(.x = int_set, .y = uni_set, .f = ~ setdiff(.x, .y)),
#          Count = unlist(map(.x = Intersect, .f = length)),
#          intersect_set_count = map(.x = int_name, .f = length) %>% unlist()) %>% 
#   dplyr::select(names(d0), intersect_set_count, Count, 'Intersect') %>% 
#   arrange(desc(intersect_set_count));m3
# 


# upset画图示例-1 -----------------------------------------------------------------------------------------------------------------------------------
# rm(list = ls())
# library(tidyverse)
# library(UpSetR)
# d0 <- read_csv(file = 'upset_shiny/www/test0.csv') %>%
#   as.list() %>%
#   map(., ~ na.omit(.x)) %>%
#   map(., ~ as.character(.x)) %>%
#   map(., ~ .x[.x != ""])
# 
# d0 %>%
#   fromList() %>%
#   upset(data = .,
#         sets = input$nsets,                                       # 选择绘图的集合
#         nintersects = input$nintersects,                          # (主)柱状图的柱子数量
#         order.by = input$order_by,                                # freq:默认按照柱子高度从高往低排序；degree:默认按照交集情况矩阵中取交集集合数量从小到大排序
#         decreasing = input$decreasing,                            # freq:按照交集中元素个数排序，即垂直柱状图的高度; degree:按照交集中集合数量排序
#         mb.ratio = c(input$mb_ratio, 1 - input$mb_ratio),         # 样本名称(标签)到颜色填充中心旋转的距离
#         main.bar.color = input$main_bar_color,                    # 主柱状图与下方交集矩阵关系的
#         sets.bar.color = input$sets_bar_color,                    # 在主柱状图上的填充颜色
#         mainbar.y.label = input$mainbar_y_label,                  # Y轴标签文本内容(名称)
#         sets.x.label = input$sets_x_label,                        # X轴标签文本内容(名称)
#         point.size = input$point_size,                            # 在主柱状图下方，表示集合交集情况的矩阵图中，点的大小
#         line.size = input$line_size,                              # 在主柱状图下方，表示集合交集情况的矩阵图中，线的宽度
#         show.numbers = input$show_numbers,                        # 在主柱状图上显示柱状图高度(交集)数值
#         set_size.show = as.logical(input$set_size_show),          # 在柱状图(横)上显示柱状图高度(交集)数值
#         set_size.numbers_size = input$set_size_numbers_size,      # 在柱状图(横)上显示柱状图高度(交集)数值文本字号。
#         text.scale = c(input$mainbar_y_label_size,                # Y轴标签文本大小
#                        input$mainbar_y_scale_size,                # Y轴坐标轴上文本大小
#                        input$sets_x_label_size,                   # X轴标签文本大小
#                        input$sets_x_scale_size,                   # X轴坐标轴上文本大小
#                        input$samlep_name_size,                    # set1/set2等集合名称字体大小设置
#                        input$mainbar_numeric_size),               # 在主柱状图上显示柱状图高度(交集)数值文本字号。
#         set_size.scale_max = input$sets_x_scale_max)              # 



