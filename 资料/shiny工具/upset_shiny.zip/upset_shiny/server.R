## author: Shuqiang Xu
#  date: 2022/03/28
#  update: 2022/06/06

server <- function(input, output, session) {
  original_dir <- getwd()
  # 数据读取d0 / 数据预览 / 数据清理d1 --------------------------------------------------------------------
  # 数据读取
  d0 <- reactive({
    req(input$file)
    ext <- tools::file_ext(input$file$name)
    
    # 警告1：当数据类型不符合要求
    exist <- ext %in% c("txt","csv","xls","xlsx")
    shinyFeedback::feedbackDanger(inputId = 'file', show = !exist, text = "请导入csv|txt|xls|xlsx格式文件")
    
    req(exist, cancelOutput = TRUE)
    d <- switch(ext,
                txt = vroom::vroom(input$file$datapath),
                csv = vroom::vroom(input$file$datapath, delim = ","),
                xls  = openxlsx::read.xlsx(path = input$file$datapath),
                xlsx = readxl::read_xlsx(path = input$file$datapath),
                validate("无效文件，请输出csv|txt|xls|xlsx格式文件")
    )
    # 警告2：当数据列数超过5组
    n_col <- ncol(d) < 2
    shinyFeedback::feedbackDanger(inputId = 'file', show = n_col, text = "文件中至少需要2组(列)集合")
    req(!n_col, cancelOutput = TRUE)
    
    return(d)
  })
  
  # 数据预览
  output$preview <- DT::renderDataTable({
    req(d0())
    datatable(d0(),
              extensions = 'Buttons',
              class      = "row-border hover",
              options    = list(pageLength = 15,
                                lengthMenu = c(10, 20, 50, 100, -1),
                                dom = 'Blfrtip',
                                autowidth = TRUE, 
                                buttons = c('csv', 'excel'),
                                columnDefs = list(list(width = "125px", targets = "_all")),
                                scrollX = TRUE))
  })

  # 数据清理/转换，d1为list列表
  d1 <- reactive({
    req(d0())
    d0() %>%
      as.list() %>%
      map(., ~ na.omit(.x)) %>%           # 在读取整个表格(xlsx)时，列数据集的元素个数不一致，会有NA存在
      map(., ~ subset(.x, .x != '')) %>%  # 缺失值可能是‘’的情况
      map(., ~ as.character(.x)) %>%      # 如果数值，则转换成char
      return()
  })
  
  # 更新ui参数: ui端根据上传数据改变 -----------------------------------------------------
  observe({
    req(input$file)
    updateSelectInput(inputId = "nsets", choices = names(d1()), selected = names(d1()))
    updateNumericInput(inputId = 'nintersects', value = 20, min = 1, step = 1)
    updateNumericInput(inputId = 'sets_x_scale_max', label = 'X轴数值长度', 
                       value = round(x = max(unlist(lapply(d1(), length)))*1.5,digits = 0), 
                       min = 0)
    output$plot_out_ui <- renderUI({
      withSpinner(plotOutput(outputId = "plot_out", width = paste0(input$plot_width,'px'), height = paste0(input$plot_height,'px')))
    })
  })
  
  
  
  # 图形/绘图参数输出 ---------------------------------------------------------------
  
  observe({
    # 画图输出
    output$plot_out <- renderPlot({
      req(d1())
      k <<- d1() %>% 
        fromList() %>% 
        upset(data = .,
              sets = input$nsets, # Warning: Error in <-: replacement has length zero
              nintersects = input$nintersects,
              order.by = input$order_by,
              decreasing = input$decreasing,
              mb.ratio = c(input$mb_ratio, 1 - input$mb_ratio),
              main.bar.color = input$main_bar_color,
              sets.bar.color = input$sets_bar_color,
              mainbar.y.label = input$mainbar_y_label,
              sets.x.label = input$sets_x_label,
              point.size = input$point_size,
              line.size = input$line_size,
              show.numbers = input$show_numbers,
              set_size.show = as.logical(input$set_size_show),
              set_size.numbers_size = input$set_size_numbers_size,
              text.scale = c(input$mainbar_y_label_size,
                             input$mainbar_y_scale_size,
                             input$sets_x_label_size,
                             input$sets_x_scale_size,
                             input$samlep_name_size,
                             input$mainbar_numeric_size),
              set_size.scale_max = input$sets_x_scale_max)
        # try(., silent = TRUE)
      return(k)
    })
    
  })
  
  # 绘图参数输出
  output$plot_config_table <- renderTable({
    req(input$file)
    plot_values_matrix0 <<- reduce(.f = rbind, .x = list(c("R版本:", paste0(str_extract(R.version$version.string, '(\\d).(\\d).(\\d{1,2})'))),
                                                         c("R包版本:", paste0("UpSetR ",packageVersion("UpSetR"))),
                                                         c('柱子数量', input$nintersects),
                                                         c('排序类型', input$order_by),
                                                         c('降序排列', input$decreasing),
                                                         c('柱状图比例', input$mb_ratio),
                                                         c('Y轴标签', input$mainbar_y_label),
                                                         c('Y轴标签字号', input$mainbar_y_label_size),
                                                         c('Y轴数值字号', input$mainbar_y_scale_size),
                                                         c('显示计数标签', input$show_numbers),
                                                         c('计数标签字号', input$mainbar_numeric_size),
                                                         c('柱状图颜色', input$main_bar_color),
                                                         c('X轴标签', input$sets_x_label),
                                                         c('X轴标签字号', input$sets_x_label_size),
                                                         c('X轴数值字号', input$sets_x_scale_size),
                                                         c('X轴数值长度', input$sets_x_scale_max),
                                                         c('样本名称字号', input$samlep_name_size),
                                                         c('柱状图(横)颜色', input$sets_bar_color),
                                                         c('显示计数标签(横)', input$set_size_show),
                                                         c('计数标签字号', input$set_size_numbers_size),
                                                         c('点大小', input$point_size),
                                                         c('线宽度', input$line_size))) %>% 
      as_tibble() %>% 
      set_names(nm = c('参数', '数值'))
  })
  
  # 绘图参数下载
  # 绘图参数下载
  output$plot_config_download <- downloadHandler(
    filename = paste0('upset_config.xlsx'),
    content = function(file) {
      openxlsx::write.xlsx(plot_values_matrix0, file, rowNames = FALSE, append = TRUE, sheetName = 'Sheet 1')
    }
  )
  
  # 绘图下载 ------------------------------------------------------------------------------------------------------------------------------------------
  observeEvent(input$plot_format, {
    output$plot_download <- downloadHandler(
      filename <- paste0('upset_plot.', input$plot_format),
      content <- function(file) {
        setwd(tempdir())
        print(tempdir())
        
        try(dev.off(), silent = T)
        switch (input$plot_format,
                'png' = png(file, width = input$plot_width, height = input$plot_height),
                'tiff' = tiff(file, width = input$plot_width, height = input$plot_height),
                'pdf' = pdf(file, width = input$plot_width/85, height = input$plot_height/85),
                'svg' = svg(filename = file, width = input$plot_width/85, height = input$plot_height/85))
        print(k)
        try(dev.off(), silent = T)
      }
    )
  })
  

  # Overlap数据处理与下载 -------------------------------------------------------
  # Overlap数据处理
  observe({
    # 思路1：将数据框中的每列转换为一个列表元素，并对其做缺失值/字符类型做处理；已在数据预处理做过，得到d1()
    # 思路2：排列组合各种交集的可能性，前7列的每一行代表一种排列组合可能性，提取相应的取交集的名称int_name和并集的名称uni_name
    m0 <- list(c(TRUE, FALSE)) %>%
      rep(length(d1())) %>%
      expand.grid() %>%
      set_names(names(d1())) %>%
      mutate(s = rowSums(.)) %>%
      filter(s != 0) %>%
      select(-s) %>%
      rowwise() %>%
      mutate(int = list(c_across(cols = everything()))) %>%
      ungroup() %>%
      mutate(int_name = map(.x = int, .f = function(x){names(d1())[x]}),
             uni_name = map(.x = int_name, .f = ~ setdiff(x = names(d1()), y = .x))) %>%
      select(-int)

    m1 <<- m0 %>%
      # 思路3：根据int_name(uni_name)提取集合名称对应的集合，并对其单元格内的list求交集和并集;得到int_set/uni_set.
      mutate(int_set = map(.x = int_name, .f = ~ sapply(X = .x, FUN = function(x) d1()[[x]])),
             uni_set = map(.x = uni_name, .f = ~ sapply(X = .x, FUN = function(x) d1()[[x]]))) %>%
      mutate(int_set = map(.x = int_set,
                           .f = function(x){
                             if(is.list(x)){
                               reduce(.x = x, .f = intersect)
                             } else { return(x)}
                           }),
             uni_set = map(.x = uni_set, .f = ~ unlist(.x) %>% unique())) %>%
      # 思路4：对每一行的int_set和uni_set求差集
      mutate('Intersect' = map2(.x = int_set, .y = uni_set, .f = ~ setdiff(.x, .y)),
             Count = unlist(map(.x = Intersect, .f = length)),
             intersect_set_count = map(.x = int_name, .f = length) %>% unlist()) %>% 
      dplyr::select(1:length(d1()), intersect_set_count, Count, 'Intersect') %>% 
      arrange(desc(intersect_set_count))
  })
  
  ### Overlap数据下载
  output$plot_overlap_download <- downloadHandler(
    filename = paste0('overlap_data.xlsx'),
    content = function(file) {
      openxlsx::write.xlsx(m1, file, row.names = FALSE, append = TRUE, sheetName = 'Sheet 1')
    }
  )
  
  # 示例数据下载 ------------------------------------------------------------------
  output$downloaddemo <- downloadHandler(
    filename = paste0('Demo_upset_1.csv'),
    content = function(file){
      file.copy(paste0(original_dir,"/www/Demo_upset_1.csv"), file)
    }
  )
}


