library(tidyverse)
library(readxl)
library(UpSetR)
d <- # read_xlsx(path = 'C:/Users/ptm/Downloads/Demo_upset_2.xlsx') %>% 
  # read_xlsx(path = './venn_shiny/www/Demo_Venn_5.xlsx') %>%
  read_csv(file = './upset_shiny/www/test0.csv') %>%
  as.list() %>%
  map(., ~ na.omit(.x)) %>%           # 在读取整个表格(xlsx)时，列数据集的元素个数不一致，会有NA存在
  map(., ~ subset(.x, .x != '')) %>%  # 缺失值可能是‘’的情况
  map(., ~ as.character(.x))          # 如果数值，则转换成char

# d <- 
# pdf(file = "plot.pdf", width = 8, height = 8)
# UpSetR:::Make_matrix_plot
# a <-
  d %>% 
  fromList() %>% 
  # upset(nsets = length(d), order.by = c("freq", "degree"), decreasing = c(TRUE,FALSE), sets = c('lsp', 'ksp', 'npe'))
  upset(, order.by = c("freq", "degree"), decreasing = c(TRUE,FALSE), intersections = list(c('lsp','ksp')))
# savePlot(filename = 'plot.png', device = dev.cur())
print(a)
dev.off()
file.show('plot.pdf')
# save(list = a, file = 'upset.png')
# library(pacman)
# p_unload(p_loaded(), character.only = T)


require(ggplot2)
require(plyr)
require(gridExtra)
require(grid)



movies <- read_delim(system.file("extdata","movies.csv",package = "UpSetR"), delim = ';', col_names = TRUE)
# View(movies)
d <- as_tibble(movies, rownames = NULL)

d %>% 
  as.list() %>%
  fromList() %>% 
  # upset(nsets = 4, order.by = c("freq", "degree"), decreasing = c(TRUE,FALSE), nintersects = 8)
  upset(set_size.show = FALSE
    
      )

upset(movies, order.by = "freq", decreasing = F)

# Sample1,Sample2,Sample3,Sample4,Sample5,Sample6,Sample7
# 主柱状图
# sets: 只观察哪几个集合的组合交集(参数为列名称)
# nsets: 最多展示多少个集合数据。总共只有5个集合, 最多值观察4个集合的交集
# nintersects: 最多展示多少交集。(NA,全部交集; 1:2^n)
# mb.ratio： 点点图和条形图的比例。
# order.by： 交集如何排序。这里先根据freq(交集中元素的个数)，然后根据degree(进行交集的集合个数)
# decreasing： 垂直柱状图排序，FALSE, 4集合的交集、3个集合的交集、2个集合的交集、1个集合的交集
# decreasing： 垂直柱状图排序，TRUE,  1集合的交集、2个集合的交集、3个集合的交集、4个集合的交集
# intersections: 文件中集合的名称向量，最少2个，表示'只'关注这几个集合的交集情况,比如list(list(set1,set2), list(set3,set4)),则只会呈现set1和set2、set3和set4的交集
# main.bar.color: (正)主柱子的颜色
# matrix.color: 表示intersection关系线段的颜色
# sets.bar.color: (侧)横柱子的颜色
# mainbar.y.label: 主柱状图的y轴标签
# sets.x.label: (侧)横柱子的x轴标签
# point.size: 矩阵点的大小
# line.size: 矩阵连线的宽度
# mb.ratio: 主柱子与矩阵在画板中的占比(c(0.5, 0.5))
# expression
# att.pos	
# att.color
# show.numbers: 柱状图上方显示数字('yes', 'no')
# shade.alpha: 柱状图下方间隔横条的阴影

# scale.intersections:柱状图数值转换
# scale.sets:横柱状图数值转化
movies <- read.csv( system.file("extdata", "movies.csv", package = "UpSetR"), header=TRUE, sep=";" )

require(ggplot2); require(plyr); require(gridExtra); require(grid);

between <- function(row, min, max){
  newData <- (row["ReleaseDate"] < max) & (row["ReleaseDate"] > min)
}

plot1 <- function(mydata, x){
  myplot <- (ggplot(mydata, aes_string(x= x, fill = "color"))
             + geom_histogram() + scale_fill_identity()
             + theme(plot.margin = unit(c(0,0,0,0), "cm")))
}

plot2 <- function(mydata, x, y){
  myplot <- (ggplot(data = mydata, aes_string(x=x, y=y, colour = "color"), alpha = 0.5)
             + geom_point() + scale_color_identity()
             + theme_bw() + theme(plot.margin = unit(c(0,0,0,0), "cm")))
}

attributeplots <- list(gridrows = 55,
                       plots = list(list(plot = plot1, x= "ReleaseDate",  queries = FALSE),
                                    list(plot = plot1, x= "ReleaseDate", queries = TRUE),
                                    list(plot = plot2, x = "ReleaseDate", y = "AvgRating", queries = FALSE),
                                    list(plot = plot2, x = "ReleaseDate", y = "AvgRating", queries = TRUE)),
                       ncols = 3)

upset(movies, nsets = 7, nintersects = 30, mb.ratio = c(0.5, 0.5),
      order.by = c("freq", "degree"), decreasing = c(TRUE,FALSE))

upset(movies, sets = c("Drama", "Comedy", "Action", "Thriller", "Western", "Documentary"),
      queries = list(list(query = intersects, params = list("Drama", "Action")),
                     list(query = between, params = list(1970, 1980), color = "red", active = TRUE)),
      # boxplot.summary = c('Western', 'Action'), 
      text.scale = c(1,1,1,1,1,1.3), set_size.show = TRUE, set_size.numbers_size = 10, set_size.angles = 0, set_size.scale_max = 2000)

upset(movies, attribute.plots = attributeplots,
      queries = list(list(query = between, params = list(1920, 1940)),
                     list(query = intersects, params = list("Drama"), color= "red"),
                     list(query = elements, params = list("ReleaseDate", 1990, 1991, 1992))),
      main.bar.color = "yellow")




# Overlap数据下载 -----------------------------------------------------------------------------------------------------------------------------------------
rm(list = ls())
library(pacman)
p_unload(p_loaded(), character.only = T)
# d0 <- read_xlsx(path = "./shiny_venn/www/Demo_Venn_5.xlsx") %>%  as.list() %>%
#   map(., ~ na.omit(.x)) %>%
#   map(., ~ as.character(.x)) %>%
#   map(., ~ .x[.x != ""])
library(tidyfst)
library(readxl)
library(tidyverse)

tidyfst::sys_time_print({
  d0 <- read_xlsx(path = './venn_shiny/www/Demo_Venn_5.xlsx') %>%
    as.list() %>%
    map(., ~ na.omit(.x)) %>%           # 在读取整个表格(xlsx)时，列数据集的元素个数不一致，会有NA存在
    map(., ~ subset(.x, .x != '')) %>%  # 缺失值可能是‘’的情况
    map(., ~ as.character(.x))          # 如果数值，则转换成char
  # 思路2：排列组合各种交集的可能性，每一行代表一种可能性
  sys_time_print({
    m0 <- list(c(TRUE, FALSE)) %>%
      rep(length(d0)) %>%
      expand.grid() %>%
      set_names(names(d0)) %>%
      mutate(s = rowSums(.)) %>%
      filter(s != 0) %>%
      select(-s) %>%
      rowwise() %>%
      mutate(int = list(c_across(cols = everything()))) %>%
      ungroup() %>%
      mutate(int_name = map(.x = int, .f = function(x){names(d0)[x]}),
             uni_name = map(.x = int_name, .f = ~ setdiff(x = names(d0), y = .x))) %>%
      select(-int)
  })
  m3 <- m0 %>%
    # 思路3：根据int_name(uni_name)提取集合名称对应的集合，得到int_set/uni_set，并对其单元格内的list求交集和并集
    mutate(int_set = map(.x = int_name, .f = ~ sapply(X = .x, FUN = function(x) d0[[x]])),
              uni_set = map(.x = uni_name, .f = ~ sapply(X = .x, FUN = function(x) d0[[x]]))) %>%
    mutate(int_set = map(.x = int_set,
                            .f = function(x){
                              if(is.list(x)){
                                reduce(.x = x, .f = intersect)
                              } else { return(x)}
                            }),
              uni_set = map(.x = uni_set, .f = ~ unlist(.x) %>% unique())) %>%
    # 思路4：对每一行的int_set和uni_set求差集
    mutate('Intersect' = map2(.x = int_set, .y = uni_set, .f = ~ setdiff(.x, .y))) %>% 
    mutate(Count = map(.x = Intersect, .f = length) %>% unlist(),
              intersect_set_count = map(.x = int_name, .f = length) %>% unlist()) %>% 
    select(1:length(d0), intersect_set_count, Count, 'Intersect') %>% 
    arrange(desc(intersect_set_count))
})


# tidyfst::sys_time_print({
#   library(tidyfst)
#   library(readxl)
#   library(tidyverse)
#   d0 <- read_xlsx(path = './venn_shiny/www/Demo_Venn_5.xlsx') %>%
#     as.list() %>%
#     map(., ~ na.omit(.x)) %>%           # 在读取整个表格(xlsx)时，列数据集的元素个数不一致，会有NA存在
#     map(., ~ subset(.x, .x != '')) %>%  # 缺失值可能是‘’的情况
#     map(., ~ as.character(.x))          # 如果数值，则转换成char
#   # 思路2：排列组合各种交集的可能性，每一行代表一种可能性
#   sys_time_print({
#     m0 <- list(c(TRUE, FALSE)) %>%
#       rep(length(d0)) %>%
#       expand.grid() %>%
#       set_names(names(d0)) %>%
#       mutate(s = rowSums(.)) %>%
#       filter(s != 0) %>%
#       select(-s) %>%
#       rowwise() %>%
#       mutate(int = list(c_across(cols = everything()))) %>%
#       ungroup() %>%
#       as.data.table() %>% 
#       mutate(int_name = map(.x = int, .f = function(x){names(d0)[x]}),
#              uni_name = map(.x = int_name, .f = ~ setdiff(x = names(d0), y = .x))) %>%
#       select(-int)
#   })
#   m3 <- m0 %>%
#     # 思路3：根据int_name(uni_name)提取集合名称对应的集合，得到int_set/uni_set，并对其单元格内的list求交集和并集
#     mutate_dt(int_set = map(.x = int_name, .f = ~ sapply(X = .x, FUN = function(x) d0[[x]])),
#               uni_set = map(.x = uni_name, .f = ~ sapply(X = .x, FUN = function(x) d0[[x]]))) %>%
#     mutate_dt(int_set = map(.x = int_set,
#                             .f = function(x){
#                               if(is.list(x)){
#                                 reduce(.x = x, .f = intersect)
#                               } else { return(x)}
#                             }),
#               uni_set = map(.x = uni_set, .f = ~ unlist(.x) %>% unique())) %>%
#     # 思路4：对每一行的int_set和uni_set求差集
#     mutate_dt('Intersect' = map2(.x = int_set, .y = uni_set, .f = ~ setdiff(.x, .y))) %>% 
#     mutate_dt(Count = map(.x = Intersect, .f = length) %>% unlist(),
#               intersect_set_count = map(.x = int_name, .f = length) %>% unlist()) %>% 
#     select(1:length(d0), intersect_set_count, Count, 'Intersect') %>% 
#     arrange(desc(intersect_set_count))
# })
# head(m3,20)
