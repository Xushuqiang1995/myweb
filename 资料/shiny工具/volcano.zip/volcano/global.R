library(shiny)
enableBookmarking(store = 'url')

# shiny::shinyApp(ui, server)
# shiny::runApp("./shiny/volcano")
