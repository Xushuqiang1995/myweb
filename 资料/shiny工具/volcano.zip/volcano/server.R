rm(list=ls())
library(shiny)
library(DT)
library(shinyjqui)##图片拖拽大小
library(ggplot2)
library(readxl)
library(openxlsx)###write.xlsx
library(ggrepel)
library(RColorBrewer)
library(rlang)
library(stringr)
library(shinycssloaders)#等待条
library(shinyjs)
#library(shinylogs)##logs记录
library(tippy)
library(ggthemes)
#library(log4r)##logs记录

# author: Yinling Zhu
# Date: 2022/03/28
# update: 2022/06/06

server=function(input,output,session){
  #------------------------ reactive --------------------------
  options(shiny.maxRequestSize=5000*1024^2)#shiny.reactlog = TRUE
  jqui_bookmarking()
  values=reactiveValues(data=NULL,datano=NULL,infc=NULL,inpve=NULL,plotvol=NULL)
  print(getwd())###app.R存放路径，当前工作路径
  print(tempdir())###临时运行路径，生成文件
  original_dir <- getwd()
  #track_usage(storage_mode = store_json(path = paste0(original_dir,"logs/")))##logs记录
  #track_usage(storage_mode = store_null(console = TRUE))###log展示在对话框
  # #---------日志-----------------------------------------------
  # path = paste0(original_dir,"/logs")
  # pathlog = paste0(path,"/Volcano_shinyapp_log.txt")
  # if (!dir.exists(path)){
  #   dir.create(path)
  # }
  # if (file.exists(pathlog)){
  #   file.remove(pathlog)
  #   file.create(pathlog)
  # }else{
  #   file.create(pathlog)
  # }
  # writeLog <- function(message, user, level) {
  #   create.logger(pathlog, level = 2)
  #   appender = file_appender(pathlog)
  #   # hardcode输出样式
  #   appender(level, '[', user, ']', ' ', message)
  # }
  # # 传入字符'WARN'判断等级 WARN, INFO, ERROR, DEBUG, FATAL
  # writeLog(level = 'INFO', user = 'shinyapp', message = '开始运行')
  # #---------日志-----------------------------------------------
  ####导入demo #####不导入demo
  # demo_datain <- read_xlsx(paste0(original_dir,"/www/different_volcano.xlsx"),sheet = 1)##第二列ratio，第三列pvalue##############################
  # demo_data <- as.data.frame(demo_datain)
  ####demo完成
  ###########------------------------ 文件上传 --------------------------
  observe({
    if(!is.null(input$file)){
      #writeLog(level = 'INFO', user = 'shinyapp', message = '文件上传成功')
      showNotification("文件已上传，正在绘图中，请稍等......", type = "warning",duration=10)
      inFile <- input$file
      
      if((str_detect(inFile$name,pattern = '.xlsx$')) | (str_detect(inFile$name,pattern = '.xls$'))){ ##stringr::
        sheets=excel_sheets(path = inFile$datapath)
        if (length(sheets) > 1){
          showModal(###弹窗提醒
            modalDialog(
              p("请上传仅有一个sheet的xlsx/xls格式的表格,或者是txt，csv格式文件"),
              easyClose = TRUE,
              footer = tagList(
                actionButton(inputId = "intro", label = "OK", icon = icon("info-circle")))
            )
          )
        }else{
          data_up <- read_excel(inFile$datapath,sheet = 1)
          data_up <- as.data.frame(data_up)
          values$data<-data_up
          #writeLog(level = 'INFO', user = 'shinyapp', message = '文件读入成功')
        }
      }else if(str_detect(inFile$name,pattern = '.csv$')){
        values$data<-read.csv(file=inFile$datapath,header = T,stringsAsFactors = F,##row.names = 1,####stringsAsFactors = F,与excel读入的列保持一致，为向量而不是因子
                              encoding = 'UTF-8',check.names = F)
        #writeLog(level = 'INFO', user = 'shinyapp', message = '文件读入成功')
      }else{
        values$data<-read.table(file=inFile$datapath,header=T,stringsAsFactors = F,##row.names = 1,
                                sep = "\t",encoding = 'UTF-8',check.names = F,quote = "")
        #writeLog(level = 'INFO', user = 'shinyapp', message = '文件读入成功')
      }
    }else{
      values$data <- NULL#######默认不输入文件
      ##values$data=demo_data ##无文件上传时，默认使用demo矩阵数据##########################################
    }
  })
  observeEvent(input$intro,{
    removeModal()
  })
  output$tableupdate=DT::renderDataTable({
    datatable(values$data[1:10,],extensions = 'Buttons', class = "row-border hover",
              options=list(pageLength = 10,lengthMenu = c(10, 20, 50, 100,-1),dom = 'rt',
                           scrollX=TRUE))
  })
  ###########------------------------ 文件上传 --------------------------
  ###########------------------------ 文件处理 --------------------------
  plotdata <- reactive({
    if (any(file.exists(dir(".", pattern="(.png)")))){
      file.remove(dir(".", pattern="(.png)"))
    }
    if (is.null(values$data)){
      redata <- NULL
    }else{
      # tryCatch({
      ###标记上下调，注意空和0处理
      if (ncol(values$data) > 3){
        redata <- cbind(values$data[,1:4],c(rep("Unchange",nrow(values$data))))###额外一列放上下调,第四列为基因名或其他需要展示的标签
        #writeLog(level = 'INFO', user = 'shinyapp', message = '数据多于3列，将第4列作为备选散点展示标签')
      }else if(ncol(values$data) < 4){
        redata <- cbind(values$data[,1:3],values$data[,1],c(rep("Unchange",nrow(values$data))))####如果小于4列，把ID作为显示label
        #writeLog(level = 'INFO', user = 'shinyapp', message = '数据少于4列，散点标签仅可选第1列ID')
      }else{
        NULL
      }
      colnames(redata) <- c("ID","FC","P.value","Point.Label","Regulated.Type")
      redata$Regulated.Type = as.character(redata$Regulated.Type)###factor转换为character
      redata <- redata[!rowSums(is.na(redata[,1:3]))>0,]###前三列带有空值，直接去除，基因名带空值不影响
      if (min(redata[,2]) > 0){###原始数据未进行log
        for (m in 1:nrow(redata)) {
          if (redata[m,3] < input$pvkazhi){
            if (redata[m,2] > input$fckazhi){
              redata[m,'Regulated.Type'] <- 'Up'
            }else if(redata[m,2] < 1/input$fckazhi){
              redata[m,'Regulated.Type'] <- 'Down'
            }
          }
        }
      }else{
        for (m in 1:nrow(redata)) {
          if (redata[m,3] < input$pvkazhi){
            if (redata[m,2] > input$fckazhi){
              redata[m,'Regulated.Type'] <- 'Up'
            }else if(redata[m,2] < -input$fckazhi){
              redata[m,'Regulated.Type'] <- 'Down'
            }
          }
        }
      }
      # },
      # error = function(e) {
      #   problem <<- conditionMessage(e)　####conditionMessage是错误详情
      #   #writeLog(level = 'ERROR', user = 'shinyapp', message = problem)
      # })
    }
    return(redata)
  })
  ###########------------------------ 文件处理 --------------------------
  ###########------------------------ 图例位置输入框UI-------
  output$legend_position_ui <- renderUI({
    if (input$legend_in == '坐标系外') {
      selectInput(inputId = 'legend_position_id', label = i18n('坐标系外位置:'), c('top', 'bottom', 'left', 'right'), 
                  selected = 'right',width = "47%")
    } else {
      fluidRow(column(width = 6, numericInput('legend_x', '图例x轴位置', min = 0, max = 1, value = 0.85, step = 0.05)),###zyl###, step = 0.1
               column(width = 6, numericInput('legend_y', '图例y轴位置', min = 0, max = 1, value = 0.85, step = 0.05))
      )
    }
  })
  ###########------------------------ 选择是否添加阈值虚线出现输入框UI-------
  output$dotted_line_style_ui <- renderUI({
    if (input$dotted_line){
      div(
        fluidRow(
          column(3,pickerInput(inputId = "ltyid",label = "线条类型:",choices = c("dashed","dotdash","twodash","longdash","dotted","solid"),
                               selected = "dashed")),
          column(3,colourpicker::colourInput('dotted_line_colid', "线条颜色:","black",palette = "limited",returnName=TRUE)),
          column(3,numericInput("lwdid", "线条宽度:", value = 0.7, step =0.1,min = 0.1, width  = NULL)),
          column(3,numericInput("alphaid", "线条透明度:", value = 0.7, step =0.1,min = 0,max = 1, width  = NULL))
        )
      )
    }else{
      NULL
    }
  })
  ###########------------------------ 选择是否添加阈值虚线出现输入框UI-------
  ###########------------------------ 选择是否添加基因名出现输入框UI-------
  output$id_gene_label_ui <- renderUI({
    if (is.null(values$data) && input$genename){
      awesomeRadio(inputId = "no_id_gene_label_id",label = "展示标签来源：",choices = c("首列ID"),selected = "首列ID",inline = TRUE,checkbox = TRUE)
    }else if (ncol(values$data)>3 && input$genename){
      awesomeRadio(inputId = "id_gene_label_id",label = "展示标签来源：",choices = c("首列ID", "第四列symbol"),selected = "第四列symbol",inline = TRUE,checkbox = TRUE)
    }else if (ncol(values$data)<4 && input$genename){
      awesomeRadio(inputId = "no_id_gene_label_id",label = "展示标签来源：",choices = c("首列ID"),selected = "首列ID",inline = TRUE,checkbox = TRUE)
    }else{
      NULL
    }
  })
  output$geom_text_label_ui <- renderUI({
    if (input$genename){
      awesomeRadio(inputId = "geom_text_label_id",label = "标签格式：",choices = c("纯文字", "带背景框"),selected = "纯文字",inline = TRUE,checkbox = TRUE)
    }else{
      NULL
    }
  })
  
  
  output$gene_label_text_ui <- renderUI({
      if (input$genename){
      div(
        fluidRow(
          column(5,div(numericInput("topfc", "展示蛋白FC最大/最小的标签个数:", value = 10, min = 0, step = 5, width  = NULL),
                       numericInput("toppv", "展示蛋白P.value最小的标签个数:", value = 0, min = 0, step = 5, width  = NULL))),
          column(1,style = "padding-top: 60px;",p("或")),##float:center;
          column(2,style = "padding-top: 10px;",checkboxInput("showalllabel",strong("展示全部差异蛋白标签"), FALSE,width="95%")),
          column(1,style = "padding-top: 60px;",p("或")),
          column(3,textAreaInput("text_area_list",
                                 label = "自定义输入：",
                                 height = "100px",value = "",placeholder = "SFXN2\nRPS28\n..."))
          ),
        tippy_this('topfc', tooltip = "三种显示散点标签的方式优先级依次增加，后面会覆盖前面，若想恢复前面显示标签方式，只需将后面的恢复默认！", 
                   animation = "scale",duration = 1000, placement = "bottom",theme = "translucent"),
        tippy_this('toppv', tooltip = "三种显示散点标签的方式优先级依次增加，后面会覆盖前面，若想恢复前面显示标签方式，只需将后面的恢复默认！", 
                   animation = "scale",duration = 1000, placement = "bottom",theme = "translucent"),
        tippy_this('text_area_list', tooltip = "三种显示散点标签的方式优先级依次增加，后面会覆盖前面，若想恢复前面显示标签方式，只需将后面的恢复默认！
                   每行填写一个蛋白或基因名，最好从表格中直接复制，避免输错导致不显示！", 
                   animation = "scale",duration = 1000, placement = "bottom",theme = "translucent"),
        fluidRow(
          column(3,colourpicker::colourInput('lable_color_id', "标签字体颜色:","white",palette = "limited",returnName=TRUE)),
          column(2,numericInput("labelsize_id", "标签字体:", value =  5, min = 0)),
          column(3,colourpicker::colourInput('segment_color_id', "连接线颜色:","white",palette = "limited",returnName=TRUE)),
          column(2,numericInput("box_padding_id", "连接线长:", value =  0.8,step = 0.1 , min = 0,max = 10)),
          column(2,numericInput("segment_size_id", "连接线宽:", value =  0.8, step = 0.1, min = 0,max = 10))
        ),
        tippy_this('lable_color_id', tooltip = "此颜色选择框默认为'white'，此时标签与连接线同色，区分上下调颜色并分别跟随蛋白上下调的颜色!
                   若选择其他颜色，展示出的蛋白标签均变为新选择的颜色，且连接线颜色同时会跟随改变！若想恢复默认，选择'white'即可！", 
                   animation = "scale",duration = 1000, placement = "bottom",theme = "translucent"),
        tippy_this('segment_color_id', tooltip = "此颜色选择框默认为'white'，连接线区分上下调颜色并分别跟随蛋白上下调的颜色!若选择其他颜色，
                    连接线均变为新选择的颜色！若想恢复默认，此处两个颜色选择框均选择'white'即可！", 
                   animation = "scale",duration = 1000, placement = "bottom",theme = "light")
      )
    }else{
      NULL
    }
  })
  ###########------------------------ 选择是否添加基因名出现输入框UI-------
  ###########------------------------ 参数输入绘图 ----------------------
  observe({
    data <- plotdata()
    datafccolname <- "FC"###展示绘图数据table的表头
    datapvcolname <- "P.value"###展示绘图数据table的表头
    if (is.null(data)){
      p <- NULL
    }else{
      #writeLog(level = 'INFO', user = 'shinyapp', message = '绘图参数准备')
      data[which(data$FC == 0),"FC"] <- 1
      data[which(data$P.value == 0),"P.value"] <- 0.00000001 ###-log10时，0会报错，赋极小值0.00000001。
      data$Regulated.Type=as.vector(data$Regulated.Type)
      if(input$fcid){
        if (min(data$FC) > 0){
          data$FC = log2(data$FC)
          values$infc = log2(input$fckazhi)
          datafccolname <- "Log2 FC"
          if (input$xlab == "FC"){
            updateTextInput(session,inputId="xlab", label="x轴标签:", value = "Log2 FC")
          }
        }else{
          values$infc = input$fckazhi
          #updateCheckboxInput(session,inputId="fcid",label=strong("FC(Ratio) 进行log2计算"), value = FALSE)
          showNotification("FC值中含有非正数，可能已经进行过log转换，不可再进行log转换！", type = "warning",duration=30)
        }
      }else{
        values$infc = input$fckazhi
        if (input$xlab == "Log2 FC"){
          updateTextInput(session,inputId="xlab", label="x轴标签:", value = "FC")
        }
      }
      if(input$pvalueid){
        if (min(data$P.value) > 0){
          data$P.value = -log10(data$P.value)
          values$inpve = -log10(input$pvkazhi)
          datapvcolname <- "-Log10 P.value"
          if (input$ylab == "P value"){
            updateTextInput(session,inputId="ylab", label="y轴标签:", value = "-Log10 P value")
          }
        }else{
          values$inpve = input$pvkazhi
          #updateCheckboxInput(session,inputId="pvalueid",label=strong("P Value 进行-log10计算"), value = FALSE)
          showNotification("P Value中含有非正数，可能已经进行过log转换，不可再进行log转换！", type = "warning",duration=10)
        }
      }else{
        values$inpve = input$pvkazhi
        if (input$ylab == "-Log10 P value"){
          updateTextInput(inputId="ylab", label="y轴标签:", value = "P value")
        }
      }
      dataplottable <- data[which(data$Regulated.Type %in% c("Up","Down")),]
      colnames(dataplottable)[2:3] <- c(datafccolname,datapvcolname)###展示绘图数据,全部Point.Label，便于复制
      ymax=max(data$P.value,na.rm=T)+0.5
      # if(ymax > 20){###不再限制最大y轴范围
      #   ymax <- 20
      # }
      if(input$yhight != ""){
        my_y <- input$yhight
        my_y <- as.numeric(as.character(my_y))
        ymax <- my_y
      }
      xmax=max(abs(data$FC),na.rm=T)+0.5
      xmaxl=-xmax
      xmaxr=xmax
      # if(xmax > 6){###不再限制最大x轴范围
      #   xmax=6
      #   xmaxl=-6
      #   xmaxr=6
      # }
      if(input$xrangel != ""){
        my_xl <- input$xrangel
        my_xl <- as.numeric(as.character(my_xl))
        xmaxl <- my_xl
      }
      if(input$xranger != ""){
        my_xr <- input$xranger
        my_xr <- as.numeric(as.character(my_xr))
        xmaxr <- my_xr
      }
      #writeLog(level = 'INFO', user = 'shinyapp', message = '参数准备完成，开始绘图')
      #tryCatch({
      p <- ggplot(data=data,aes(x=FC,y=P.value,colour=Regulated.Type))+geom_point(size=input$point,alpha=input$pointalpha)+
        scale_colour_manual(values=c(Unchange=input$nodif,Down=input$down,Up=input$up))+labs(x=input$xlab,y=input$ylab)+
        xlim(xmaxl,xmaxr)+ylim(0,ymax)
      # },
      # error = function(e) {
      #   problem2 <<- conditionMessage(e)　####conditionMessage是错误详情
      #   writeLog(level = 'ERROR', user = 'shinyapp', message = problem2)
      # })
      themetype <- input$themeid
      ## add theme
      if (grepl("::", themetype)) {
        real_theme <- strsplit(themetype, split = "::")[[1]][2]
        pkg <- strsplit(themetype, split = "::")[[1]][1]
        p <- p + base::eval(call(real_theme), envir = rlang::search_env(rlang::pkg_env_name(pkg)))
      } else {
        p <- p + base::eval(call(themetype))
      }
      #writeLog(level = 'INFO', user = 'shinyapp', message = '图片格式设定')
      ## legend
      if (input$legend_in == "坐标系外") {
          p <- p + theme(legend.position = input$legend_position_id)
        } else {
          p <- p + theme(legend.position = c(input$legend_x, input$legend_y))
        }
      p <- p+theme(axis.text=element_text(size=input$xylegendfontid),axis.title.x=element_text(size=input$xlabfontid,face = input$xlabfaceid),
                   axis.title.y=element_text(size=input$ylabfontid,face = input$ylabfaceid),
                   legend.title=element_text(size=input$legendtitlefontid,face = input$legendtitle_faceid),
                   legend.text=element_text(size=input$xylegendfontid),plot.margin = margin(1, 0.5, 1, 0.5, "cm"))#t, r, b, l#####,plot.margin = unit(c(1,1,1,1),"cm")
      ####分割线添加#############################################
      if (input$dotted_line){
        req(input$ltyid)
        #writeLog(level = 'INFO', user = 'shinyapp', message = '添加阈值虚线')
        p <- p + geom_vline(xintercept=c(-values$infc,values$infc),lty=input$ltyid,col=input$dotted_line_colid,lwd=input$lwdid,alpha=input$alphaid) + ###lty=2,col="black",lwd=0.7,alpha=0.5
          geom_hline(yintercept = values$inpve,lty=input$ltyid,col=input$dotted_line_colid,lwd=input$lwdid,alpha=input$alphaid)
      }
      #########添加label########################################
      if (ncol(values$data)>3 && input$genename){####前面小于4列情况已默认，把ID作为显示label
        req(input$id_gene_label_id)
        if(input$id_gene_label_id == "首列ID"){
          data$Point.Label <- as.character(data$ID)
        }######重选另一个后，会重新导入原始data，所以此处无需恢复原data########93行已规定3列时输入内容，ID列作为Point.Label列
      }else if (ncol(values$data)<4 && input$genename){
        req(input$no_id_gene_label_id)
      }
      if (input$genename){###输出的data以下进行topFC top P 自定义输入，三种情况处理
        #writeLog(level = 'INFO', user = 'shinyapp', message = '添加散点标签')
        data$Point.Label <- as.character(data$Point.Label)
        data[which(data$Regulated.Type %in% "Unchange"),"Point.Label"] <- ""
        dshowlabel <- c()
        if(input$text_area_list != ""){
          ingenelist <- unlist(str_split(input$text_area_list,"\n"))
          dshowlabel <- data[which((data$Point.Label %in% ingenelist)),"ID"]
        }else{
          if(input$showalllabel){
            dshowlabel <- as.character(data$ID)
          }else{
            dlabelfcid <- c()
            if(input$topfc > 0){
              top_num <- input$topfc
              dfallnonull <- data[which(!(data$Point.Label %in% "")),]
              dfallnonullup <- dfallnonull[which((dfallnonull$Regulated.Type %in% "Up")),]
              dfallnonulldown <- dfallnonull[which((dfallnonull$Regulated.Type %in% "Down")),]
              dfnameup <- dfallnonullup[order(-dfallnonullup$FC),"ID"]#####FC最大,使用ID，唯一，不存在重复，可不用阈值。Point.Label可能存在重复。默认升序
              dfnamedown <- dfallnonulldown[order(dfallnonulldown$FC),"ID"]#####FC最大
              if ((length(dfnameup) < top_num) && (length(dfnamedown) < top_num)){
                dfnamefc <- c(dfnameup,dfnamedown)
              }else if ((length(dfnameup) < top_num) && (length(dfnamedown) >= top_num)){
                dfnamefc <- c(dfnameup,dfnamedown[1:top_num])
              }else if ((length(dfnameup) >= top_num) && (length(dfnamedown) < top_num)){
                dfnamefc <- c(dfnameup[1:top_num],dfnamedown)
              }else if ((length(dfnameup) >= top_num) && (length(dfnamedown) >= top_num)){
                dfnamefc <- c(dfnameup[1:top_num],dfnamedown[1:top_num])
              }
              dlabelfcid <- dfnamefc
            }
            dlabelpvid <- c()
            if(input$toppv > 0){
              top_num <- input$toppv
              dfallnonull <- data[which(!(data$Point.Label %in% "")),]
              dfallpvorder <- dfallnonull[order(dfallnonull$P.value,decreasing =TRUE),"ID"]#####P.value最大,使用ID，唯一，不存在重复，可不用阈值。Point.Label可能存在重复
              if (length(dfallpvorder) < top_num){
                dfnamepv <- dfallpvorder
              }else{
                dfnamepv <- dfallpvorder[1:top_num]
              }
              dlabelpvid <- dfnamepv
            }
            dshowlabel <- c(dlabelfcid,dlabelpvid)
            dshowlabel <- unique(dshowlabel)
          }
        }
        #writeLog(level = 'INFO', user = 'shinyapp', message = '标签选择完毕')
        ####dshowlabel对筛选出的ID列提取对应的Point.Label
        if (is.null(dshowlabel)){
          data[,"Point.Label"] <- ""
        }else{
          df<-as.data.frame(matrix(dshowlabel,ncol=1))
          colnames(df)<-"Gene_id"
          data[which(!(data$ID %in% df$Gene_id)),"Point.Label"] <- ""####符合的保留标签
        }
        if(input$segment_color_id == "white"){
          input_segment_color_id = NULL
        }else{
          input_segment_color_id=input$segment_color_id
        }
        if(input$geom_text_label_id == "纯文字"){
          if(input$lable_color_id == "white"){
            p <- p + geom_text_repel(aes(label = data$Point.Label), size = input$labelsize_id, alpha=0.8,show.legend = FALSE,
                                     segment.color = input_segment_color_id,segment.size = input$segment_size_id,##自定义标签颜色，但上下调点的标签为同一颜色#NULL与上下调散点颜色保持一致
                                     box.padding = input$box_padding_id,##box.padding连接线长度
                                     min.segment.length=0.5,force=3) #geom_label_repel
          }else{
            p <- p + geom_text_repel(aes(label = data$Point.Label), size = input$labelsize_id, alpha=0.8,show.legend = FALSE,
                                     colour = input$lable_color_id,segment.color = input_segment_color_id,segment.size = input$segment_size_id,##自定义标签颜色，但上下调点的标签为同一颜色#NULL与上下调散点颜色保持一致
                                     box.padding = input$box_padding_id,##box.padding连接线长度
                                     min.segment.length=0.5,force=3) #geom_label_repel
          }
        }else{
          if(input$lable_color_id == "white"){
            p <- p + geom_label_repel(aes(label = data$Point.Label), size = input$labelsize_id, alpha=0.8,show.legend = FALSE,
                                     segment.color = input_segment_color_id,segment.size = input$segment_size_id,##自定义标签颜色，但上下调点的标签为同一颜色#NULL与上下调散点颜色保持一致
                                     box.padding = input$box_padding_id,##box.padding连接线长度
                                     min.segment.length=0.5,force=3) #geom_label_repel
          }else{
            p <- p + geom_label_repel(aes(label = data$Point.Label), size = input$labelsize_id, alpha=0.8,show.legend = FALSE,
                                     colour = input$lable_color_id,segment.color = input_segment_color_id,segment.size = input$segment_size_id,##自定义标签颜色，但上下调点的标签为同一颜色#NULL与上下调散点颜色保持一致
                                     box.padding = input$box_padding_id,##box.padding连接线长度
                                     min.segment.length=0.5,force=3) #geom_label_repel
          }
        }
        #writeLog(level = 'INFO', user = 'shinyapp', message = '标签添加完成')
      }
      #########添加label########################################
    }
    values$plotvol <-p ##############################最终绘图
    output$plotvolcano <- renderPlot({ 
      return(p)
      })
    if (is.null(data)){
      dataplottable <-NULL
      }
    output$tablevolcano = renderDataTable({
      datatable(dataplottable,rownames = F,class="row-border hover",extensions = 'Buttons',
                options=list(pageLength = 10,lengthMenu = c(10, 20, 50, 100,-1),
                             dom = 'Blfrtip',scrollX=TRUE,buttons = c('csv', 'excel')))
    })
  })
  ###########------------------------ 参数输入绘图 ----------------------
  observe({
    ######绘图参数输出
    #writeLog(level = 'INFO', user = 'shinyapp', message = '绘图参数输出')
    plot_values_matrix <- rbind(
      c("R version:"," v3.6.3"),
      c("R package(version):"," ggplot2(v3.3.5)"),
      c("FC(Ratio)进行log2计算: ",input$fcid),
      c("FC(Ratio)阈值: ",input$fckazhi),
      c("P Value 进行-log10计算: ",input$pvalueid),
      c("P Value阈值: ",input$pvkazhi),
      c("上调颜色: ",input$up),
      c("非差异颜色: ",input$nodif),
      c("下调颜色: ",input$down),
      c("散点大小: ",input$point),
      c("y轴高度: ",input$yhight),
      c("x轴左侧范围值(负整数)): ",input$xrangel),
      c("x轴右侧范围值(正整数): ",input$xranger),
      c("y轴标签: ",input$ylab),
      c("y轴标签字体大小: ",input$ylabfontid),
      c("y轴标签字体样式: ",input$ylabfaceid),
      c("x轴标签: ",input$xlab),
      c("x轴标签字体大小: ",input$xlabfontid),
      c("x轴标签字体样式: ",input$xlabfaceid),
      c("坐标刻度及图例字体大小: ",input$xylegendfontid),
      c("图例标题字体大小: ",input$legendtitlefontid),
      c("图例标题字体样式: ",input$legendtitle_faceid),
      c("主题选择: ",input$themeid)
    )
    ###############按需添加，需要根据上方选择进行#######################
    if (input$legend_in == '坐标系外') {
      plot_values_matrix <- rbind(
        plot_values_matrix ,
        c("图例位置: ",input$legend_in),
        c("坐标系外位置: ",input$legend_position_id))
    }else{
      plot_values_matrix <- rbind(
        plot_values_matrix ,
        c("图例位置: ",input$legend_in),
        c("图例x轴位置: ",input$legend_x),
        c("图例x轴位置: ",input$legend_y)
      )
    }
    if (input$dotted_line){
      req(input$ltyid)
      plot_values_matrix <- rbind(
        plot_values_matrix ,
        c("线条类型: ",input$ltyid),
        c("线条颜色: ",input$dotted_line_colid),
        c("线条宽度: ",input$lwdid),
        c("线条透明度: ",input$alphaid)
      )
    }
    if (!is.null(values$data) && ncol(values$data)>3 && input$genename){
      req(input$id_gene_label_id)
      plot_values_matrix <- rbind(
        plot_values_matrix ,
        c("展示标签来源: ",input$id_gene_label_id),
        c("展示蛋白FC最大/最小的标签个数: ",input$topfc),
        c("展示蛋白P.value最小的标签个数: ",input$toppv),
        c("展示全部差异蛋白标签: ",input$showalllabel),
        c("标签字体颜色: ",input$lable_color_id),
        c("标签字体: ",input$labelsize_id),
        c("连接线颜色: ",input$segment_color_id),
        c("连接线长: ",input$box_padding_id),
        c("连接线宽: ",input$segment_size_id)
      )
    }
    if (!is.null(values$data) && ncol(values$data)<4 && input$genename){
      req(input$no_id_gene_label_id)
      plot_values_matrix <- rbind(
        plot_values_matrix ,
        c("展示标签来源: ",input$id_gene_label_id),
        c("展示蛋白FC最大/最小的标签个数: ",input$topfc),
        c("展示蛋白P.value最小的标签个数: ",input$toppv),
        c("展示全部差异蛋白标签: ",input$showalllabel),
        c("标签字体颜色: ",input$lable_color_id),
        c("标签字体: ",input$labelsize_id),
        c("连接线颜色: ",input$segment_color_id),
        c("连接线长: ",input$box_padding_id),
        c("连接线宽: ",input$segment_size_id)
      )
    }
    ########################################
    colnames(plot_values_matrix) <- c("Keys","Values")
    values$plot_values_matrix <- plot_values_matrix
  })
  output$plot_values_table <- renderTable({
    return(values$plot_values_matrix)
  })
  observeEvent(input$intro,{
    removeModal()
  })
  #--------------------------- demo data download --------------------------------
  output$downloaddemo=downloadHandler(
    filename = function() {
      paste0("demo_volcano_data",".xlsx")
    },
    content = function(file){
      file.copy(paste0(original_dir,"/www/different_volcano.xlsx"), file)
    }
  )
  ###--------------------------- Export plot --------------------------------
  setwd(tempdir())
  output$plotvolcano.save=downloadHandler(
    filename = function() {
      plotfilename = "Volcano"
      if((input$plotfilename != "") & (input$plotfilename != ".")){
        plotfilename = input$plotfilename
      }
      paste0(plotfilename, ".pdf")
    },
    content = function(file){
      ggsave(filename = file,values$plotvol,width = input$plotvolcano_size$width/70,height = input$plotvolcano_size$height/70)
    },
    contentType = "pdf"
  )
  output$plotvolcanopng.save=downloadHandler(
    filename = function() {
      plotfilename = "Volcano"
      if((input$plotfilename != "") & (input$plotfilename != ".")){
        plotfilename = input$plotfilename
      }
      paste0(plotfilename, ".png")
    },
    content = function(file){
      ggsave(filename = file,values$plotvol,width = input$plotvolcano_size$width/70,height = input$plotvolcano_size$height/70)
    },
    contentType = "png"
  )
  #--------------------------- 参数导出download --------------------------------
  output$save_plot=downloadHandler(
    filename = function() {
      paste0("Volcano_plot_values_matrix",".xlsx")
    },
    content = function(file){
      write.xlsx(values$plot_values_matrix,file=paste0(tempdir(),"/demo_plot_values_matrix.xlsx"),sheetName = "Sheet1",col.names = TRUE,row.names = FALSE)
      file.copy(paste0(tempdir(),"/demo_plot_values_matrix.xlsx"), file)
    },
    contentType = "xlsx"
  )
  #----------------------------------------------------------
  observeEvent(input$disconnect, {
    session$close()
  })
}
