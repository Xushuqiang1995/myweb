rm(list=ls())
library(shiny)
library(shinydashboard)
library(DT)
library(shinyjqui)##图片拖拽大小
library(shinythemes)
library(esquisse)
library(shinyWidgets)
library(shinyjs)
library(shinycssloaders)#等待条
library(shinydisconnect)#自定义断开页面
#library(shinylogs)##logs记录
library(tippy)

#library(shinyFiles)
# author: Yinling Zhu
# Date: 2022/03/28
# update: 2022/06/06

ui=function(request) {
  #use_tracking()##logs记录
  #--------------- Header ------------------------
  header <- dashboardHeader(title = "Volcano Plot",titleWidth = 200)
  #--------------- Sidebar ------------------------
  sidebar <- dashboardSidebar(
    disconnectMessage(
      text = "若上传文件或设置参数运行后出现此界面，表明你上传的数据可能有问题，程序已停止运行。请点击‘Refresh’重新打开工具查看教程，
      严格按照教程示例数据修改你的文件及格式，再做尝试！",
      refresh = "Refresh" ), # import dependencies#自定义断开页面
    actionButton("disconnect", "Disconnect the app"),
    collapsed = TRUE,###折叠侧边栏
    useShinyjs(),
    width = 200,
    sidebarMenu(
      id = "tabs",
      menuItem("Volcano", tabName = "tabplot", icon = icon("barcode"))
      )
  )
  #--------------- Body ------------------------
  theme_choices <- esquisse:::get_themes()[1:2] ####去掉par solid
  #theme_choices$ggthemes$par <- NULL
  theme_choices$ggthemes$solid <- NULL
  body <- dashboardBody(
    theme = shinytheme(theme="flatly"),
    #style="background-color:white;",##将全局默认背景改为白色
    tabItems(
      tabItem("tabplot",
              fluidRow(
                column(4,
                       h4("参数"),
                       tabsetPanel(
                         tabPanel("数据&参数",
                                  div(style = "background-color: white; padding-left: 5px; padding-top: 25px; padding-right: 5px; margin-bottom: 5px;",
                                      fluidRow(###横排分割，宽度1-12整数，相对宽度无法精细
                                        column(3,h5(strong("上传绘图数据："))),
                                        column(5,fileInput(inputId = "file",accept = c(".txt",".csv",".xls",".xlsx"),label=NULL,
                                                           placeholder = "xlsx/txt/csv/xls",buttonLabel = "选择文件")),
                                        column(4,style='float:left;',tags$h5(tags$a(icon("download"),downloadLink("downloaddemo","下载示例文件"))))
                                      )
                                  ),
                                  div(style = "background-color: white; padding-left: 5px; padding-right: 5px; margin-bottom: 5px;",
                                      fluidRow(
                                        column(3,style = "padding-top: 10px;",checkboxInput("fcid",strong("FC(Ratio) 进行log2计算"), TRUE)),
                                        column(3,style = "padding-top: 5px;",numericInput("fckazhi", label="FC(Ratio) 阈值:",value = 2, step = 0.1,min = 1)),
                                        column(3,style = "padding-top: 10px;",checkboxInput("pvalueid",strong("P Value 进行-log10计算"), TRUE)),
                                        column(3,style = "padding-top: 5px;",numericInput("pvkazhi", label="P Value阈值:",value = 0.05, step = 0.01,min = 0))
                                      )
                                  ),
                                  div(style = "background-color: white; padding-left: 5px; padding-right: 5px; margin-bottom: 5px;",
                                      fluidRow(
                                        column(4,colourpicker::colourInput('up', "上调","#FC8D62")),
                                        column(4,colourpicker::colourInput('nodif', "非差异","gray")),
                                        column(4,colourpicker::colourInput('down', "下调","#66C2A5"))
                                      )),
                                  div(style = "background-color: white; padding-left: 5px; padding-right: 5px; margin-bottom: 5px;",####wellPanel###默认浅黄色背景
                                      fluidRow(
                                        column(2,numericInput("point", "散点大小:", 3,width  = NULL)),
                                        column(2,numericInput("pointalpha", "透明度:", 0.9,max = 1, step = 0.1,min = 0)),
                                        column(4,textInput(inputId="xrangel", label="x轴左侧范围值(负整数)):", value = "",placeholder = "-5",width  = NULL)),###x轴范围左,placeholder = "Auto"
                                        column(4,textInput(inputId="xranger", label="x轴右侧范围值(正整数):", value = "",placeholder = "5",width  = NULL)))#,###y轴范围右,placeholder = "Auto"
                                  ),
                                  div(style = "background-color: white; padding-left: 5px; padding-right: 5px; margin-bottom: 5px;",
                                      fluidRow(
                                        column(5,textInput(inputId="xlab", label="x轴标签:", value = "Log2 FC",width  = NULL)),
                                        column(3,numericInput("xlabfontid", "x轴标签字体大小:", 16,width  = NULL)),
                                        column(4,pickerInput(inputId = "xlabfaceid",label = "x轴标签字体样式:",
                                                             choices = c("plain", "italic", "bold", "bold.italic"),selected = "bold"))
                                        ),
                                      tippy_this('xlab', tooltip = "在特定情况下，'Log2 FC'会被强制转为'FC'，'FC'会被强制转为'Log2 FC'，其他任何字段都会正常显示在图形中。", 
                                                 animation = "scale",duration = 1000, placement = "bottom",theme = "translucent"),
                                      fluidRow(
                                        column(2,textInput(inputId="yhight", label="y轴高度:", value = "",placeholder = "8",width  = NULL)),###y轴高度
                                        column(3,textInput(inputId="ylab", label="y轴标签:", value = "-Log10 P value",width  = NULL)),
                                        column(3,numericInput("ylabfontid", "y轴标签字体大小:", 16,width  = NULL,min = 1)),
                                        column(4,pickerInput(inputId = "ylabfaceid",label = "y轴标签字体样式:",
                                                             choices = c("plain", "italic", "bold", "bold.italic"),selected = "bold"))
                                      ),
                                      tippy_this('ylab', tooltip = "在特定情况下，'-Log10 P value'会被强制转为'P value'，'P value'会被强制转为'-Log10 P value'，其他任何字段都会正常显示在图形中。", 
                                                 animation = "scale",duration = 1000, placement = "bottom",theme = "translucent")
                                  ),
                                  div(style = "background-color: white; padding-left: 5px; padding-right: 5px; margin-bottom: 5px;",
                                      fluidRow(
                                        column(4,awesomeRadio(inputId = "legend_in",label = "图例位置",choices = c("坐标系外", "坐标系内"),
                                                              selected = "坐标系外",inline = TRUE,checkbox = TRUE)),
                                        column(8,uiOutput("legend_position_ui"))),
                                      fluidRow(
                                        column(4,numericInput("xylegendfontid", "坐标刻度及图例字体大小:", 16,width  = NULL)),
                                        column(4,numericInput("legendtitlefontid", "图例标题字体大小:", 16,width  = NULL)),
                                        column(4,pickerInput(inputId = "legendtitle_faceid",label = "图例标题字体样式:",
                                                             choices = c("plain", "italic", "bold", "bold.italic"),selected = "bold")))
                                  ),
                                  div(style = "background-color: white; padding-left: 5px; padding-right: 5px; margin-bottom: 5px;",
                                      tippy(
                                        checkboxInput("dotted_line",strong("添加阈值虚线"), FALSE), 
                                        tooltip = "点击添加阈值虚线，并对虚线格式进行修改！", animation = "scale",
                                        duration = 1000, placement = "top-start",theme = "translucent"),
                                      uiOutput("dotted_line_style_ui")####分割线调整
                                  ),
                                  div(style = "background-color: white; padding-left: 5px; padding-right: 5px; margin-bottom: 5px;",
                                      tippy(
                                        checkboxInput("genename",strong("添加散点标签"), FALSE), 
                                        tooltip = "点击添加散点标签，并对标签格式进行修改！", animation = "scale",
                                        duration = 1000, placement = "bottom-start",theme = "translucent"),
                                      
                                      fluidRow(
                                        column(6,uiOutput("id_gene_label_ui")),###展示标签来源
                                        column(6,uiOutput("geom_text_label_ui"))
                                      ),
                                      uiOutput("gene_label_text_ui")
                                      ),
                                  pickerInput(inputId = "themeid",label = "主题选择:",choices = theme_choices,#######esquisse:::get_themes()[1:2],
                                              selected = "theme_bw")
                         ),
                         tabPanel("已传数据预览",
                                  br(),
                                  p(style="color:black","注意: 表格仅展示上传数据的前10行"),
                                  br(),
                                  br(),
                                  withSpinner(dataTableOutput('tableupdate'),type = 4)
                                  )
                         )
                ),
                column(5,h4("结果"),
                       tabsetPanel(
                         tabPanel("图片&下载",
                                  br(),
                                  fluidRow(
                                    column(4,textInput("plotfilename",label="下载文件名：",value = "Volcano_plot")),
                                    column(2,style='padding: 24px;',downloadButton('plotvolcano.save',label = 'Export pdf')),#####padding-left: 40px;
                                    column(2,style='padding: 24px;',downloadButton('plotvolcanopng.save',label = 'Export png')),##
                                    column(3,style='padding: 24px;',downloadButton('save_plot',label = '导出绘图参数',width = NULL))
                                  ),
                                  p(style="color:black","注意:图片右下方‘三角符号’可拖拽，以改变下载图片的宽度和高度"),
                                  withSpinner(jqui_resizable(plotOutput("plotvolcano", width = "750px", height = "550px")),type=4)
                         ),
                         tabPanel("绘图数据",
                                  br(),
                                  p(style="color:black","注意:表格每页展示条数选-1,再点击CVS或Excel，可下载全部数据"),
                                  withSpinner(dataTableOutput("tablevolcano"),type = 4)
                         ),
                         tabPanel("绘图参数汇总",
                                  br(),
                                  p("下方为本次绘图主要参数，可点击导出按钮保存到本地，便于后期查找或重现。"),
                                  #downloadButton('save_plot',label = '导出绘图参数',width = NULL),
                                  tableOutput('plot_values_table')
                         )
                       )
                       ),
                column(3,h4("说明"),
                       tabsetPanel(
                         tabPanel("使用教程",
                                  div(style="margin:0px 12px;max-height: 800px; overflow-y: auto;",
                                      #a("查看教程",href="https://www.bilibili.com/video/av77519185/",target="_blank"),
                                      h4(align="center",tags$b("使用教程")),
                                      h4(tags$b("简介：")),
                                      p("火山图是一种直观展示两个样本间蛋白/基因差异表达的分布图。"),
                                      h4(tags$b("适用范围：")),
                                      p("适用于转录组、蛋白组、代谢组、微生物等差异数据的可视化，数据需包括Radio(FC)和P值。"),
                                      h4(tags$b("输入：")),
                                      p("输入数据必须列有：",strong("蛋白/基因ID，两组样本表达比值，P值"),"。三列顺序固定，表头可自定义填写。可额外在第4列添加散点标签。
                                        第一列蛋白/基因名必须是唯一的，不可存在重复名称（修饰组数据第一列可用：蛋白名_氨基酸+位点 组合在一起，如P39069_S321）。"),
                                      p("文件格式包括txt(制表符分隔)文本文件、csv(逗号分隔)文本文件、以及Excel专用的xlsx格式，同样支持旧版Excel的xls(Excel 97-2003 )格式。"),
                                      p("此工具内置demo文件，可下载此demo文件，在此文件格式上进行修改添加，下载的示例输入文件为：demo_volcano_data.xlsx"),
                                      div(align="center",tags$img(src="demo_data_volcano.png",heigth="90%",width="90%")),
                                      h4(tags$b("下载：")),
                                      p("可填写自定义下载文件名，可拖拽以改变图片大小和比例，再点击下载按钮导出pdf/png格式高清图片。可点击导出按钮将主要绘图参数保存到本地，便于后期查找或重现。"),
                                      div(align="center",tags$img(src="downtz.png",heigth="100%",width="100%")),
                                      h4(tags$b("已传数据预览&绘图数据：")),
                                      p("已传数据预览存在数据表明数据已上传成功，绘图数据为经过筛选和处理后的数据。本脚本会去除Radio(FC)或者P value有缺失的蛋白。"),
                                      h4(tags$b("绘图参数导出：")),
                                      p("给出脚本所用R软件及R包版本，并记录主要绘图参数值，可以导出为plot_values_matrix.xlsx，便于后期查找或重现。"),
                                      br(),
                                      h4(tags$b("参数说明：")),
                                      p(strong("log计算："),"log计算是数据展示的一个方法，适用于数据的分布范围跨数量级的情况，增强图片的可视化效果。
                                        若输入文件中存在负值，默认不再进行log转换。若FC(Ratio)存在0值，则会强制更改为1，若P Value列存在0值，则会强制更改为10^-8(极小值)。
                                        你也可以在输入文件中自行更改为任意极小值。"),
                                      p(strong("FC(Ratio) 阈值："),"即差异倍数，用于计算蛋白是否在比较组内是差异的。注意：请按照输入文件原本数据进行填写，若文件上传前已经进行过log，
                                        则此处填写阈值也需是log后的，若上传前未经过log，无论FC在工具内选择是否进行log，此处阈值均填未经log计算的原始值。"),
                                      p(strong("P Value阈值："),"重复性检验P值，判断样本重复是否具有统计学意义，一般需小于0.05。"),
                                      p(strong("颜色选择："),"可鼠标点击选择适合的颜色，也可直接输入十六进制颜色代码。"),
                                      p(strong("x轴左侧范围值(负整数))："),"x轴显示的范围。左侧数值为负整数。"),
                                      p(strong("x轴右侧范围值(正整数)："),"x轴显示的范围。右侧数值为正整数。"),
                                      p(strong("图例位置："),"可选坐标系外或坐标系内，选择坐标系外时，可选择放置在图片上下左右；选择坐标系内时，可自定义填写图例位置。"),
                                      p(strong("添加阈值虚线："),"点击添加阈值虚线，并可对虚线格式进行修改。"),
                                      p(strong("添加散点标签："),"点击添加散点标签，并可对标签格式进行修改。"),
                                      p(HTML('&emsp;&emsp;'),"展示标签来源: 若上传文件仅三列数据，则此处默认第一列ID作为展示标签；若上传文件包含四列数据，则此处将第四列数据作为备选展示标签。"),
                                      p(HTML('&emsp;&emsp;'),"三种显示散点标签的方式优先级依次增加，后面会覆盖前面，若想恢复前面显示标签方式，
                                      只需将后面的恢复默认！自定义输入时，每行填写一个蛋白或基因名，最好从表格中直接复制，避免输错导致不显示！"),
                                      p(HTML('&emsp;&emsp;'),"标签字体颜色&连接线颜色：默认为'white'，此时标签与连接线同色，区分上下调颜色并分别跟随蛋白上下调的颜色!
                                        若选择其他颜色，展示出的蛋白标签均变为新选择的颜色，且连接线颜色同时会跟随改变！若想恢复默认，选择'white'即可！"),
                                      p(strong("主题选择："),"多种主题可供选择。")
                                      )
                                  ),
                         tabPanel("常见问题",
                                  br(),
                                  p(tags$b("Q1. 各参数控件排序杂乱，挤压显示不全。")),
                                  p("请全屏显示，并尽量使用谷歌浏览器登录云平台运行工具，部分浏览器可能不兼容，页面布局出现比例失调等情况。"),
                                  p(tags$b("Q2.页面变灰（即灰屏）无法操作问题排查")),
                                  p("出现此现象表示工具运行错误，主要有以下情况:1) 若从工具列表打开即出现灰屏，则可能是浏览器或网络问题；
                                    2) 若工具正常打开，但在传输数据后出现灰屏，则表明上传数据文件不符合要求，请按照教程，对照demo数据仔细排查，
                                    注意：表头是否符合要求（无缺失或#等），行列名是否有重复，数字列中是否有非数字字符（NA、#N/A等）。"),
                                  p("若自行排查后，依然出现灰屏，可联系对应销售经理或项目管理，并提供数据文件，我们会帮助排查。")),
                         tabPanel("工具开发者",
                                  br(),
                                  p("版本号："),
                                  p("v1.0.2"),
                                  p("开发者："),
                                  p("景杰生信部zyl"),
                                  p("维护者："),
                                  p("景杰生信部zyl"),
                                  p("发布日期："),
                                  p("2022-06-06"),
                                  br(),
                                  br(),
                                  p("更新日期：2022-07-21"),
                                  p("1.解决原始文件为log后数据 不能正常显示上下调蛋白的BUG；"),
                                  p("2.解决坐标轴标签被强制变更无法自行填写的BUG；"),
                                  p("3.添加FC阈值填写说明，指导正确填写阈值；"),
                                  p("4.修正无法导出绘图参数表格并迁移下载按钮。"),
                                  br(),
                                  p("更新日期：2022-06-15"),
                                  p("更新内容："),
                                  p("1.添加散点透明度调整按钮；"),
                                  p("2.添加点标签是否选择带背景框；")
                                  )
                       )
                       )
              )
      )
    )
  )
  #--------------- Page ------------------------
  dashboardPage(title = 'VolcanoWebapp',skin = "blue",header,sidebar, body)
}
