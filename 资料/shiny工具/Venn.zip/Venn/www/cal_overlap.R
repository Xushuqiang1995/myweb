library(tidyverse)
library(readxl)
# d: 数据导入和预处理，剔除NA/''等
rm(list = ls())
d <- read_xlsx(path = './shiny_venn/Demo_Venn_5.xlsx') %>%
  as.list() %>% 
  map(., ~ na.omit(.x)) %>%        # 在读取整个表格(xlsx)时，列数据集的元素个数不一致，会有NA存在
  map(., ~ as.character(.x)) %>%   # 不记得了
  map(., ~ .x[.x !=''])            # 如果是txt文件，缺失值可能是‘’

# m0: m0每行表示一种状态/排列组合，TRUE表示元素存在该数据集中，FALSE表示元素不在该数据集中
# 将每行的数据分为TRUE和FALSE 2组，分别取交集和并集
for(k in 1:length(d)){
  if(k == 1){
    m <- tibble(c(TRUE, FALSE))
  } else {
    m <- cbind(m, tibble(c(TRUE, FALSE)))
  }
}
m0 <- m %>% 
  set_names(names(d)) %>% 
  expand.grid() %>% 
  mutate(s = rowSums(.)) %>% 
  filter(s != 0) %>% 
  select(-s)


# Set函数，m0中为TRUE 的列取交集，设定type=int
#                FALSE的列取并集，设定type=uni
Set <- function(data, data_name, type){
  # data: list列表，含所有的数据集
  # data_name: 
  #       如果取交集， type=int，即set_1集合
  #       如果取并集， type=uni，即set_0集合
  # 递归函数，1表示求所有TRUE集合的交集，0表示求所有FALSE集合的并集
  
  n <- length(data_name) # 查看d_1的数据集个数
  if(n == 1){
    return(data[[data_name]])
  } else if(n == 0){
    return(NULL)
  } else{
    set0_name <- data_name[n] # 最后一个数据集的名称
    set0 <- data[[set0_name]] # 提取最后一个数据集
    
    data_new <- data
    data_name_update <- data_name[-n]
    
    # switch(type,
    #   int = intersect(set0, Set(data = data, data_name = data_name[-n], type = 'int')) ,
    #   uni =     union(set0, Set(data = data, data_name = data_name[-n], type = 'uni')) # %>% return()
    # ) %>% return()
  
    if (type == 1) { # 返回交集
      intersect(set0,
                Set(data = data, data_name = data_name[-n], type = 1)) %>%
        return()
    } else {         # 返回并集，type == 0
      union(set0,
            Set(data = data, data_name = data_name[-n], type = 0)) %>%
        return()
    }
  }
}

m_intersect <- m_union <- list()
for (i in seq(nrow(m0))) {
  m_intersect[[i]] <- m0[i,] %>% as_vector() %>% names(d)[.]
  m_union[[i]] <- (!m0[i,]) %>% as_vector() %>% names(d)[.]
}

m1 <- m0 %>% 
  mutate(intersect = m_intersect,
         union = m_union) %>% 
  mutate(intersect_set = map(.x = intersect, ~ Set(data = d, data_name = .x, type = 1)),
         union_set = map(.x = union, ~ Set(data = d, data_name = .x, type = 0))) %>% 
  as_tibble() %>% 
  mutate(sets = map2(.x = intersect_set, .y = union_set, .f = ~ setdiff(.x, .y)), 
         number = map(.x = sets, .f = ~ length(.x)),
         number = as_vector(number)) %>% 
  dplyr::select(-intersect_set, -union_set) %>% 
  relocate(number, .before = sets);m1
m2 <- m1 %>% 
  mutate(sets = map(.x = sets, .f = ~ paste0(.x, collapse = ';')),
         intersect = map(.x = intersect, .f = ~ paste0(.x, collapse = ';')) %>% unlist(),
         union = map(.x = union, .f = ~ paste0(.x, collapse = ';')) %>% unlist(),
         
         intersect = str_replace_all(intersect, ';', '+'),
         union = str_replace_all(union, ';', '∪'),
         # type = paste(intersect,' - ', union)
         type = intersect
         ) %>% 
  select(-intersect, -union) %>%
  relocate(type) %>% 
  separate_rows(sets, sep = ';');m2

openxlsx::write.xlsx(x = m2, file = 'test1.xlsx')


# 将m0每行状态的集合，即想得到的数据
# s <- function(data0, data_name_1, data_name_0) {
#   # 元素在d_1的公共集中，而不在d_0的并集中
#   set_1 <- Set(data = data0, data_name = data_name_1, type = 1)
#   set_0 <- Set(data = data0, data_name = data_name_0, type = 0)
#   
#   if(is.null(set_1)){
#     return(NULL)
#   } else{
#     return(setdiff(set_1, set_0))
#   }
# }

# 导出数据 --------------------------------------------------------------------
inter_len <- NULL
dir.create('Overlap_list')
file_list <- NULL
for(i in seq_len(nrow(m0))){
  # d_1：表示  需要的数据集名称names(d)[d_1]，并通过Set求d_1中所有数据集中的公共元素，得到交集，inner_T
  # d_0：表示不需要的数据集名称names(d)[d_0]，并通过Set求d_0中所有数据集中的所有元素，得到并集，union_F
  m1 <- as_vector(m0[i, ])
  if(sum(!m1) == 0){
    d_1 <- names(d)[m1]
    d_0 <- NULL
  } else {
    d_1 <- names(d)[m1]
    d_0 <- names(d)[!m1]
  }
  
  # 输出文件名，且xlsx保存在./Overlap_list/目录下
  file_name_full <- d_1 %>% 
    paste0(collapse = '_') %>% 
    paste0('./Overlap_list/',.) %>% 
    paste0('.xlsx') %>% 
    print()
  inter <- s(data = d, data_name_1 = d_1, data_name_0 = d_0)
  inter_len <- c(inter_len, length(inter))
  file_list <- c(file_list, file_name_full)
  write.xlsx(x = inter, file = file_name_full, col.names = FALSE, row.names = FALSE)
}

# 输出all_summary/readme文件
file_summary <- m0 %>% 
  mutate('Summary' = inter_len)
read_me <- c("Overlap_list文件夹下，含有 2^n-1 个xlsx文件，和一个all_summary.xlsx。假设对5个数据集绘制韦恩图，
              集合名称分别为set1,set,set3,set4,set5。
在all_summary.xlsx文件中，第一行表示集合名称，表格中TRUE表示元素在该数据集中，FALSE表示元素不在
              该数据集。Summary列表示元素的个数，元素仅存在于表示值为TRUE的列名中，而不在值为
              FALSE的列名。
剩下的xlsx文件则为具体的交集元素，如果后缀的文件名为set1_set2_set4，该集合表示元素仅存在集合set1、
              set2、set4中，并且不在集合set3, set5中")


write.xlsx(x = file_summary, file = "./Overlap_list/all_summary.xlsx", col.names = TRUE, row.names = FALSE)
write.csv(x = read_me, file = "./Overlap_list/readme.txt", row.names = FALSE)
# 在客户上传文件前，需要清空.zip/xlsx文件

zip::zip('Overlap_list.zip', files = 'Overlap_list' ) # 压缩文件夹
file.remove(file_list)                                # 清空文件夹内容（删除，避免重复上传）


