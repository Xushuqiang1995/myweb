options(encoding = 'utf-8')

# Packages to library -----------------------------------------------------
## 数据处理和画图
library(tidyverse)              # 数据处理/转换
library(readxl)                 # 读取xlsx文件
library(ggthemes)               # 调整ggplot画图主题
library(dtplyr)                 # dtplyr::lazy_dt()将数据框转换成data.table类型进行运算处理，自动将dplyr/tidyr函数转换成data.table的处理函数
library(data.table)             # data.table的运行速度相比data.frame/tibble更快
library(VennDiagram)            # 绘制Venn图
## Shiny展示效果拓展相关包
library(DT)                     # 用于输出数据框显示
library(shiny)                  # 涉及shiny的主要内容，fileInput()/tableOutput()等传参函数，observe()/req()/valid()等条件相应函数
library(shinydashboard)         # 不同于shiny的UI框架，由dashboardHeader()/dashboardSidebar()/dashboardBody()函数构成UI结构
library(shinythemes)            # 主要在ui端设置背景板颜色，在dashboardBody()函数内
library(esquisse)               # # 拖动选择变量的过程，即drag-and-drop，但是这里好像用不到;esquisse:::get_theme()获取ggplot所有的theme设置
library(shinyWidgets)           # 丰富shiny控件内容，通过shinyWidgets::shinyWidgetsGallery()可查看
library(shinyjs)                # shinyjs将JavaScript封装成函数，或者自己的js，可以直接调用
library(shinyFeedback)          # 如果文件类型/数据不符合要求，则给出警告反馈；主要用shinyFeedback::feedbackDanger()函数
library(shinycssloaders)        # 程序运行加载（等待）条，主要应用在画图加载时，使用 withSpinner()
library(Cairo)                  # 使用Cairo图形库进行渲染，解决 Times New Romance等字体在生成pdf过程中报错的问题(参考：https://www.jianshu.com/p/c81d829bfbd6)
# 好像没用到？
library(shinydisconnect)        # 自定义断开页面，如果用户上传数据不符合要求，则断开连接，无法接下来的操作



# server.R 给图片添加文本字体 --------------------------------------------------------------------
### 从google字体库中下载字体
# font_add_google("Gochi Hand", "gochi")
# font_add_google("Schoolbell", "bell")
# font_add_google("Covered By Your Grace", "grace")
# font_add_google("Rock Salt", "rock")
# font_add_google("Rock Salt", "rock")

### 新增字体 
### 
# 参考资料：https://luansheng.netlify.app/2017/12/31/using-other-system-chinese-fonts-in-r/
# 需要了解字体和字体家族，其实不需要用到font_add_google()等内容
library(showtext)
# font_families() # 查看已有字体
# # font_paths()    # 查看当前系统字体文件所在路径
# font_files()    # 查看当前系统字体文件所在路径
# # font_files() %>% view()
# font_add(family = "Times New Roman",
#          regular = "FreeSerif.ttf",
#          bold = "FreeSerifBold.ttf",
#          italic = 'FreeSerifItalic.ttf',
#          bolditalic = 'FreeSerifBoldItalic.ttf')
# font_add(family = "Arial",regular = "FreeSans.ttf",
#          bold = "FreeSansBold.ttf",
#          italic = "FreeSansBoldOblique.ttf",
#          bolditalic = "FreeSansOblique.ttf")
# font_add(family = "Calibri",
#          regular = "FreeSans.ttf",
#          bold = "FreeSansBold.ttf",
#          italic = "FreeSansBoldOblique.ttf",
#          bolditalic = "FreeSansOblique.ttf")
font_add(family = "Times New Roman",regular = "/usr/share/fonts/truetype/dejavu/TIMES.TTF",bold = "/usr/share/fonts/truetype/dejavu/TIMESBD.TTF",
         italic = "/usr/share/fonts/truetype/dejavu/TIMESI.TTF", bolditalic = "/usr/share/fonts/truetype/dejavu/TIMESBI.TTF")
font_add(family = "Arial",regular = "/usr/share/fonts/truetype/dejavu/ARIAL.TTF",bold = "/usr/share/fonts/truetype/dejavu/ARIALBD.TTF",
         italic = "/usr/share/fonts/truetype/dejavu/ARIALI.TTF", bolditalic = "/usr/share/fonts/truetype/dejavu/ARIALBI.TTF")
font_add(family = "Calibri",regular = "/usr/share/fonts/truetype/dejavu/CALIBRI.TTF",bold = "/usr/share/fonts/truetype/dejavu/CALIBRIB.TTF",
         italic = "/usr/share/fonts/truetype/dejavu/CALIBRII.TTF", bolditalic = "/usr/share/fonts/truetype/dejavu/CALIBRIZ.TTF")
showtext::showtext_auto()



# server.R 调用display_venn/display_venn0用于图展示与下载 --------------------------------------------

# 图形输出
display_venn <- function(x, ...){
  library(VennDiagram)
  grid.newpage()
  venn_object <- venn.diagram(x, filename = NULL, ...)
  grid.draw(venn_object)
}

# 图形下载
display_venn0 <- function(x, ...){
  library(VennDiagram)
  # grid.newpage()
  venn_object <- venn.diagram(x, filename = NULL, ...)
  grid.draw(venn_object)
}

# overlap数据处理完整示例 V0 调用Set函数：求多个集合的交集与并集------------------

Set <- function(data, data_name, type){
  # data: list列表，含所有的数据集
  # data_name:
  #       如果取交集， type=1，即set_1集合
  #       如果取并集， type=0，即set_0集合

  n <- length(data_name) # 查看d_1的数据集个数
  if(n == 1){
    return(data[[data_name]])
  } else if(n == 0){
    return(NULL)
  } else{
    set0_name <- data_name[n] # 最后一个数据集的名称
    set0 <- data[[set0_name]] # 提取最后一个数据集

    data_new <- data
    data_name_update <- data_name[-n]

    # 递归函数，1表示求所有TRUE集合的交集，0表示求所有FALSE集合的并集
    if (type == 1) { # 返回交集
      intersect(set0,
                Set(data = data, data_name = data_name[-n], type = 1)) %>%
        return()
    } else {         # 返回并集，type == 0
      union(set0,
            Set(data = data, data_name = data_name[-n], type = 0)) %>%
        return()
    }
  }
}


# overlap数据处理完整示例 V0 -----------------------------------------------------------
# 需要调用global.R中的Set函数
### 思路
# 1. 列举所有集合overlap情况，每个集合要么是交集类，要么是差集类
# 2. 对交集类：提取"公共"元素
# 3. 对差集类：提取"所有"元素
# 4. 交集类元素 - 差集类元素，则元素只在交集类的每一个集合中，而不在差集类的每一个集合中
# t1 <- proc.time()
# library(tidyverse)
# library(readxl)
# ### 任取一个venn图数据
# d <- read_xlsx(path = './shiny_venn/www/Demo_Venn_5.xlsx') %>%
#   as.list() %>%
#   map(., ~ na.omit(.x)) %>%        # 在读取整个表格(xlsx)时，列数据集的元素个数不一致，会有NA存在
#   map(., ~ as.character(.x)) %>%   # 不记得了
#   map(., ~ .x[.x !=''])            # 如果是txt文件，缺失值可能是‘’
# 
# # 1. 列举所有集合overlap情况，得到m0，每个集合要么是交集类，要么是差集类
# for(k in 1:length(d)){
#   if(k == 1){
#     m <- tibble(c(TRUE, FALSE))
#   } else {
#     m <- cbind(m, tibble(c(TRUE, FALSE)))
#   }
# }
# m0 <- m %>%
#   set_names(names(d)) %>%
#   expand.grid() %>%
#   mutate(s = rowSums(.)) %>%
#   filter(s != 0) %>%
#   select(-s)
# 
# m_intersect <- m_union <- list()
# for (i in seq(nrow(m0))) {
#   #
#   m_intersect[[i]] <- m0[i,] %>% as_vector() %>% names(d)[.]
#   m_union[[i]] <- (!m0[i,]) %>% as_vector() %>% names(d)[.]
# }
# m0 <- m0 %>%
#   as_tibble() %>%
#   mutate(intersect = m_intersect,
#          union = m_union)
# 
# ### 思路2/3/4，得到m1、m2俩种数据表达形式
# m1 <- m0 %>%
#   # 2. 对交集类：提取"公共"元素
#   # 3. 对差集类：提取"所有"元素
#   mutate(intersect_set = map(.x = intersect, ~ Set(data = d, data_name = .x, type = 1)),
#          union_set = map(.x = union, ~ Set(data = d, data_name = .x, type = 0))) %>%
#   # 4. 交集类元素 - 差集类元素，则元素只在交集类的每一个集合中，而不在差集类的每一个集合中
#   mutate(sets = map2(.x = intersect_set, .y = union_set, .f = ~ setdiff(.x, .y)),
#          number = map(.x = sets, .f = ~ length(.x)),
#          number = as_vector(number)) %>%
#   dplyr::select(-intersect_set, -union_set) %>%
#   relocate(number, .before = sets)
# 
# 
# m2 <- m1 %>%
#   mutate(sets = map(.x = sets, .f = ~ paste0(.x, collapse = ';')),
#          intersect = map(.x = intersect, .f = ~ paste0(.x, collapse = ';')) %>% unlist(),
#          union = map(.x = union, .f = ~ paste0(.x, collapse = ';')) %>% unlist(),
#          intersect = str_replace_all(intersect, ';', '+'),
#          union = str_replace_all(union, ';', '∪'),
#          type = intersect) %>%
#   select(-intersect, -union) %>%
#   relocate(type) %>%
#   separate_rows(sets, sep = ';')
# 
# t2 <- proc.time()
# t2 - t1
# overlap数据处理完整示例 V1 -----------------------------------------------------------
# d0 <- read_xlsx(path = "./shiny_venn/www/Demo_Venn_5.xlsx") %>%  as.list() %>%
#   map(., ~ na.omit(.x)) %>%
#   map(., ~ as.character(.x)) %>%
#   map(., ~ .x[.x != ""])
# 
# m0 <- list(c(TRUE, FALSE)) %>% 
#   rep(length(d0)) %>% 
#   expand.grid() %>%
#   set_names(names(d0)) %>%
#   mutate(s = rowSums(.)) %>%
#   filter(s != 0) %>%
#   select(-s)
# 
# m_int <- m_uni <- list()
# for (i in seq(nrow(m0))) {
#   m_int[[i]] <- m0[i,] %>% 
#     as_vector() %>% 
#     names(d0)[.] %>% 
#     sapply(X = ., FUN = list) %>% 
#     sapply(X = ., FUN = function(x) d0[[x]])
#   m_uni[[i]] <- (!m0[i,]) %>%
#     as_vector() %>% 
#     names(d0)[.] %>% 
#     sapply(X = ., FUN = list) %>% 
#     sapply(X = ., FUN = function(x) d0[[x]])
#   if (length(m_int[[i]]) == 0) {
#     m_int[[i]] <- NULL
#   }  else if (is.character(m_int[[i]])){
#     m_int[[i]] <- list(m_int[[i]])
#   }
#   
#   if (length(m_uni[[i]]) == 0) {
#     m_uni[[i]] <- NULL
#   }  else if (is.character(m_uni[[i]])){
#     m_uni[[i]] <- list(m_uni[[i]])
#   }
# }
# 
# rm_null <- function(x){
#   if(length(x) == 0) {
#     NULL
#   } 
#   else {
#     x
#   }
# }
# 
# m2 <- m0 %>%
#   as_tibble() %>%
#   mutate(int = m_int, uni = m_uni) %>% 
#   select(-(ksp:hsa)) %>% 
#   mutate(int_set = map(.x = int, .f = rm_null),
#          int_set0 = map(.x = int, .f = ~ reduce(.x = .x, .f = intersect)),
#          uni_set = map(.x = uni, .f = rm_null),
#          uni_set0 = map(.x = uni, .f = function(x){
#            if(length(x) <= 1){
#              as_vector(x)
#            } else {
#              reduce(.x = x, .f = union)}
#          })) %>% 
#   mutate(int_set1 = map2(.x = int_set0, .y = uni_set0, .f = ~ setdiff(x = .x, y = .y)))
# 
# map(.x = m2$int_set1, .f = length) %>% unlist()
# 
# 
# ### 思路2/3/4，得到m1/m2俩种数据表达形式
# m1 <<- m0 %>%
#   ### 2. 对交集类：提取"公共"元素
#   ### 3. 对差集类：提取"所有"元素
#   mutate(intersect_set = map(.x = intersect, ~ Set(data = d0, data_name = .x, type = 1)),
#          union_set = map(.x = union, ~ Set(data = d0, data_name = .x, type = 0))) %>%
#   ### 4. 交集类元素 - 差集类元素，则元素只在交集类的每一个集合中，而不在差集类的每一个集合中
#   mutate(sets = map2(.x = intersect_set, .y = union_set, .f = ~ setdiff(.x, .y)),
#          count = map(.x = sets, .f = ~ length(.x)),
#          count = as_vector(count)) %>%
#   dplyr::select(-intersect_set, -union_set) %>%
#   relocate(count, .before = sets) %>%
#   dplyr::select(-union)
# 
# m2 <<- m1 %>%
#   mutate(sets = map(.x = sets, .f = ~ paste0(.x, collapse = ';')),
#          'intersect' = map(.x = 'intersect', .f = ~ paste0(.x, collapse = ';')) %>% unlist(),
#          'union' = map(.x = 'union', .f = ~ paste0(.x, collapse = ';')) %>% unlist(),
#          intersect = str_replace_all(intersect, ';', '+'),
#          union = str_replace_all(union, ';', '∪'),
#          type = intersect) %>%
#   select(-'intersect') %>%
#   relocate(type) %>%
#   separate_rows(sets, sep = ';')

# overlap数据处理完整示例 V2 ------------------------------------------------------
## 使用purrr函数式编程思想，可以广泛替换循环语句、递归语句，使得代码更简洁，但本质上还是循环
## 如果想提高运算效率，建议使用data.table和tidyfst进行数据处理，适合读取、处理GB级数据

# # 思路1：将数据清理为列表形式
# t1 <- proc.time()
# d0 <- read_xlsx(path = "./shiny_venn/www/Demo_Venn_5.xlsx") %>%  
#   as.list() %>%
#   map(., ~ na.omit(.x)) %>%
#   map(., ~ as.character(.x)) %>%
#   map(., ~ .x[.x != ""])
# 
# # 思路2：排列组合各种交集的可能性，每一行代表一种可能性
# m0 <- list(c(TRUE, FALSE)) %>%
#   rep(length(d0)) %>%
#   expand.grid() %>%
#   set_names(names(d0)) %>%
#   mutate(s = rowSums(.)) %>%
#   filter(s != 0) %>%
#   select(-s) %>% 
#   rowwise() %>%
#   mutate(int = list(c_across(cols = everything()))) %>%
#   ungroup() %>%
#   mutate(int_name = map(.x = int, .f = function(x){names(d0)[x]}),
#          uni_name = map(.x = int_name, .f = ~ setdiff(x = names(d0), y = .x))) %>% 
#   select(-int) 
# 
# m3 <- m0 %>%
#   # 思路3：根据int_name(uni_name)提取集合名称对应的集合，得到int_set/uni_set，并对其单元格内的list求交集和并集
#   mutate(int_set = map(.x = int_name, .f = ~ sapply(X = .x, FUN = function(x) d0[[x]])),
#          uni_set = map(.x = uni_name, .f = ~ sapply(X = .x, FUN = function(x) d0[[x]]))) %>% 
#   mutate(int_set = map(.x = int_set,
#                        .f = function(x){
#                          if(is.list(x)){
#                            reduce(.x = x, .f = intersect)
#                          } else { return(x)}
#                        }),
#          uni_set = map(.x = uni_set, .f = ~ unlist(.x) %>% unique())) %>%
#   # 思路4：对每一行的int_set和uni_set求差集
#   mutate('Intersect' = map2(.x = int_set, .y = uni_set, .f = ~ setdiff(.x, .y)),
#          Count = unlist(map(.x = Intersect, .f = length)))
# t2 <- proc.time()
# t2 - t1

# user  system elapsed 
# 0.101   0.003   0.102 
# venn画图示例1 ------------------------------------------------------------------
# # 该方法仅适用于普通R desktop绘图，不方便用于shiny图片展示
# library(tidyverse)
# library(VennDiagram)
# library(readxl)
# 
# d0 <- read_xlsx(path = "./shiny_venn/www/Demo_Venn_5.xlsx") %>%  
#   map(., ~ na.omit(.x)) %>%
#   map(., ~ as.character(.x)) %>%
#   map(., ~ .x[.x != ""])
# 
# color_s <- colours() %>%
#   .[c(-1, -2)] %>%
#   sample(size = length(d0))
# 
# plot0 <- venn.diagram(x = d0, filename = NULL,
#                   disable.logging = TRUE,
#                   height = 500, width = 500,
#                   main = "中文",
#                   fill = color_s[1:5],
#                   alpha = 0.5,
#                   # col = NULL,
#                   lwd = NA)
# 
# grid.draw(plot0)

# venn画图示例2 ------------------------------------------------------------------
# # 将图提取过程封装在函数中，方便在shiny中直接调佣图像
# rm(list = ls())
# library(tidyverse)
# library(VennDiagram)
# library(readxl)
# 
# d0 <- read_xlsx(path = "./shiny_develop/shiny_venn/www/Demo_Venn_5.xlsx") %>%
#   map(., ~ na.omit(.x)) %>%
#   map(., ~ as.character(.x)) %>%
#   map(., ~ .x[.x != ""])
# 
# color_s <- colours() %>%
#   .[c(-1, -2)] %>%
#   sample(size = length(d0))
# 
# display_venn <- function(x, ...) {
#   library(VennDiagram)
#   grid.newpage()
#   venn_object <- venn.diagram(x, filename = NULL, ..., )
#   grid.draw(venn_object)
# }
# pdf('test.pdf', width = 8, height = 6)
# display_venn(d0,
#              disable.logging = TRUE,
#              height = 500, width = 500,
#              main = "title",
#              fill = color_s[1:5],
#              alpha = 0.5,
#              lwd = NA, 
#              # fontfamily = 'Times New Roman',
#              # cat.fontface = 'Calibri'
#              ) %>% grid.draw()
# try(dev.off(), silent = TRUE)
# 
