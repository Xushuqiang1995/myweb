## author: Shuqiang Xu
#  date: 2022/03/28
#  update: 2022/06/06

ui <- function(request) {

  # Header ------------------------------------------------------------------
  header <- dashboardHeader(title = "Venn Plot", titleWidth = 200, disable = TRUE)

  # Sidebar -----------------------------------------------------------------
  sidebar <- dashboardSidebar(
    disconnectMessage(
      text = "若上传文件或设置参数运行后出现此界面，表明你上传的数据可能有问题，程序已停止运行。
      请点击‘Refresh’重新打开工具查看教程，严格按照教程示例数据修改你的文件及格式，再做尝试！",
      refresh = "Refresh"
    ),
    # import dependencies  # 自定义断开页面

    actionButton("disconnect", "Disconnect the app"),
    collapsed = TRUE, ### 折叠侧边栏
    useShinyjs(),
    width = 200,
    sidebarMenu(
      id = "tabs",
      menuItem("Venn", tabName = "tabplot", icon = icon("barcode"), startExpanded = )
    )
  )

  # Body --------------------------------------------------------------------
  # theme_choices$ggthemes$solid <- NULL
  body <- dashboardBody(
    theme = shinytheme(theme = "flatly"),
    style = "background-color:white;", ## 将全局默认背景改为白色
    tabItems(
      tabItem(
        "tabplot",
        fluidRow(
          column(
            4, h4("参数"),
            tabsetPanel(
              #   Panel-1: 数据上传和参数设置 -------------------------------------------------------------
              tabPanel(
                "数据&参数",
                shinyFeedback::useShinyFeedback(),
                div(
                  style = "background-color: white; padding-left: 5px; padding-top: 25px; padding-right: 5px; margin-bottom: 5px;", # overflow-y: scroll 添加垂直滑动条
                  fluidRow(
                    column(2, h5(strong("导入数据")), style = "padding-left: 25px"),
                    column(5, fileInput(inputId = "file", accept = c(".txt", ".csv", ".xls", ".xlsx"), label = NULL, placeholder = "xlsx/txt/csv/xls", buttonLabel = "选择文件")),
                    column(4, style = "float:left;", tags$h5(tags$a(icon("download"), downloadLink("downloaddemo", "下载示例文件"))))
                  ),
                ),
                div(
                  id = "venn", style = "background-color: white; padding-left: 5px; padding-right: 5px; margin-bottom: 5px;",
                  fluidRow(
                    column(2, strong("填充颜色"), style = "padding: 10px; padding-left:25px;padding-top:30px"),
                    column(2, colourpicker::colourInput(inputId = "color1", label = "集合1", showColour = "background", value = "cornflowerblue")),
                    column(2, colourpicker::colourInput(inputId = "color2", label = "集合2", showColour = "background", value = "lightcoral")),
                    column(2, colourpicker::colourInput(inputId = "color3", label = "集合3", showColour = "background", value = "olivedrab3")),
                    column(2, colourpicker::colourInput(inputId = "color4", label = "集合4", showColour = "background", value = "orchid")),
                    column(2, colourpicker::colourInput(inputId = "color5", label = "集合5", showColour = "background", value = "slateblue3"))
                  ),
                  fluidRow(
                    column(2, strong("标签角度"), style = "padding: 10px; padding-left: 25px"),
                    column(2, numericInput(inputId = "cat_pos1", label = NULL, value = 0, step = 10)),
                    column(2, numericInput(inputId = "cat_pos2", label = NULL, value = -30, step = 10)),
                    column(2, numericInput(inputId = "cat_pos3", label = NULL, value = 270, step = 10)),
                    column(2, numericInput(inputId = "cat_pos4", label = NULL, value = 110, step = 10)),
                    column(2, numericInput(inputId = "cat_pos5", label = NULL, value = 0, step = 10))
                  ),
                  fluidRow(
                    column(2, strong("标签距离"), style = "padding: 10px; padding-left: 25px"),
                    column(2, numericInput(inputId = "cat_dist1", label = NULL, value = 0.20, width = NULL, step = 0.01)),
                    column(2, numericInput(inputId = "cat_dist2", label = NULL, value = 0.22, width = NULL, step = 0.01)),
                    column(2, numericInput(inputId = "cat_dist3", label = NULL, value = 0.23, width = NULL, step = 0.01)),
                    column(2, numericInput(inputId = "cat_dist4", label = NULL, value = 0.20, width = NULL, step = 0.01)),
                    column(2, numericInput(inputId = "cat_dist5", label = NULL, value = 0.22, width = NULL, step = 0.01))
                  ),
                  fluidRow(
                    column(4, selectInput(inputId = "plot_linetype", label = "颜色区域边框线条", choices = c("blank", "solid", "dashed", "dotted", "dotdash", "longdash", "twodash")), offset = 2),
                    column(2, numericInput(inputId = "plot_linewidth", label = "边框宽度", value = 0.7, min = 0)),
                    column(2, numericInput(inputId = "transparency", label = "颜色透明度", value = 0.4, min = 0.01, max = 1, step = 0.01, width = NULL)),
                    column(2, numericInput(inputId = "margin", label = "图片边距", value = 0.7, min = 0, max = 1, width = NULL)),
                  ),
                  fluidRow(
                    column(2, strong("字号"), style = "padding: 10px; padding-left:40px;padding-top:30px"),
                    column(2, numericInput(inputId = "size_tit", label = "标题", value = 3, step = 0.1)),
                    column(2, numericInput(inputId = "size_lab", label = "标签", value = 1.5, step = 0.1)),
                    column(2, numericInput(inputId = "size_num", label = "数字", value = 1.1, step = 0.1))
                  ),
                  fluidRow(
                    column(2, strong("字体样式"), style = "padding: 25px; padding-left:22px;padding-top:10px"),
                    column(2, selectInput(inputId = "type_tit", label = NULL, choices = c("plain", "bold", "italic", "bold.italic"))),
                    column(2, selectInput(inputId = "type_lab", label = NULL, choices = c("plain", "bold", "italic", "bold.italic"))),
                    column(2, selectInput(inputId = "type_num", label = NULL, choices = c("plain", "bold", "italic", "bold.italic")))
                  ),
                  fluidRow(
                    column(2, strong("字体"), style = "padding: 25px; padding-left:40px;padding-top:10px"),
                    column(2, pickerInput(inputId = "fontfamily_tit", label = NULL, choices = sysfonts::font_families(), selected = 'sans')), # , "Times New Roman", "Arial", "Calibri"
                    column(2, pickerInput(inputId = "fontfamily_lab", label = NULL, choices = sysfonts::font_families(), selected = 'sans')), # , "Times New Roman", "Arial", "Calibri"
                    column(2, pickerInput(inputId = "fontfamily_num", label = NULL, choices = sysfonts::font_families(), selected = 'sans')), # , "Times New Roman", "Arial", "Calibri"
                  ),
                  fluidRow(
                    column(4, textInput(inputId = "label_title", label = "标题内容", value = NULL), offset = 2),
                    column(2, numericInput(inputId = "label_hor", label = "水平位置", value = 0.5, step = 0.05)),
                    column(2, numericInput(inputId = "label_ver", label = "垂直位置", value = 0.8, step = 0.05))
                  )
                )
              ),

              #   Panel-2: 数据预览 -------------------------------------------------------------
              tabPanel(
                "数据预览",
                br(),
                p(style = "color:black", "注意: 表格仅展示上传数据的前10行"),
                br(),
                DT::dataTableOutput(outputId = "preview")
              )
            )
          ),
          column(
            5, h4("结果"),
            tabsetPanel(
              #   Panel-3: 图片&下载 -------------------------------------------------------------
              
              tabPanel(
                title = "图片&下载",
                br(),
                fluidRow(
                  column(2, selectInput(
                    inputId = "plot_format", label = NULL,
                    selected = "png", choices = c("png", "pdf", "tiff", 'svg')
                  )),
                  column(3, numericInputIcon("plot_h", label = NULL, value = 520, min = 10, icon = list("图高"))),
                  column(3, numericInputIcon("plot_w", label = NULL, value = 520, min = 10, icon = list("图宽")))
                ),
                fluidRow(
                  column(1, downloadButton("plot_download", label = "图片")),
                  column(2, downloadButton("plot_overlap_download", label = "Overlap数据集"), style = "padding-left: 40px"),
                  column(4, "参数调整后下方图片将实时更新", style = "color:#F08080; padding-top:10px", offset = 1),
                ),
                div(
                  style = "background-color: white; padding-left: 5px; padding-top: 25px; padding-right: 5px; margin-bottom: 5px;",
                  uiOutput(outputId = "plot_out_ui")
                ),
              ),
              
              #   Panel-4: 绘图参数详情 -------------------------------------------------------------
              tabPanel(
                "绘图参数",
                column(2, downloadButton("plot_config_download", label = "绘图参数"), style = "padding-left: 35px", offset = 1),
                br(),
                br(),
                p("下方为本次绘图主要参数，可点击导出按钮保存到本地，便于后期查找或重现。"),
                tableOutput("plot_config_table")
              )
            )
          ),
          column(
            3, h4("说明"),
            tabsetPanel(
              #   Panel-5: 使用教程 -----------------------------------------------------------
              tabPanel(
                "使用教程",
                div(
                  style = "margin:0px 12px;max-height: 800px; overflow-y: auto;",
                  # a("查看教程",href="https://www.bilibili.com/video/av77519185/",target="_blank"),
                  h4(align = "center", tags$b("使用教程")),
                  h4(tags$b("简介：")),
                  p("韦恩图常用于展示各样本(分组)之间共有(或特有)的元素"),
                  h4(tags$b("适用范围：")),
                  p("适用于转录组、蛋白组、代谢组、微生物、基因组等差异数据的可视化，数据需包括样本(集合)名称及其元素"),
                  h4(tags$b("输入：")),
                  p("含有1-5列不同的样本(集合)"),
                  div(align = "center", tags$img(src = "p1.png", heigth = "100%", width = "100%")),
                  h4(tags$b("下载：")),
                  p("设置好图形的宽高后，选择png/pdf/tiff图片格式后，下载保存图片"),
                  div(align = "center", tags$img(src = "p2.png", heigth = "90%", width = "90%")),
                  h4(tags$b("已传数据预览&绘图数据：")),
                  p("已传数据预览存在数据表明数据已上传成功，绘图数据为经过缺失值处理后的数据"),
                  h4(tags$b("绘图参数导出：")),
                  p("主要介绍了使用的R版本及相应的包版本，以及前端参数设置详情，以便将来图形复现。"),
                  br(),
                  h4(tags$b("参数说明：")),
                  p(strong("填充颜色："), "区域填充的颜色，用来区分不同的样本(集合)。"),
                  p(strong("标签角度："), "样本名称(标签)围绕颜色填充中心旋转的角度。"),
                  p(strong("标签距离："), "样本名称(标签)到颜色填充中心旋转的距离。"),
                  p(strong("颜色区域边框线条："), "有实线、虚线、点线等线类型填充颜色区域边框，也可选择'blank'无线填充颜色外框。"),
                  p(strong("边框宽度："), "边框线条的宽度。"),
                  p(strong("颜色透明度："), "区域填充颜色的透明图，"),
                  p(strong("图片边框："), "空白区域占整张图片的比例。"),
                  p(strong("字号："), "标题、标签、数字的文本大小。"),
                  p(strong("字体样式："), "简洁、加粗、斜体、加粗和斜体等选择。"),
                  p(strong("字体："), "根据期刊发表要求设置相应的字体，如Times New Roman/Calibri等。"),
                  p(strong("标题内容："), "图片标题文本。"),
                  p(strong("水平位置："), "标题文本的水平位置。"),
                  p(strong("垂直位置："), "标题文本的垂直位置。"),
                  p(strong("图高："), "根据需要设置图片的大小与格式。"),
                  p(strong("图宽："), "根据需要设置图片的大小与格式。")
                )
              ),
              #   Panel-6: 常见问题 -----------------------------------------------------------
              tabPanel(
                "常见问题",
                br(),
                p(tags$b("Q1. 各参数控件排序杂乱，挤压显示不全。")),
                p("请全屏显示，并尽量使用谷歌浏览器登录云平台运行工具，部分浏览器可能不兼容，页面布局出现比例失调等情况。"),
                p(tags$b("Q2.如程序宕机，请刷新重新上传文件")),
                p("若自行排查后依然无法正常运转，可联系对应销售经理或项目管理，并提供数据文件，我们会帮助排查。"),
                p(tags$b("Q3. 请确保所有参数都已设置，并保证‘填充颜色’参数不为空值")),
              ),
              #   Panel-7: 工具开发者 -----------------------------------------------------------
              tabPanel(
                "工具开发者",
                br(),
                p("版本号："),
                p("v0.0.1"),
                p("开发者："),
                p("景杰生信部xsq"),
                p("维护者："),
                p("景杰生信部zyl"),
                p("发布日期："),
                p("2022-08-16"),
              )
            )
          )
        )
      )
    )
  )
  dashboardPage(title = "VennWebapp", skin = "blue", header, sidebar, body)
}
