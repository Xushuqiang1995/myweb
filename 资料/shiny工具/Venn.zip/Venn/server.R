#       Venn Plot
# 后端数据处理与绘图

## author: Shuqiang Xu
#  date: 2022/03/28
#  update: 2022/06/06

server <- function(input, output, session){
  original_dir <- getwd()
  # 数据读取d0 / 数据预览 / 数据清理d1 --------------------------------------------------------------------
  # 数据读取
  d0 <- reactive({
    req(input$file)
    ext <- tools::file_ext(input$file$name)

    # 警告1：当数据类型不符合要求
    exist <- ext %in% c("txt","csv","xls","xlsx")
    shinyFeedback::feedbackDanger(inputId = 'file', show = !exist, text = "请导入csv|txt|xls|xlsx格式文件")
    req(exist, cancelOutput = TRUE)
    
    d <- switch(ext,
                txt = vroom::vroom(input$file$datapath),
                csv = vroom::vroom(input$file$datapath, delim = ","),
                xls  = read.xlsx(path = input$file$datapath),
                xlsx = read_xlsx(path = input$file$datapath),
                validate("无效文件，请输出csv|txt|xls|xlsx格式文件")
                )
    # 警告2：当数据列数超过5组
    n_col <- ncol(d) > 5
    shinyFeedback::feedbackDanger(inputId = 'file', show = n_col, text = "数据超过5组(列)，建议使用upSet")
    req(!n_col, cancelOutput = TRUE)

    return(d)
  })

  # 数据预览
  output$preview <- DT::renderDataTable({
    req(d0())
    datatable(d0(),
              extensions = 'Buttons',
              class      = "row-border hover",
              options    = list(pageLength = 10,
                                lengthMenu = c(10, 20, 50, 100, -1),
                                dom = 'rt',
                                scrollX=TRUE))
  })

  # 数据清理/转换
  d1 <- reactive({
    d0() %>%
      as.list() %>%
      map(., ~ na.omit(.x)) %>%        # 在读取整个表格(xlsx)时，列数据集的元素个数不一致，会有NA存在
      map(., ~ .x[.x !='']) %>%        # 缺失值可能是‘’的情况
      map(., ~ as.character(.x)) %>%   # 如果数值，则转换成char
      return()
  })



  # 更新ui参数: ui端根据上传数据改变------------------------------------------------------------
  observeEvent(input$file, {
    req(d1())
    len <- length(d1())

    # 图片边距ui
    updateNumericInput(inputId = "margin", label = "图片边距", value = case_when(len==1~0,len==2~0, len==3~0,len==4~0,len==5~0), min = 0, max = 1, step = 0.01)
    # 填充颜色ui
    colors_select <- c('cornflowerblue', 'lightcoral', 'olivedrab3', 'orchid', 'slateblue3')
    colourpicker::updateColourInput(session, "color1", value = ifelse(len>=1,colors_select[1],'white'), label = ifelse(len>=1, names(d1())[1], 'null'), showColour = 'background')
    colourpicker::updateColourInput(session, "color2", value = ifelse(len>=2,colors_select[2],'white'), label = ifelse(len>=2, names(d1())[2], 'null'), showColour = 'background')
    colourpicker::updateColourInput(session, "color3", value = ifelse(len>=3,colors_select[3],'white'), label = ifelse(len>=3, names(d1())[3], 'null'), showColour = 'background')
    colourpicker::updateColourInput(session, "color4", value = ifelse(len>=4,colors_select[4],'white'), label = ifelse(len>=4, names(d1())[4], 'null'), showColour = 'background')
    colourpicker::updateColourInput(session, "color5", value = ifelse(len>=5,colors_select[5],'white'), label = ifelse(len>=5, names(d1())[5], 'null'), showColour = 'background')

    # ui:cat_pos(标签角度)
    updateNumericInput(session, "cat_pos1", label = NULL, value = case_when(len == 1 ~ 0,len == 2 ~ -20,len == 3 ~ -3, len == 4 ~ -15,len == 5 ~ 360))
    updateNumericInput(session, "cat_pos2", label = NULL, value = case_when(             len == 2 ~ 10 ,len == 3 ~ 3,  len == 4 ~ 15, len == 5 ~ -30))
    updateNumericInput(session, "cat_pos3", label = NULL, value = case_when(                            len == 3 ~ 180,len == 4 ~ 0,  len == 5 ~ 270))
    updateNumericInput(session, "cat_pos4", label = NULL, value = case_when(                                           len == 4 ~ 0,  len == 5 ~ 110))
    updateNumericInput(session, "cat_pos5", label = NULL, value = case_when(                                                          len == 5 ~ 0  ))


    # ui:cat_dist(标签距离)
    updateNumericInput(session, "cat_dist1", label = NULL,step = 0.01, value = case_when(len == 1 ~ 0.03,len == 2 ~ 0.5,len == 3 ~ 0.06,len == 4 ~ 0.22,len == 5 ~ 0.20))
    updateNumericInput(session, "cat_dist2", label = NULL,step = 0.01, value = case_when(               len == 2 ~ 0.58,len == 3 ~ 0.06,len == 4 ~ 0.22,len == 5 ~ 0.22))
    updateNumericInput(session, "cat_dist3", label = NULL,step = 0.01, value = case_when(                               len == 3 ~ 0.03,len == 4 ~ 0.12,len == 5 ~ 0.24))
    updateNumericInput(session, "cat_dist4", label = NULL,step = 0.01, value = case_when(                                               len == 4 ~ 0.12,len == 5 ~ 0.22))
    updateNumericInput(session, "cat_dist5", label = NULL,step = 0.01, value = case_when(                                                               len == 5 ~ 0.22))

    # ui:标题垂直和水平位置
    updateNumericInput(inputId = "label_hor", label = "水平位置", value = case_when(len==1 ~ 0.5,len==2 ~ 0.5,len==3 ~ 0.5 ,len==4 ~ 0.5 ,len==5 ~ 0.5 ), min = 0, max = 1)
    updateNumericInput(inputId = "label_ver", label = "垂直位置", value = case_when(len==1 ~ 1  ,len==2 ~ 1  ,len==3 ~ 1   ,len==4 ~ 0.95,len==5 ~ 1.08), min = 0, max = 1)

    # 隐藏不必要的ui
    # hide(id = "")
    output$plot_out_ui <- renderUI({
      plotOutput(outputId = "plot_out", width = paste0(input$plot_w,'px'), height = paste0(input$plot_h,'px'))
    })

  })

  # 图形/绘图参数输出 ---------------------------------------------------------------
  observe({
    # 整理画图参数：整理ui端参数
    color_s <<- c(input$color1, input$color2, input$color3, input$color4, input$color5) %>%
      first(n = length(d1()))
    cat_pos_s <<- c(input$cat_pos1, input$cat_pos2, input$cat_pos3, input$cat_pos4, input$cat_pos5) %>%
      first(n = length(d1()))
    cat_dist_s <<- c(input$cat_dist1, input$cat_dist2, input$cat_dist3, input$cat_dist4, input$cat_dist5) %>%
      first(n = length(d1()))
    main_just <<- c(input$label_hor, input$label_ver)

    # 画图输出
    output$plot_out <- renderPlot({
      venn_object <- try(display_venn(d1(), disable.logging = TRUE,
                         margin=input$margin, main.pos = c(input$label_hor, input$label_ver),
                         fill = color_s,                   # 填充颜色
                         cat.dist = cat_dist_s,            # 标签距离图形距离
                         cat.pos = cat_pos_s,              # 标签旋转
                         alpha = input$transparency,       # 颜色透明度
                         main = input$label_title,                # 标题内容
                         main.cex = input$size_tit,               # 标题字号
                         main.fontface = input$type_tit,          # 标题字形
                         main.fontfamily = input$fontfamily_tit,  # 标题字体
                         cat.cex = input$size_lab,                # 标签字号
                         cat.fontface = input$type_lab,           # 标签字形
                         cat.fontfamily = input$fontfamily_lab,   # 标签字体
                         cex = input$size_num,              # 数字字号
                         fontface = input$type_num,         # 数字字形
                         fontfamily = input$fontfamily_num, # 数字字体
                         lwd = input$plot_linewidth,        # 颜色区域外框线宽
                         lty = input$plot_linetype          # 颜色区域外框线条类型
                         ), silent = TRUE)
    })
    
    # 绘图参数输出
    # 整理绘图参数矩阵
    plot_values_matrix <<- rbind(c("R version:", paste0(' ', str_extract(R.version$version.string, '(\\d).(\\d).(\\d{1,2})'))),
                                c("R package(version):", paste0(" VennDiagram",packageVersion("VennDiagram"))),
                                c("标题内容", input$label_title),
                                c("标题水平位置", input$label_hor),
                                c("标题垂直位置", input$label_ver)) %>%
      as_tibble() %>%
      set_names(nm = c("Keys","Values"))

    color_config <<- tibble("Keys" = paste0('颜色:', names(d1())), "Values" = color_s)
    cat_dist_config <<- tibble("Keys" = paste0('标签距离:', names(d1())), "Values" = cat_dist_s)
    cat_pos_config <<- tibble("Keys" = paste0('标签位置:', names(d1())), "Values" = cat_pos_s)
  })
  output$plot_config_table <- renderTable({
    req(input$file)
    plot_values_matrix0 <<- reduce(.f = rbind, .x = list(plot_values_matrix,
                                                        color_config,
                                                        cat_dist_config,
                                                        cat_pos_config,
                                                        c('颜色透明度', input$transparency),
                                                        c('图片边距', input$margin),
                                                        c('颜色边框宽度', input$plot_linewidth),
                                                        c('颜色区域边框线条类型', input$plot_linetype),
                                                        c('标题字号', input$size_tit),
                                                        c('标题字体', input$type_tit),
                                                        c('标题字体样式', input$fontfamily_tit),
                                                        c('标签字号', input$size_lab),
                                                        c('标签字体', input$type_lab),
                                                        c('标签字体样式', input$fontfamily_lab),
                                                        c('数字字号', input$size_num),
                                                        c('数字字体', input$type_num),
                                                        c('数字字体样式', input$fontfamily_num)))
  })
  

  # 图形/绘图参数下载 --------------------------------------------------------------------
  # 图形下载
  observeEvent(input$plot_format, {
    output$plot_download <- downloadHandler(
      filename = paste0('Venn_plot.', input$plot_format),
      content = function(file) {
        setwd(tempdir())
        switch(input$plot_format,
               'png' = CairoPNG(file, width = input$plot_w, height = input$plot_h),
               'tiff' = CairoTIFF(file, width = input$plot_w, height = input$plot_h),
               'pdf' = CairoPDF(file, width = input$plot_w/85, height = input$plot_h/85),
               'svg' = CairoSVG(file, width = input$plot_w/85, height = input$plot_h/85))
        
        display_venn0(d1(), disable.logging = TRUE,
                      margin=input$margin, main.pos = c(input$label_hor, input$label_ver),
                      fill = color_s,                   # 填充颜色
                      cat.dist = cat_dist_s,            # 标签距离图形距离
                      cat.pos = cat_pos_s,              # 标签旋转
                      alpha = input$transparency,       # 颜色透明度
                      main = input$label_title,                # 标题内容
                      main.cex = input$size_tit,               # 标题字号
                      main.fontface = input$type_tit,          # 标题字形
                      main.fontfamily = input$fontfamily_tit,  # 标题字体
                      cat.cex = input$size_lab,                # 标签字号
                      cat.fontface = input$type_lab,           # 标签字形
                      cat.fontfamily = input$fontfamily_lab,   # 标签字体
                      cex = input$size_num,              # 数字字号
                      fontface = input$type_num,         # 数字字形
                      fontfamily = input$fontfamily_num, # 数字字体
                      lwd = input$plot_linewidth,        # 颜色区域外框线宽
                      lty = input$plot_linetype)         # 颜色区域外框线条类型
        try(dev.off(), silent = TRUE)
      }
    )
  })

  # 绘图参数下载
  output$plot_config_download <- downloadHandler(
    filename = paste0('overlap_config.xlsx'),
    content = function(file) {
      openxlsx::write.xlsx(plot_values_matrix0, file, row.names = FALSE, append = TRUE, sheetName = 'Sheet 1')
    }
  )
  

  # Overlap数据处理与下载 -------------------------------------------------------
  # Overlap数据处理
  observe({
    ### 思路
    ### 1. 列举所有集合overlap情况，每个集合要么是交集类，要么是差集类
    ### 2. 对交集'intersect'类：提取"公共"元素
    ### 3. 对差集'union'类：提取"所有"元素
    ### 4. 交集类元素 - 差集类元素，则元素只在交集类的每一个集合中，而不在差集类的每一个集合中

    ### 1. 列举所有集合overlap情况，得到m0，每个集合要么是交集类，要么是差集类
    m0 <- list(c(TRUE, FALSE)) %>% 
      rep(length(d1())) %>% 
      expand.grid() %>%
      set_names(names(d1())) %>%
      mutate(s = rowSums(.)) %>%
      filter(s != 0) %>%
      select(-s)

    m_intersect <- m_union <- list()
    for (i in seq(nrow(m0))) {
      #
      m_intersect[[i]] <- m0[i,] %>% as_vector() %>% names(d1())[.]
      m_union[[i]] <- (!m0[i,]) %>% as_vector() %>% names(d1())[.]
    }
    m0 <- m0 %>%
      as_tibble() %>%
      mutate(intersect = m_intersect,
             union = m_union)

    ### 思路2/3/4，得到m1/m2俩种数据表达形式
    m1 <<- m0 %>%
      ### 2. 对交集类：提取"公共"元素
      ### 3. 对差集类：提取"所有"元素
      mutate(intersect_set = map(.x = intersect, ~ Set(data = d1(), data_name = .x, type = 1)),
                union_set = map(.x = union, ~ Set(data = d1(), data_name = .x, type = 0))) %>%
      ### 4. 交集类元素 - 差集类元素，则元素只在交集类的每一个集合中，而不在差集类的每一个集合中
      mutate(sets = map2(.x = intersect_set, .y = union_set, .f = ~ setdiff(.x, .y)),
               count = map(.x = sets, .f = ~ length(.x)),
               count = as_vector(count)) %>%
      dplyr::select(-intersect_set, -union_set) %>%
      relocate(count, .before = sets) %>%
      dplyr::select(-union)

    m2 <<- m1 %>%
      mutate(sets = map(.x = sets, .f = ~ paste0(.x, collapse = ';')),
             'intersect' = map(.x = 'intersect', .f = ~ paste0(.x, collapse = ';')) %>% unlist(),
             'union' = map(.x = 'union', .f = ~ paste0(.x, collapse = ';')) %>% unlist(),
             intersect = str_replace_all(intersect, ';', '+'),
             union = str_replace_all(union, ';', '∪'),
             type = intersect) %>%
      select(-'intersect') %>%
      relocate(type) %>%
      separate_rows(sets, sep = ';')

  })

  ### Overlap数据下载
  output$plot_overlap_download <- downloadHandler(
    filename = paste0('overlap_data.xlsx'),
    content = function(file) {
      openxlsx::write.xlsx(m1, file, row.names = FALSE, append = TRUE, sheetName = 'Sheet 1')
    }
  )


  # 示例数据下载 ------------------------------------------------------------------
  output$downloaddemo <- downloadHandler(
    filename = paste0('Demo_venn.csv'),
    content = function(file){
      file.copy(paste0(original_dir,"/www/Demo_venn.csv"), file)
      }
  )



}
